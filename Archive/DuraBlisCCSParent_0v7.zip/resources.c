/* File:   resources.c
 * Manages the matrix of needed control resoources versus parent / child owners
 * Author: Michael L Anderson
 * Contact: MichaelLAndersonEE@gmail.com
 * Platform: PIC32MX350F256H on DuraBlis-CCS-Main_v4 board.
 * LCD:  NHD NHD-C12864WC-FSW-FBW-3V3, 128 x 64 pixels
 * Created: 18 Sep14
 */

#include <xc.h>
#include <stdbool.h>
#include "DuraBlisCCSParent.h"
#include "resources.h"

static const unsigned resourceParentK1 = 0x1000;       // Bit order in resourceMatrix
static const unsigned resourceParentK2 = 0x2000;
bool resourceFloodSensor[NUM_CHILDREN];

    // resource is from resourceMatrix, eg resourceMatrix.heater
    // owner is child <1..8> or parent <0>
    // Returns 0x01 for relay K1 | 0x02 for relay K2 | 0x04 for extra (eg exterior
    // TH sensor). 0x00 for null vector. 0xF0 for error.
byte resourceQuery(unsigned *resource, byte owner)
{
    byte retVal = 0;
    unsigned bitField;

    if (resource == &resourceMatrix.heater)
    {
        if (owner == 0)     // Parent
        {
            if (resourceMatrix.heater & resourceParentK1) retVal |= 0x01;
            if (resourceMatrix.heater & resourceParentK2) retVal |= 0x02;
        }
        else
        {
            bitField = (resourceMatrix.heater & 0x0F00) >> 8;
            if (bitField == owner) retVal |= 0x01;      // 'Child c has heater on K1'
            bitField = (resourceMatrix.heater & 0x00F0) >> 4;
            if (bitField == owner) retVal |= 0x02;
        }
    }
    else if (resource == &resourceMatrix.airConditioner)
    {
        if (owner == 0)     // Parent
        {
            if (resourceMatrix.airConditioner & resourceParentK1) retVal |= 0x01;
            if (resourceMatrix.airConditioner & resourceParentK2) retVal |= 0x02;
        }
        else
        {
            bitField = (resourceMatrix.airConditioner & 0x0F00) >> 8;
            if (bitField == owner) retVal |= 0x01;
            bitField = (resourceMatrix.airConditioner & 0x00F0) >> 4;
            if (bitField == owner) retVal |= 0x02;
        }
    }                   // A parent cannot have further resources. They require large relays
    else if (resource == &resourceMatrix.dehumidifier)
    {
        bitField = (resourceMatrix.dehumidifier & 0x0F00) >> 8;
        if (bitField == owner) retVal |= 0x01;
        bitField = (resourceMatrix.dehumidifier & 0x00F0) >> 4;
        if (bitField == owner) retVal |= 0x02;
    }
    else if (resource == &resourceMatrix.airExchanger)
    {
        bitField = (resourceMatrix.airExchanger & 0x0F00) >> 8;
        if (bitField == owner) retVal |= 0x01;
        bitField = (resourceMatrix.airExchanger & 0x00F0) >> 4;
        if (bitField == owner) retVal |= 0x02;
    }
    else if (resource == &resourceMatrix.humidifier)
    {
        bitField = (resourceMatrix.humidifier & 0x0F00) >> 8;
        if (bitField == owner) retVal |= 0x01;
        bitField = (resourceMatrix.humidifier & 0x00F0) >> 4;
        if (bitField == owner) retVal |= 0x02;
    }
    else if (resource == &resourceMatrix.intFanTH)
    {
        bitField = (resourceMatrix.intFanTH & 0x0F00) >> 8;
        if (bitField == owner) retVal |= 0x01;
        bitField = (resourceMatrix.intFanTH & 0x00F0) >> 4;
        if (bitField == owner) retVal |= 0x02;
    }
    else if (resource == &resourceMatrix.outsideTH)
    {
        bitField = (resourceMatrix.outsideTH & 0x000F);     // Note different position
        if (bitField == owner) retVal |= 0x04;
    }
    
    return(retVal);
}

    // Signals successful change.  Relay 1 | 2. Owner 0 for parent, 1:8 for child
    // TODO optimize
    // -------------------------------
bool resourceChange(unsigned *resource, byte owner, byte relay, bool enable)
{
#define NUM_RES 6

    unsigned bitField;
    unsigned *resPtrAry[NUM_RES] = {
        &resourceMatrix.heater,
        &resourceMatrix.airConditioner,
        &resourceMatrix.dehumidifier,
        &resourceMatrix.airExchanger,
        &resourceMatrix.humidifier,
        &resourceMatrix.intFanTH };
        //&resourceMatrix.outsideTH };
    unsigned *resPtr;
    byte res;

    if ((owner > NUM_CHILDREN) || (relay > 2)) return(false);
    if ((owner == IDX_PARENT) && (res > 2)) return(false);   // Parent cannot have more resources
    if (resource == &resourceMatrix.outsideTH)      // This one is different
    {
        if (enable) resourceMatrix.outsideTH = owner;
        else resourceMatrix.outsideTH &= 0xFF0;
        return(true);
    }

    for (res = 0; res < NUM_RES; res++)
    {
        resPtr = resPtrAry[res];            // &resourceMatrix.heater;

        if (resource == resPtr)
        {
            if (owner == 0)     // Parent
            {
                if (relay == 1)
                {
                    if (enable) *resPtr |= resourceParentK1;
                    else *resPtr &= ~resourceParentK1;

                    //if (enable) resourceMatrix.heater |= resourceParentK1;
                    //else resourceMatrix.heater &= ~resourceParentK1;
                }
                else
                {
                    if (enable) *resPtr |= resourceParentK2;
                    else *resPtr &= ~resourceParentK2;

//                    if (enable) resourceMatrix.heater |= resourceParentK2;
//                    else resourceMatrix.heater &= ~resourceParentK2;
                }
            }
            else                    // Child
            {
                if (relay == 1)
                {
                    bitField = ((unsigned) owner) << 8;
                    if (enable) *resPtr |= bitField;
                    else *resPtr &= 0x00FF;      // TODO make sure this isn't too dire
//                    if (enable) resourceMatrix.heater |= bitField;
//                    else resourceMatrix.heater &= 0x00FF;
                }
                else                // Relay 2
                {
                   bitField = ((unsigned) owner) << 4;
                   if (enable) *resPtr |= bitField;
                   else *resPtr &= 0x0F0F;
                }
            }
        }
    }

    return(true);
}

    // ------------------
void resourceInitialize(void)
{
    byte c;

    resourceMatrix.heater = 0;
    resourceMatrix.airConditioner = 0;        // Parent low-current thermostat K1 & K2 only for first two resources
    resourceMatrix.dehumidifier = 0;
    resourceMatrix.airExchanger = 0;
    resourceMatrix.humidifier = 0;
    resourceMatrix.intFanTH = 0;
    resourceMatrix.outsideTH = 0;

    for (c = 0; c < NUM_CHILDREN; c++)
        resourceFloodSensor[c] = false;
}