/* File:   time.c  RTCC and high level time functions
 * Author: Michael L Anderson
 * Contact: MichaelLAndersonEE@gmail.com
 * Platform: PIC32MX350F256H on DuraBlis-CCS-Main_v4 board.
 * Created: 18 Sep14
 */

#include <xc.h>
#include <stdbool.h>
#include "DuraBlisCCSParent.h"
#include "time.h"


struct t_struct time;
unsigned process1Time_secs = 8;    // Network polling  TODO report
const char monStr[12][4] =
    { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };

    // Mon is 1 - 12, year is 00 - 99
byte daysInMonth(byte mo, byte yr)
{
    byte retVal;
    const byte dIM[12] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    if (mo < 1 || mo > 12 || yr > 99) return(0);
    retVal = dIM[mo - 1];
    if ((yr % 4 == 0) && (mo == 2) ) retVal++;
    return(retVal);
}

   // ----------------------
void delay_us(unsigned T)   // TODO calibrate
{
    unsigned t;
    for (t=0; t<T; t++ ) ;
}

// This is simply based on the present exec loop timing.
    // In Ver 0.51, period = 5 us.
void fastTimer(void)
{
    static unsigned fastCtr;

    if (fastCtr++ > 200)
    {      
        fastCtr = 0;
        if (time.msec++ > 999) time.msec = 0;
        timeRead(TIME_UPDATE);  // Ca 1 ms resolution
    }
}

    // Reads RTCC and updates time struct.  Called by timeFast() approx every sec.
    // Sets bool .newMinute for main exec loop, which must clr it.
void timeRead(byte modeRead)
{
    static byte oldSec;
    static unsigned process1Timer;
    byte tBfr;
   //bool retVal = false;
    long unsigned rtccImage;

    rtccImage = RTCTIME;
    if (modeRead == TIME_LOQUACIOUS)
    {
        sprintf(ioBfr, "\n\r\tT: %08lX\n\r", rtccImage);
        putStr(ioBfr);
    }

    rtccImage >>= 8;        // Lower 8 empty
    tBfr = rtccImage;
    tBfr = bcd2byte(tBfr);
    if (tBfr < 60) time.second = tBfr;
    if (modeRead == TIME_LOQUACIOUS)
    {
        sprintf(ioBfr, "\ts %02d, ", tBfr);
        putStr(ioBfr);
    }
    //if ((modeRead == TIME_NEW_SECOND) && (tBfr != oldSec)) retVal = true;

    if (time.second != oldSec)
    {
        time.process2Flag = true;
        if (++process1Timer >= process1Time_secs)
        {
            process1Timer = 0;
            time.process1Flag = true;   // The user will clear
        }
    }
    oldSec = time.second;

    rtccImage >>= 8;
    tBfr = rtccImage;
    tBfr = bcd2byte(tBfr);
    if (tBfr < 60) time.minute = tBfr;
    if (modeRead == TIME_LOQUACIOUS)
    {
        sprintf(ioBfr, "m %02d, ", tBfr);
        putStr(ioBfr);
    }
//    if (time.minute != oldMinute) time.process1Flag = true;
//    oldMinute = time.minute;

    rtccImage >>= 8;
    tBfr = rtccImage;
    tBfr = bcd2byte(tBfr);
    if (tBfr < 24) time.hour = tBfr;
    if (modeRead == TIME_LOQUACIOUS)
    {
        sprintf(ioBfr, "h %02d, ", tBfr);
        putStr(ioBfr);
    }

    rtccImage = RTCDATE;
    if (modeRead == TIME_LOQUACIOUS)
    {
        sprintf(ioBfr, "\n\r\tD: %08lX\n\r", rtccImage);
        putStr(ioBfr);
    }
    tBfr = rtccImage;
    tBfr = bcd2byte(tBfr);
    if (tBfr < 7) time.weekday = tBfr;
    if (modeRead == TIME_LOQUACIOUS)
    {
        sprintf(ioBfr, "\twd %02d, ", tBfr);
        putStr(ioBfr);
    }

    rtccImage >>= 8;
    tBfr = rtccImage;
    tBfr = bcd2byte(tBfr);
    if (tBfr < 32) time.dayMonth = tBfr;
    if (modeRead == TIME_LOQUACIOUS)
    {
        sprintf(ioBfr, "dm %02d, ", tBfr);
        putStr(ioBfr);
    }

    rtccImage >>= 8;
    tBfr = rtccImage;
    tBfr = bcd2byte(tBfr);
    if (tBfr < 13) time.month = tBfr;
    if (modeRead == TIME_LOQUACIOUS)
    {
        sprintf(ioBfr, "m %02d, ", tBfr);
        putStr(ioBfr);
    }

    rtccImage >>= 8;
    tBfr = rtccImage;
    tBfr = bcd2byte(tBfr);
    if (tBfr < 100) time.year = tBfr;
    if (modeRead == TIME_LOQUACIOUS)
    {
        sprintf(ioBfr, "y %02d", tBfr);
        putStr(ioBfr);
    }

   // if (modeRead == TIME_UPDATE) retVal = true;
   // return(retVal);
}

    ////////////////////
void timeWrite(void)
{
    unsigned long timeNow;  // = 0x12345678 Set time to 12 hr, 34 min, 56 sec
    unsigned long dateNow;  // = 0x14111001 Set date to Mon, 10 Nov 2014

    timeNow = byte2bcd(time.hour);
    timeNow <<= 8;
    timeNow += byte2bcd(time.minute);
    timeNow <<= 16;         // Time write a fortiori sets sec = 0;
                            // PIC32MX350 RTCC does not have subsec resolution
    dateNow =  byte2bcd(time.year);
    dateNow <<= 8;
    dateNow += byte2bcd(time.month);
    dateNow <<= 8;
    dateNow += byte2bcd(time.dayMonth);
    dateNow <<= 8;
    dateNow += byte2bcd(time.weekday);

    RTCCONCLR = 0x8000;     // Turn off the RTCC
    while(RTCCON & 0x40);   // Wait for clock to be turned off
    RTCTIME = timeNow;      // Safe to update the time
    RTCDATE = dateNow;      // Update the date
    RTCCONSET = 0x8000;     // Turn on the RTCC
    while(!(RTCCON & 0x40));// Wait for clock to be turned on  TODO timeout
}

