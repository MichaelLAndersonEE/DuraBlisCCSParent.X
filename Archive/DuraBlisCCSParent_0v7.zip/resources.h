/* File:   resources.h
 * Manages the matrix of needed control resoources versus parent / child owners
 * Author: Michael L Anderson
 * Contact: MichaelLAndersonEE@gmail.com
 * Platform: PIC32MX350F256H on DuraBlis-CCS-Main_v4 board.
 * LCD:  NHD NHD-C12864WC-FSW-FBW-3V3, 128 x 64 pixels
 * Created: 18 Sep14
 */

#ifndef RESOURCES_H
#define	RESOURCES_H

#ifdef	__cplusplus
extern "C" {
#endif

#define IDX_PARENT  0       // Used in resource mgmt

   // This maps needed resources to child node numbers or local control.
    // We will incorporate the info from childen EQQs.  Children are 1-indexed.
    // xx, <1> parent K1, <1> parent K2, <4> child K1, <4> child K2, <4> child input
    // The order here shall be the priority order. Eg, if local K1 bit is set for heater and for airCon,
    // we will treat only heater case.  This is a logical inconsistency that should be caught by RealityCheck().
    // A resource may easily be null, in which case we lack a control vector. An implicit assumption is that a
    // given resource has at most two children associated with it. This seems reasonable.
struct res_struct
{
    unsigned heater;
    unsigned airConditioner;        // Parent low-current thermostat K1 & K2 only for first two resources
    unsigned dehumidifier;
    unsigned airExchanger;
    unsigned humidifier;
    unsigned intFanTH;
    unsigned outsideTH;
} resourceMatrix;

byte resourceQuery(unsigned *resource, byte owner);
bool resourceChange(unsigned *resource, byte owner, byte relay, bool enabled);
void resourceInitialize(void);

#ifdef	__cplusplus
}
#endif

#endif	/* RESOURCES_H */