/* File:   serial.h  UART consoleIO
 * Author: Michael L Anderson
 * Contact: MichaelLAndersonEE@gmail.com
 * Platform: PIC32MX350F256H on BW-CCS-Main_v2 board
 * Created: 16 May 14
 */

#ifndef SERIAL_H
#define	SERIAL_H

#ifdef	__cplusplus
extern "C" {
#endif

#define CARRIAGE_RETURN     13

int getStr(char *buffer, byte numChars, unsigned timeOut);
int parseHex3Byte(char nibHi, char nibMid, char nibLo, unsigned *hexaFlexagon);
void putUns2Hex(unsigned uns);
void putByte2Hex(byte me);
void putPrompt(void);
void putChar(char c);
char getChar(void);
void putStr(const char *);

char *itoa(char *buf, int val, int base);
char *utoa(char *buf, unsigned val, int base);

#ifdef	__cplusplus
}
#endif

#endif	/* SERIAL_H */

