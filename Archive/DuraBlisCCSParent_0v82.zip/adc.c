/* File:   adc.c  Analog functions low and high level
 * Author: Michael L Anderson
 * Contact: MichaelLAndersonEE@gmail.com
 * Platform: PIC32MX350F256H on BW-CCS-Main_v2 board.  
 * Created: 10 Jul 14
 */

#include <xc.h>
#include "DuraBlisCCSParent.h"
#include "adc.h"
#include "serial.h"

#define NUM_SA   16
#define ADC_LOW_TH_RANGE   0.2     // Acceptable V range for T&H sensors
#define ADC_HIGH_TH_RANGE  3.0

static unsigned adcUrConvert(byte chan);
static double adcMeanConvert(byte chan);

    // TODO set/clr error bits
void adcCurrents(byte opMode)
{
    // extern double temperNowF, temperCalFactor, rhumidNow, rhumidCalFactor;
    const byte chArray[NUM_CHILDREN] = { ANCH_ISEN1, ANCH_ISEN2, ANCH_ISEN3, ANCH_ISEN4,
        ANCH_ISEN5, ANCH_ISEN6, ANCH_ISEN7, ANCH_ISEN8 };
    extern double iSen[NUM_CHILDREN], iSenCalFactor [NUM_CHILDREN];
    double adcV;
    byte sa;

    if (opMode == ADC_LOQUACIOUS) putStr("\tChild currents: \n\r");

    for (sa = 0; sa < NUM_CHILDREN; sa++)
    {
        adcV = adcMeanConvert(chArray[sa]);
        iSen[sa] = iSenCalFactor[sa] * adcV / 2000.0;   // Nominal 2 ohm sense resistor, /1000 for mA

        if (opMode == ADC_LOQUACIOUS)
        {
            sprintf(ioBfr, "\tCh %d: %4.03f mA [%5.04f]\n\r", sa + 1, iSen[sa], iSenCalFactor[sa]);
            putStr(ioBfr);
        }
    }
}

    // TODO set/clr error bits
void adcTH(byte opMode)
{
    extern double temperNowF, temperCalFactor, rhumidNow, rhumidCalFactor;
    extern unsigned sysFault;
    double adcV;

        // Microchip MCP9700A
    adcV = adcMeanConvert(ANCH_TEMPER);
    if ((adcV < ADC_LOW_TH_RANGE) || (adcV > ADC_HIGH_TH_RANGE)) sysFault |= FLT_PARENT_TSENSOR;   // User must clear    
    temperNowF = 180 * adcV - 58;
    temperNowF *= temperCalFactor;

    if (opMode == ADC_LOQUACIOUS)
    {
        putStr("\tTemperature: ");
        sprintf(ioBfr, "%3.02f oF (%3.02fV) ", temperNowF, adcV);
        putStr(ioBfr);
        putStr("\n\r");
    }

        // Honeywell HIH5030, normalized to unity
        // TODO Sensor has temperature dependence and slight hysteresis
    adcV = adcMeanConvert(ANCH_RELHUM);
    if ((adcV < ADC_LOW_TH_RANGE) || (adcV > ADC_HIGH_TH_RANGE)) sysFault |= FLT_PARENT_HSENSOR;   // User must clear
    rhumidNow = 50 * adcV - 25;
    rhumidNow *= rhumidCalFactor;

    if (opMode == ADC_LOQUACIOUS)
    {
        putStr("\r\n\tRel humidity: ");
        sprintf(ioBfr, "%3.02f %% (%3.02fV)", rhumidNow, adcV);
        putStr(ioBfr);
        putStr("\n\r");
    }
}

double adcMeanConvert(byte chan)
{
    byte sa;
    double retVal = 0.0;
    unsigned uBfr[NUM_SA], samp, minSa = 0xFFFF, maxSa = 0;

    for (sa = 0; sa < NUM_SA; sa++)
    {
        delay_us(10);
        samp = adcUrConvert(chan);
        uBfr[sa] = samp;
        if (samp < minSa) minSa = samp;
        if (samp > maxSa) maxSa = samp;
    }
    
    for (sa = 0; sa < NUM_SA; sa++)
    {
//        sprintf(ioBfr, " %03X\t", (unsigned) uBfr[sa]); // DEB
//        putStr(ioBfr);
        retVal += uBfr[sa];
    }

    retVal -= minSa;
    retVal -= maxSa;

    retVal /= (NUM_SA - 2);
    retVal = 3.3 * retVal / 1023;
    
        // DEB
//    sprintf(ioBfr, " %4.03f\t", retVal);
//    putStr(ioBfr);

    return(retVal);
}

unsigned adcUrConvert(byte chan)
{
    AD1CON1bits.SAMP = 0;       // End sampling & start conver
    AD1CHSbits.CH0NA = 0;       // Sample A Ch 0 neg input is Vrefl
    AD1CHSbits.CH0SA = chan;    // A mux <- chan
    AD1CSSL = 0;                // Write to scan buff 0

    AD1CON1bits.SAMP = 1;       // Start sampling
    delay_us(10);
    AD1CON1bits.SAMP = 0;
    while(!(AD1CON1bits.DONE)) ;    // Wait
    return(ADC1BUF0);
}