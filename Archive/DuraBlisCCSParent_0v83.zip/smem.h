/* File:   smem.h  SEEPROM functions
 * Author: Michael L Anderson
 * Contact: MichaelLAndersonEE@gmail.com
 * Platform: PIC32MX350F256H on DuraBlis-CCS-Main_v4 board.
 * Created: 02 Oct 14
 */


#ifndef SMEM_H
#define	SMEM_H

#ifdef	__cplusplus
extern "C" {
#endif

void smemWriteTest(void);
void smemReadTest(void);
byte smemInit(void);
void smemRestore(void);
void smemSave(void);
//byte smemEraseAll(void);

#ifdef	__cplusplus
}
#endif

#endif	/* SMEM_H */

