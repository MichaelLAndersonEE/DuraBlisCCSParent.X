/* File:   smem.c  SEEPROM SPI2-based functions
 * Author: Michael L Anderson
 * Contact: MichaelLAndersonEE@gmail.com
 * Platform: PIC32MX350F256H on DuraBlis-CCS-Main_v4 board.
 * Created: 02 Oct 14
 */

#include <xc.h>
#include "DuraBlisCCSParent.h"
#include "smem.h"

    // SMEM semantics
#define SMEM_DUMMY  0x00
#define SMEM_READ   0x03
#define SMEM_WRITE  0x02
#define SMEM_WRDI   0x04
#define SMEM_WREN   0x06
#define SMEM_RDSR   0x05
#define SMEM_WRSR   0x01

static byte _smemWrite(unsigned addr, byte datum);
static byte _smemReadArray(unsigned addr, char *arrayPtr, unsigned arraySize);
static byte _smemWriteArray(unsigned addr, char *arrayPtr, unsigned arraySize);
static byte _smemRead(unsigned addr);
//byte _spiWrite(byte datum);     // TODO static
static bool _smemBusy(void);
static byte _spi2WRBuffer(byte datum);


void smemWriteTest(void)
{
    const char testMsg[31] = "Home plate don't move.\r\n";
    //byte ch;

    //_smemWrite(0x50, testMsg[0]);
    _smemWriteArray(0x50, (byte *) testMsg, sizeof(testMsg));

}

void smemReadTest(void)
{
    _smemReadArray(0x50, ioBfr, 20);
    ioBfr[21] = 0;
    putStr(ioBfr);
}

    //
byte smemInit(void)
{

}

    // Called on startup and as factory setting restore of operating parms
void smemRestore(void)
{}

    // Called hourly as operating parm backup
void smemSave(void)
{}

    // TODO this one in doubt
byte _smemWrite(unsigned addr, byte datum)
{
    SMEM_CS_n = 0;
    delay_us(1);            
    _spi2WRBuffer(0x06);    // Write ena
    _spi2WRBuffer(0x02);    // Write instruction
    _spi2WRBuffer(addr >> 8);
    _spi2WRBuffer(addr);
    _spi2WRBuffer(datum);
    delay_us(1);
    _spi2WRBuffer(0x04);    // Write disa
    SMEM_CS_n = 1;
    return(1);
}

    // TODO byte *
byte _smemReadArray(unsigned addr, char *arrayPtr, unsigned arraySize)
{
    unsigned by;

    _smemBusy();        // Pause till free
    SMEM_CS_n = 0;
    _spi2WRBuffer(SMEM_READ);
    _spi2WRBuffer(addr >> 8);
    _spi2WRBuffer(addr);

    for (by = 0; by < arraySize; by++)
    {
        arrayPtr[by] = _spi2WRBuffer(SMEM_DUMMY);
    }
    SMEM_CS_n = 1;
    return(1);
}

byte _smemWriteArray(unsigned addr, char *arrayPtr, unsigned arraySize)
{
    unsigned by;
    _smemBusy();        // Pause till free
    SMEM_CS_n = 0;
    _spi2WRBuffer(SMEM_WREN);    //
    SMEM_CS_n = 1;
    delay_us(1);
    SMEM_CS_n = 0;
    _spi2WRBuffer(SMEM_WRITE);
    _spi2WRBuffer(addr >> 8);
    _spi2WRBuffer(addr);

    for (by = 0; by < arraySize; by++)
    {
        if ((addr + by) % 128 == 0 && by != 0)  // Hit 128 by page boundary
        {
            SMEM_CS_n = 1;
            _smemBusy();
            SMEM_CS_n = 0;
            _spi2WRBuffer(SMEM_WREN);
            SMEM_CS_n = 1;
            delay_us(1);
            SMEM_CS_n = 0;
            _spi2WRBuffer(SMEM_WRITE);
            _spi2WRBuffer((addr + by) >> 8);
            _spi2WRBuffer(addr + by);
        }
        _spi2WRBuffer(arrayPtr[by]);
    }
    SMEM_CS_n = 1;
    return(1);
}

    // TODO this one in doubt
byte _smemRead(unsigned addr)
{
    byte retVal;

    SMEM_CS_n = 0;
    delay_us(1);
    _spi2WRBuffer(0x03);    // Read instruction
    _spi2WRBuffer(addr >> 8);
    _spi2WRBuffer(addr);
    //while(!SPI2STATbits.SPIRBF) ;
    retVal = _spi2WRBuffer(0);
    SMEM_CS_n = 1;
    return(retVal);
}

//byte smemEraseAll(void)
//{
//    _smemBusy();
//
//    SMEM_CS_n = 0;
//    _spi2WRBuffer(0x06);
//    SMEM_CS_n = 1;
//    SMEM_CS_n = 0;
//    _spi2WRBuffer(0xC7);
//    SMEM_CS_n = 1;
//    return(1);
//}

//  TODO don't forget, msb first

//byte _spiWrite(byte datum)
//{
//    SPI2BUF = datum;
//   //while(SPI2STATbits.SPIBUSY) ;
//    return(1);
//}

    // TODO badly needs timeout
bool _smemBusy(void)
{
    byte status = 0;
    do
    {
        SMEM_CS_n = 0;
        _spi2WRBuffer(SMEM_RDSR);    // Read status reg
        status = _spi2WRBuffer(0);  // Test datum
        SMEM_CS_n = 1;
    } while (status & 0x01);

    return(false);
}

 byte _spi2WRBuffer(byte datum)
 {
     SPI2BUF = datum;
     while (!SPI2STATbits.SPIRBF) ;
     return (SPI2BUF);
 }
