/* File:   wifi.c
 * Author: Michael L Anderson
 * Contact: MichaelLAndersonEE@gmail.com
 * Platform: PIC32MX350F256H on DuraBlis-CCS-Main_v4 board
 * Created: 02 Oct 14
 */

#include <xc.h>
//#include <stdbool.h>
#include "durablisccsparent.h"
#include "wifi.h"

byte wifiIP[4] = { 0x01, 0x01, 0x10, 0x20 };
byte wifiMask[4] = { 0xFF, 0xFF, 0xFF, 0xFF };
bool wifiDHPC = false;