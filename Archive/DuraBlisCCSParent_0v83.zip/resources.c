/* File:   resources.c
 * Manages the matrix of needed control resoources versus parent / child owners
 * Author: Michael L Anderson
 * Contact: MichaelLAndersonEE@gmail.com
 * Platform: PIC32MX350F256H on DuraBlis-CCS-Main_v4 board.
 * LCD:  NHD NHD-C12864WC-FSW-FBW-3V3, 128 x 64 pixels
 * Created: 18 Sep14
 */

#include <xc.h>
//#include <stdbool.h>
#include "DuraBlisCCSParent.h"
#include "resources.h"

        //static const unsigned resourceParentK1 = 0x1000;       // Bit order in resourceMatrix
        //static const unsigned resourceParentK2 = 0x2000;
//bool resourceFloodSensor[NUM_CHILDREN];
//byte resourceExtTH;

    // Provide string description of resource for owner Ch, incl relay A|B.
    // resource is from resourceMatrix, eg resourceMatrix.heater
    // owner is child <1..8> or parent <0>
void resourceQuery(byte owner, char typeABFX, char *dest)
{
    unsigned long ulIdx = 1;
    unsigned idx = 1;

    strcpy(dest, "Free");
    if (owner == 0)     // Parent
    {
        if ((typeABFX == 'A') && (resourceMatrix.airConditioner & RES_ParA)) strcpy(dest, "Air Cond");
        else if ((typeABFX == 'B') && (resourceMatrix.heater & RES_ParB)) strcpy(dest, "Heater");
    }
    else
    {
        if (typeABFX == 'X')
        {
            if (owner == resourceMatrix.outsideTH) { strcpy(dest, "Exterior Sensor"); return; }
        }
        else if (typeABFX == 'F')
        {
            idx <<= (owner - 1);
            if (resourceMatrix.floodSensor & idx) { strcpy(dest, "Flood Sensor"); return; }
        }
        else if (typeABFX == 'A' || typeABFX == 'B')
        {
            if (typeABFX == 'A') ulIdx <<= 2 * (owner - 1);        // Based on RES_ bitfield
            else if (typeABFX == 'B') ulIdx <<= ((2 * (owner - 1)) + 1) ;

            if (resourceMatrix.airConditioner & ulIdx)      strcpy(dest, "Air Cond");
            else if (resourceMatrix.heater & ulIdx)         strcpy(dest, "Heater");
            else if (resourceMatrix.dehumidifier & ulIdx)   strcpy(dest, "Dehumid");
            else if (resourceMatrix.airExchanger & ulIdx)   strcpy(dest, "Air Exch");
            else if (resourceMatrix.humidifier & ulIdx)     strcpy(dest, "Humidif");
            else if (resourceMatrix.intFanTH & ulIdx)       strcpy(dest, "Int Fan");
        }
    }
}

    // Cycles through exclusive output options for child modules.  Child 1-based.
    // Returns true on success.
bool resourceKCycle(byte child, char relay, byte mode)
{
    unsigned long ulIdx = 1;

    if (relay == 'A') ulIdx <<= 2 * (child - 1);        // Based on RES_ bitfield
    else if (relay == 'B') ulIdx <<= ((2 * (child - 1)) + 1) ;
    else return(false);

    if (mode == RES_CYCLE_UP)
    {
        if (resourceMatrix.airConditioner & ulIdx) { resourceMatrix.airConditioner &= ~ulIdx; resourceMatrix.heater |= ulIdx; }
        else if (resourceMatrix.heater & ulIdx) { resourceMatrix.heater &= ~ulIdx; resourceMatrix.dehumidifier |= ulIdx; }
        else if (resourceMatrix.dehumidifier & ulIdx) { resourceMatrix.dehumidifier &= ~ulIdx; resourceMatrix.airExchanger |= ulIdx; }
        else if (resourceMatrix.airExchanger & ulIdx) { resourceMatrix.airExchanger &= ~ulIdx; resourceMatrix.humidifier |= ulIdx; }
        else if (resourceMatrix.humidifier & ulIdx) { resourceMatrix.humidifier &= ~ulIdx; resourceMatrix.intFanTH |= ulIdx; }
        else if (resourceMatrix.intFanTH & ulIdx) { resourceMatrix.intFanTH &= ~ulIdx; }            // Goto null case
        else if (!(resourceMatrix.intFanTH & ulIdx)) { resourceMatrix.airConditioner |= ulIdx; }    // Closes the cycle
    }
    else
    {
        if (resourceMatrix.airConditioner & ulIdx) { resourceMatrix.airConditioner &= ~ulIdx; resourceMatrix.intFanTH |= ulIdx; }
        else if (resourceMatrix.intFanTH & ulIdx) { resourceMatrix.intFanTH &= ~ulIdx; resourceMatrix.humidifier |= ulIdx; }
        else if (resourceMatrix.humidifier & ulIdx) { resourceMatrix.humidifier &= ~ulIdx; resourceMatrix.airExchanger |= ulIdx; }
        else if (resourceMatrix.airExchanger & ulIdx) { resourceMatrix.airExchanger &= ~ulIdx; resourceMatrix.dehumidifier |= ulIdx; }
        else if (resourceMatrix.dehumidifier & ulIdx) { resourceMatrix.dehumidifier &= ~ulIdx; resourceMatrix.heater |= ulIdx; }
        else if (resourceMatrix.heater & ulIdx) { resourceMatrix.heater &= ~ulIdx; }            // Goto null case
        else if (!(resourceMatrix.heater & ulIdx)) { resourceMatrix.airConditioner |= ulIdx; }    // Closes the cycle
    }
    return(true);
}


    // ------------------
void resourceInitialize(void)
{
//    resourceMatrix.heater = 0;
//    resourceMatrix.airConditioner = 0;        // Parent low-current thermostat K1 & K2 only for first two resources
//    resourceMatrix.dehumidifier = 0;
//    resourceMatrix.airExchanger = 0;
//    resourceMatrix.humidifier = 0;
//    resourceMatrix.intFanTH = 0;
//    resourceMatrix.outsideTH = 0;
//    resourceMatrix.floodSensor = 0;

        // Fake setup TODO
    resourceMatrix.heater = RES_ParB;
    resourceMatrix.airConditioner = RES_ParA;        // Parent low-current thermostat K1 & K2 only for first two resources
    resourceMatrix.dehumidifier = RES_Ch1A + RES_Ch2A;
    resourceMatrix.airExchanger = RES_Ch1B;
    resourceMatrix.humidifier = 0;
    resourceMatrix.intFanTH = 0;
    resourceMatrix.outsideTH = 1;
    resourceMatrix.floodSensor = 0x03;
}