/* File:        DuraBlisCCSParent.c  Main source file
 * Author:      Michael L Anderson
 * Contact:     MichaelLAndersonEE@gmail.com
 * Platform:    PIC32MX350F256H on BW-CCS-Main_v2 board
 * Created:     16 May 14
 * Timers:      T2 runs at Fclk = 25 MHz. 1 ct = 40 ns.
 * Interrupts:
 */

#define _SUPPRESS_PLIB_WARNING
    // Will need to migrate to Harmony
#include <xc.h>
#include <plib.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "configs.h"
#include "DuraBlisCCSParent.h"
#include "serial.h"
#include "adc.h"
#include "lcd.h"
#include "keypad.h"
#include "windows.h"
#include "time.h"
#include "buzzer.h"

byte bcd2byte(byte bcd);
byte byte2bcd(byte by);
//void buzzerControl(byte buzz, byte t_100ms);
void climateControl(void);
void editSetPoint(void);
void editTime(void);
//void evaluateResources(void);
void hardwareInit(void);
void ledControl(void);
void menuDisplay(void);
void monitorControl(void);
int pollChildren(void);
void reportInfo(void);
void systemInit(void);

struct ch_struct
{
    unsigned eqWord;
    unsigned status;
} child[NUM_CHILDREN];

double setPointTempF = 72.0;
double setPointRelHum = 45.0;   // All hums normalized to 100
double temperNowF, rhumidNow;
double temperCalFactor = 0.9388;    
double rhumidCalFactor = 1.3757;
double iSen[NUM_CHILDREN];
double iSenCalFactor [NUM_CHILDREN];
extern struct t_struct time;
bool t2Flag;

//unsigned process2Time_secs = 1;     // LED control
unsigned sysStat, sysStatOld;

////unsigned long t2Ctr;
//bool t2Flag = false;

char ioBfr[IO_BFR_SIZE + 1];

const char pnetCommProtocolVer = '1';
const char verStr[11] = "0.6";

char uniqueID[11] = "010814AAAA";

int main(void)
{
    extern byte splashScreen[]; //, mainScreen[];
    
    hardwareInit();
    lcdInit();
    lcdOnOff(1);
    lcdScreen(splashScreen);
    //lcdAllPointsOnOff(1);       // DEB
    systemInit();
//    putStr("\n\r DuraBlis CCS Monitor, v");
//    putStr(verStr);
//    putStr(", MLA");
//    menuDisplay();
//    putStr("\n\r > ");
    buzzerControl(BUZ_STARTUP, 30);
  //  extern byte *workScreen;
  //  lcdScreen(workScreen);

    //lcdScreen(mainScreen);
    while (1)
    {
        //lcdDataWrite(0x55);     // DEB
        fastTimer();         // TODO put this on intrpt
        ledControl();
        if (sysStat != sysStatOld)
            if (sysStat) buzzerControl(BUZ_STATUSBAD, 40);
            else buzzerControl(BUZ_CLEARSTATUS, 30);
         sysStatOld = sysStat;
         if (time.msec % 32 == 0) windowManager(keypad(KEYPAD_SILENT));


        if (time.process1Flag)    
        {
            adcTH(ADC_SILENT);
            pollChildren();     // TODO respond to errs
          // TODO  evaluateResources();
//            climateControl();

           
            time.process1Flag = false;
        }
        monitorControl();

            // Child emulation
//        if (sysStat & ST_CHILDMODE) childModeStMach(charCh);

    };      // EO while (1)
}
   
void monitorControl(void)
{
    char charCh;

    charCh = getChar();     // TODO funcitonalize this
    if (!charCh) return;
    putChar(charCh);
    if (charCh == '/')      // Super commands for Monitor
    {
        charCh = 0;
        while (!charCh)
        {
            charCh = getChar();
            if (!charCh) continue;
            putChar(charCh);
            switch(charCh)
            {
//                case 'C':
//                    sysStat ^= ST_CHILDMODE;
//                    if (sysStat & ST_CHILDMODE) putStr("\t*Child mode*\n\r");
//                    else putStr("\t*Parent mode*\n\r");
//                    putStr("\n\r > ");
//                    break;

                case 'r':
                    reportInfo();
                    break;

                case 'i':
                    adcCurrents(ADC_LOQUACIOUS);
                    break;

                case 'k':
                    keypad(KEYPAD_LOQUACIOUS);
                    break;

                case 's':
                    adcTH(ADC_LOQUACIOUS);
                    break;

                case 'S':
                    editSetPoint();
                    break;

                case 't':
                    timeRead(TIME_LOQUACIOUS);
                    break;

                case 'T':
                    editTime();
                    timeWrite();
                    break;

                case '1':
                    RELAY1 ^= 1;
                    if (RELAY1) putStr("\tRelay 1 on");
                    else putStr("\tRelay 1 off");
                    break;

                case '2':
                    RELAY2 ^= 1;
                    if (RELAY2) putStr("\tRelay 2 on");
                    else putStr("\tRelay 2 off");
                    break;

                case '?':
                    menuDisplay();
                    //putStr("\n\r > ");
                    break;
            }   // EO switch
            putPrompt();
        }       // EO while

       
    }           // EO if char
}

    /////////////////////
byte bcd2byte(byte bcd)
{
    byte retVal;

    if ((bcd & 0x0F) > 9) return(0xFE);
    else retVal = bcd & 0x0F;
    bcd >>= 4;
    if ((bcd & 0x0F) > 9) return(0xFF);
    else retVal += 10 * bcd;
    return(retVal);
}

    /////////////////////
byte byte2bcd(byte by)
{
    byte nibH, nibL, retVal;

    if (by > 99) return(0xFF);
    nibH = by / 10;
    nibL = by % 10;
    retVal = (nibH << 4) + nibL;
    return(retVal);
}

void ledControl(void)
{
    if (time.process2Flag)
    {
        if (sysStat)
        {
            LED_GREEN = 0;
            if (LED_RED) LED_RED = 0;
            else LED_RED = 1;
        }
        else
        {
            LED_RED = 0;
            if (LED_GREEN) LED_GREEN = 0;
            else LED_GREEN = 1;
        }

        time.process2Flag = false;
    }
}

    ////////////////////
void editSetPoint(void)
{
    double inDo;

    putStr("\tSetpoint temperature (oF): ");
    if (getStr(ioBfr, 11, TIMEOUT_HUMAN) < 1) return;
    inDo = atof(ioBfr);
    if (inDo < 50.0)
    {
        putStr("\tToo low");
        return;
    }
    if (inDo > 95.0)
    {
        putStr("\tToo high");
        return;
    }
    setPointTempF = inDo;

    putStr("\r\n\tRelative humidity (%): ");
    if (getStr(ioBfr, 11, TIMEOUT_HUMAN) < 1) return;
    inDo = atof(ioBfr);
    if (inDo < 10.0)
    {
        putStr("\tToo low");
        return;
    }
    if (inDo > 80.0)
    {
        putStr("\tToo high");
        return;
    }
    setPointRelHum = inDo;
    putStr("\r\n\tOkay");
}

    ////////////////////
void editTime(void)
{
    int inVal;

    putStr("\tMinute (0 - 59): ");
    if (getStr(ioBfr, 11, TIMEOUT_HUMAN) < 1) return;
    inVal = atoi(ioBfr);
    if (inVal < 0 || inVal > 59)
    {
        putStr("\tRange error");
        return;
    }
    time.minute = inVal;

    putStr("\n\r\tHour (0 - 23): ");
    if (getStr(ioBfr, 11, TIMEOUT_HUMAN) < 1) return;
    inVal = atoi(ioBfr);

    if (inVal < 0 || inVal > 23)
    {
        putStr("\tRange error");
        return;
    }
    time.hour = inVal;

    putStr("\n\r\tDay of month (1 - 31): ");
    if (getStr(ioBfr, 11, TIMEOUT_HUMAN) < 1) return;
    inVal = atoi(ioBfr);

    if (inVal < 1 || inVal > 31)
    {
        putStr("\tRange error");
        return;
    }
    time.dayMonth = inVal;

    putStr("\n\r\tMonth (1 - 12): ");
    if (getStr(ioBfr, 11, TIMEOUT_HUMAN) < 1) return;
    inVal = atoi(ioBfr);

    if (inVal < 1 || inVal > 12)
    {
        putStr("\tRange error");
        return;
    }
    time.month = inVal;

    putStr("\n\r\tYear (00 - 99): ");
    if (getStr(ioBfr, 11, TIMEOUT_HUMAN) < 1) return;
    inVal = atoi(ioBfr);

    if (inVal < 0 || inVal > 99)
    {
        putStr("\tRange error");
        return;
    }
    time.year = inVal;

    putStr("\n\r\tDay of week (0 Sun - 6 Sat): ");
    if (getStr(ioBfr, 11, TIMEOUT_HUMAN) < 1) return;
    inVal = atoi(ioBfr);

    if (inVal < 0 || inVal > 6)
    {
        putStr("\tRange error");
        return;
    }
    time.weekday = inVal;
    
    sysStat &= ~ST_CLOCKNOTSET;
    putStr("\r\n\tOkay");
}

    // ---------------------
    // Called minutely.
    //
void climateControl(void)
{

}

    // ---------------------
    // Called minutely after polling children.
    // Update resource table.
    //  TODO needs complete rework
//void evaluateResources(void)
//{
//    byte ch;
////    resource.airConditioner &= 0xFF00;      // Local resources in high byte
////    resource.heater &= 0xFF00;              // They are locally programmed
////
////    resource.airExchanger &= 0xFF00;
////    resource.dehumidifier &= 0xFF00;
////    resource.humidifier &= 0xFF00;
////    resource.intFanTH &= 0xFF00;
////    resource.outsideTH &= 0xFF00;
////    resource.liquidSensor &= 0xFF00;
////
////    for(ch = 0; ch < NUM_CHILDREN; ch++)
////    {
////        if (child[ch].eqWord & CHILD_EQPT_TH_OUTSIDE)
////            resource.outsideTH = (1 << ch);        // Can only be one. Highest gets priority
////        if (child[ch].eqWord & CHILD_EQPT_TH_INTFAN)
////            resource.intFanTH |= (1 << ch);
////        if ((child[ch].eqWord & CHILD_EQPT_DEHUM_K1) || (child[ch].eqWord & CHILD_EQPT_DEHUM_K2))
////            resource.dehumidifier |= (1 << ch);
////        if ((child[ch].eqWord & CHILD_EQPT_EXTFAN_K1) || (child[ch].eqWord & CHILD_EQPT_EXTFAN_K2))
////            resource.airExchanger |= (1 << ch);
////        if ((child[ch].eqWord & CHILD_EQPT_HUMIDIFIER_K1) || (child[ch].eqWord & CHILD_EQPT_HUMIDIFIER_K2))
////            resource.humidifier |= (1 << ch);
////        if (child[ch].eqWord & CHILD_EQPT_LIQUIDSENSOR)
////            resource.liquidSensor |= (1 << ch);
////    }
//
//}

void hardwareInit(void)
{
       // Configure the device for maximum performance, but do not change the PBDIV clock divisor.
        // Given the options, this function will change the program Flash wait states,
        // RAM wait state and enable prefetch cache, but will not change the PBDIV.
        // The PBDIV value is already set via the pragma FPBDIV option above.
    SYSTEMConfig(SYS_FREQ, SYS_CFG_WAIT_STATES | SYS_CFG_PCACHE);

    PORTSetPinsAnalogIn(IOPORT_B, BIT_15 | BIT_14 | BIT_9 | BIT_8 | BIT_7 | BIT_6 | BIT_5 | BIT_4);
        // Could also use mPORTDSetPinsDigitalOut(BIT_6 | BIT_7);
    PORTSetPinsDigitalOut(IOPORT_B, BIT_11 | BIT_3 | BIT_2);
    PORTSetPinsDigitalIn(IOPORT_B, BIT_13 | BIT_12 | BIT_10 | BIT_1 | BIT_0);

    PORTSetPinsDigitalOut(IOPORT_C, BIT_14);
    PORTSetPinsDigitalIn(IOPORT_C, BIT_13);

    PORTSetPinsAnalogIn(IOPORT_D, BIT_2 | BIT_1);
    PORTSetPinsDigitalOut(IOPORT_D, BIT_11 | BIT_10 | BIT_9 | BIT_8 | BIT_7 | BIT_6 | BIT_5 | BIT_4 |
        BIT_3 | BIT_0);     // D4..11 are LCD data port and used bidir

   //  PORTSetPinsAnalogIn(IOPORT_E, BIT_6 | BIT_5 | BIT_4 | BIT_2); // TODO CTMU
    PORTSetPinsDigitalOut(IOPORT_E, BIT_7 | BIT_3 | BIT_1 | BIT_0);
    PORTSetPinsDigitalIn(IOPORT_E, BIT_6 | BIT_5 | BIT_4 | BIT_2 );  // TODO not CTMU

    PORTSetPinsDigitalOut(IOPORT_F, BIT_6 | BIT_5 | BIT_4 | BIT_3 | BIT_1 | BIT_0);
    PORTSetPinsDigitalIn(IOPORT_F, BIT_2);

    PORTSetPinsDigitalOut(IOPORT_G, BIT_9 | BIT_8 | BIT_6 | BIT_3 | BIT_2);
    PORTSetPinsDigitalIn(IOPORT_G, BIT_7);

        // This is the waggle to set reprogrammable peripheral
        // Assume ints & DMA disa
    SYSKEY = 0xAA996655;
    SYSKEY = 0x556699AA;
    U1RXR = 0b1111;     // Selects RPF2 as RxD1 input
    RPF3R = 0b0011;     // Selects U1TX as TxD1 output
    RPF6R = 0b1100;     // Selects RPF6 as OC1 output, buzzer PWM
    SDI2R = 0b0001;     // Selects pin 5 as SDI (PICO)
    RPG8R = 0b0110;     // Selects pin 6 as SDO (POCI)
    RTCCONSET = 0b1000; // Turn on RTCC.RTCWREN.
    SYSKEY = 0x33333333;    // Junk relocks it

    OSCCONbits.SOSCEN = 1;
    OSCCONbits.SOSCRDY = 1;
        // Serial port on UART1
        // Note, Mode & Sta have atomic bit clr, set, & inv registers
    U1MODEbits.ON = 1;      // Ena UART1, per UEN, with UTXEN
    U1MODEbits.SIDL = 0;    // Continue oper in idle mode
    U1MODEbits.IREN = 0;    // Disa IrDA
    U1MODEbits.RTSMD = 1;   // U1RTS_n pin in simplex mode
    U1MODEbits.UEN = 0b00;  // U1CTS_n & U1RTS_n unused
    U1MODEbits.WAKE = 0;    // Disa wakeup
    U1MODEbits.LPBACK = 0;  // Disa loopback
    U1MODEbits.ABAUD = 0;   // Disa autobaud
    U1MODEbits.RXINV = 0;   // U1Rx idle is 1
    U1MODEbits.BRGH = 0;    // Std speed 16x, 1: high speed is 4x baud clk
    U1MODEbits.PDSEL = 0b00;    // 8 bit data, no parity
    U1MODEbits.STSEL = 0;   // 1 stop bit

    U1STAbits.ADM_EN = 0;   // Disa automatic address mode detect
    U1STAbits.UTXISEL = 0b01;   // Interrupt gen when all chars transmitted
    U1STAbits.UTXINV = 0;   // U1Tx idle is 1
    U1STAbits.URXEN = 1;    // Ena U1Rx
    U1STAbits.UTXBRK = 0;   // Disa Break (Start bit, then 12 0's, Stop)
    U1STAbits.UTXEN = 1;    // Ena U1Tx
    U1STAbits.URXISEL = 0b01;   // Interrupt flag asserted while buffer is 1/2 or more full
    U1STAbits.ADDEN = 0;    // Disa address mode

    U1BRG = 162;             // 80 for 19200 baud = PBCLK / (16 x (BRG + 1)), PBCLK = 25 MHz @ div / 1, Jitter 0.47%
                             // 162 for 9600 baud, 325 for 4800
    COMM_RX_ENA_n = 0;     
    COMM_SHDN_n = 1;

    AD1CON1bits.FORM = 0b000;   // Integer 16-bit, 10 lsb's
    AD1CON1bits.SSRC = 0b111;   // Internal ctr ends sampling and starte conver, auto.
    AD1CON1bits.ASAM = 1;       // Sampling begins immediately after last conversion completes; SAMP bit is automatically set
    AD1CON1bits.SAMP = 1;       // Ena sampling

    AD1CON2bits.VCFG = 0b000;   // Vdd & Vss are refs
    AD1CON2bits.OFFCAL = 0;     // Disa offset cal mode
    AD1CON2bits.CSCNA = 0;      // Disa scan the inputs
    AD1CON2bits.BUFM = 0;       // Buffer is one 16-bit word
    AD1CON2bits.ALTS = 0;       // Always use sample A input mux settings

    AD1CON3bits.ADRC = 1;       // ADC clk from FRC
    AD1CON3bits.SAMC = 0b00100; // 4 TAD autosample time

        // These don't matter if we scan.
    AD1CHSbits.CH0NB = 0;       // Sample B Ch 0 neg input is Vrefl
    AD1CHSbits.CH0SB = 0b00000; // Select B: AN0
    AD1CHSbits.CH0NA = 0;       // Sample A Ch 0 neg input is Vrefl
    AD1CHSbits.CH0SA = 0b00000; // Select B: AN0

    AD1CON1bits.ON = 1;         // This must be last step.

        // CTMU for capacitive keypad
    //CTMUCONbits.

        //  Real time clock 
    RTCCONbits.ON = 1;
    RTCCONbits.RTCOE = 0;   // Disa RTCC output

        // Buzzer PWM & ancillaries preliminary setup
        // buzzerControl() handles tones & durations
    INTEnableSystemMultiVectoredInt();  // Enable system wide interrupt to multivectored mode.
    T2CONSET = 0x8000;                  // Enable Timer2
    TMR2 = 1;                           // Clear register
    IFS0CLR = 0x00000100;               // Clear T2 int flag
    IEC0SET = 0x00000100;               // Ena T2 int
    IPC2SET = 0x0000001C;               // Set T2 int priority to 7
    
    // T1CONbits.TON = 1; TODO ??
    keypadInit();
}

void __ISR(_TIMER_2_VECTOR, IPL7AUTO) T2_IntHandler(void)
{
    static unsigned long t2Ctr;
    if (t2Ctr > 0) t2Ctr--;
    else { t2Flag = true; putChar('*'); t2Ctr = 100000; }

    IFS0CLR = 0x0100;
}

void menuDisplay(void)
{
    putStr("\n\r Use / for these commands\n\r");
    putStr(" b - buzzer test *\n\r");
    putStr(" [C - toggle parent / child mode]\n\r");
    putStr(" D - init NHD C12864 display * \n\r");
    putStr(" i - read channel currents\n\r");
    putStr(" k - keypad test\n\r");
    putStr(" K - calibrate constants * \n\r");
 //   putStr(" [L - assign local resources *]\n\r");
    putStr(" r - report basic info\n\r");
    putStr(" R - smem Read *\n\r");
    putStr(" s - read T & RH sensors\n\r");
    putStr(" S - set T & RH control point\n\r");
    putStr(" t - rtcc vals\n\r");
    putStr(" T - set rtcc Time\n\r");   
    putStr(" W - smem Write *\n\r");
    putStr(" Z - set fuzzy T & RH zone *\n\r");
    putStr(" 1 - toggle relay 1\n\r");
    putStr(" 2 - toggle relay 2\n\r");
    putStr(" ? - show this menu\n\r");   
}

    // ---------------------------
    // Called minutely to update
    // TODO: err if we lose a child that we had
int pollChildren(void)
{
    static byte nodeNum = 0;

//    sprintf(ioBfr, "[%02d] ", time.second);  // DEB
//    putStr(ioBfr);  // DEB

    if (++nodeNum > 8) nodeNum = 1;
    putChar('A');
    putChar('T');
    putChar(nodeNum + 48);
    putChar(13);
    putChar(10);

    //ioBfr[0] = nodeNum + '0';  // DEB
    if (getStr(ioBfr, IO_BFR_SIZE, TIMEOUT_HUMAN) < 1) return(0);     // No one there; end of story.
    //putStr(ioBfr);  // DEB
    if(ioBfr[0] != 'a') return (-1);     // Serial fail
  //  putChar('1'); // DEB
    if(ioBfr[1] != 'k') return (-1);     // Serial fail
   // putChar('2'); // DEB
    if(ioBfr[2] != nodeNum + '0') return (-2);           // Protocol fail
  //  putChar('3'); // DEB
    if(ioBfr[3] != pnetCommProtocolVer) return (-3);    // Version fail
  //  putChar('4'); // DEB
    if (parseHex3Byte(ioBfr[4], ioBfr[5], ioBfr[6], &child[nodeNum - 1].eqWord) < 0)
        return(-2);     // Protocol fail
 //   putChar('5'); // DEB
    if (child[nodeNum - 1].eqWord == 0) return(-6);     // EQ = 00 is invalid
 //   putChar('6'); // DEB
//    putStr("\n\r\tChild ");    // DEB
//    putChar(nodeNum + '0');
//    putStr(" has ");
//    putChar(pnetCommProtocolVer);   // DEB

        // TODO Poll status now

    return(nodeNum);              // Okay
}

 // --------------------------------
void reportInfo(void)
{
    byte ch;
   // char outBfr[31];

    putPrompt();
    putStr("\n\r DuraBlis CCS Monitor, v");
    putStr(verStr);
    putStr(", MLA\r\n");
    putStr("  * System info *");
    putStr("\n\r Firmware ver: ");
    putStr(verStr);
    putStr("\n\r PNet protocol ver: ");
    putChar(pnetCommProtocolVer);
    putStr("\n\r UID: ");
    putStr(uniqueID);
    putStr("\n\r System status: ");
    sprintf(ioBfr, "%04Xh", sysStat);
    putStr(ioBfr);
    putStr("\tK: ");
    if (RELAY1) putChar('+'); else putChar('-');
    if (RELAY2) putChar('+'); else putChar('-');
//    putStr("\n\r Mode: ");
//    putStr(sysStat & ST_CHILDMODE ? "Child" : "Parent");
//    if (sysStat & ST_CHILDMODE) childReportInfo();

    timeRead(TIME_UPDATE); 
    sprintf(ioBfr, "\n\r Time: %02d%s%02d-%02d:%02d:%02d.%03d\r\n",
        time.dayMonth, monStr[time.month - 1], time.year,
        time.hour, time.minute, time.second, time.msec);
    putStr(ioBfr);
    adcTH(ADC_SILENT);
    putStr("\n\r Temp now: ");
    sprintf(ioBfr, "%3.02f oF [%5.04f]", temperNowF, temperCalFactor);
    putStr(ioBfr);

    putStr("\n\r RH now: ");
    sprintf(ioBfr, "%3.02f %% [%5.04f]", rhumidNow, rhumidCalFactor);
    putStr(ioBfr);

    putStr("\n\r Setpoint: ");
    sprintf(ioBfr, "%2.1f oF, %2.1f %%RH", setPointTempF, setPointRelHum);
    putStr(ioBfr);

//    putStr("\n\n\r Air con: ");
//    sprintf(ioBfr, "%04X", resourceMatrix.airConditioner);
//    putStr(ioBfr);
//    putStr("\n\r Air exch: ");
//    sprintf(ioBfr, "%04X", resourceMatrix.airExchanger);
//    putStr(ioBfr);
//    putStr("\n\r Dehum: ");
//    sprintf(ioBfr, "%04X", resourceMatrix.dehumidifier);
//    putStr(ioBfr);
//    putStr("\n\r Heater: ");
//    sprintf(ioBfr, "%04X", resourceMatrix.heater);
//    putStr(ioBfr);
//    putStr("\n\r Int fan TH: ");
//    sprintf(ioBfr, "%04X", resourceMatrix.intFanTH);
//    putStr(ioBfr);
//    putStr("\n\r Ext sen TH: ");
//    sprintf(ioBfr, "%04X", resourceMatrix.outsideTH);
//    putStr(ioBfr);
                    //    putStr("\n\r Liquid sen: ");
                    //    sprintf(ioBfr, "%04X", resourceMatrix.liquidSensor);  TODO
    putStr(ioBfr);
    putStr("\n\r");
}

    // --------------------------------
void systemInit(void)
{
    byte ch;

    sysStatOld = sysStat = ST_CLOCKNOTSET;
//    time.msec = 0;
//    time.second = 0;
//    time.minute = 0;
//    time.hour = 0;
//    time.dayMonth = 10;
//    time.weekday = 2;
//    time.month = 0;
//    time.year = 14;
//    timeWrite();

    for (ch = 0; ch < NUM_CHILDREN; ch++)
        iSenCalFactor [ch] = 1.0;
}

