/* File:   resources.c
 * Manages the matrix of needed control resoources versus parent / child owners
 * Author: Michael L Anderson
 * Contact: MichaelLAndersonEE@gmail.com
 * Platform: PIC32MX350F256H on DuraBlis-CCS-Main_v4 board.
 * LCD:  NHD NHD-C12864WC-FSW-FBW-3V3, 128 x 64 pixels
 * Created: 18 Sep14
 */

#include <xc.h>
#include <stdbool.h>
#include "DuraBlisCCSParent.h"
#include "resources.h"

static const unsigned resourceParentK1 = 0x1000;       // Bit order in resourceMatrix
static const unsigned resourceParentK2 = 0x2000;
bool resourceFloodSensor[NUM_CHILDREN];

    // resource is from resourceMatrix, eg resourceMatrix.heater
    // owner is child <1..8> or parent <0>
    // Returns 0x01 for relay K1 | 0x02 for relay K2 | 0x04 for extra (eg exterior
    // TH sensor). 0x00 for null vector. 0xF0 for error.
byte resourceQuery(unsigned *resource, byte owner)
{
    byte retVal = 0, bitField;

    if (*resource == resourceMatrix.heater)
    {
        if (owner == 0)     // Parent
        {
            if (resourceMatrix.heater & resourceParentK1) retVal |= 0x01;
            if (resourceMatrix.heater & resourceParentK2) retVal |= 0x02;
        }
        else
        {
            bitField = (resourceMatrix.heater & 0x0F00) >> 8;
            if (bitField == owner) retVal |= 0x01;      // 'Child c has heater on K1'
            bitField = (resourceMatrix.heater & 0x00F0) >> 4;
            if (bitField == owner) retVal |= 0x02;
        }
    }
    else if (*resource == resourceMatrix.airConditioner)
    {
        if (owner == 0)     // Parent
        {
            if (resourceMatrix.airConditioner & resourceParentK1) retVal |= 0x01;
            if (resourceMatrix.airConditioner & resourceParentK2) retVal |= 0x02;
        }
        else
        {
            bitField = (resourceMatrix.airConditioner & 0x0F00) >> 8;
            if (bitField == owner) retVal |= 0x01;
            bitField = (resourceMatrix.airConditioner & 0x00F0) >> 4;
            if (bitField == owner) retVal |= 0x02;
        }
    }                   // A parent cannot have further resources. The require large relays
    else if (*resource == resourceMatrix.dehumidifier)
    {
        bitField = (resourceMatrix.dehumidifier & 0x0F00) >> 8;
        if (bitField == owner) retVal |= 0x01;
        bitField = (resourceMatrix.dehumidifier & 0x00F0) >> 4;
        if (bitField == owner) retVal |= 0x02;
    }
    else if (*resource == resourceMatrix.airExchanger)
    {
        bitField = (resourceMatrix.airExchanger & 0x0F00) >> 8;
        if (bitField == owner) retVal |= 0x01;
        bitField = (resourceMatrix.airExchanger & 0x00F0) >> 4;
        if (bitField == owner) retVal |= 0x02;
    }
    else if (*resource == resourceMatrix.humidifier)
    {
        bitField = (resourceMatrix.humidifier & 0x0F00) >> 8;
        if (bitField == owner) retVal |= 0x01;
        bitField = (resourceMatrix.humidifier & 0x00F0) >> 4;
        if (bitField == owner) retVal |= 0x02;
    }
    else if (*resource == resourceMatrix.intFanTH)
    {
        bitField = (resourceMatrix.intFanTH & 0x0F00) >> 8;
        if (bitField == owner) retVal |= 0x01;
        bitField = (resourceMatrix.intFanTH & 0x00F0) >> 4;
        if (bitField == owner) retVal |= 0x02;
    }
    else if (*resource == resourceMatrix.outsideTH)
    {
        bitField = (resourceMatrix.outsideTH & 0x000F);     // Note different position
        if (bitField == owner) retVal |= 0x04;
    }

}

    // Signals successful change
    //  TODO is this a good place to program remote children?
    // -------------------------------
bool resourceChange(unsigned *resource, byte owner, byte relay, bool enable)
{
    unsigned bitField;

    if ((owner > NUM_CHILDREN) || (relay > 2)) return(false);

    if (*resource == resourceMatrix.heater)
    {
        if (owner == 0)     // Parent
        {
            if (relay == 1)
            {
                if (enable) resourceMatrix.heater |= resourceParentK1;
                else resourceMatrix.heater &= ~resourceParentK1;
            }
            else
            {
                if (enable) resourceMatrix.heater |= resourceParentK2;
                else resourceMatrix.heater &= ~resourceParentK2;
            }
        }
        else
        {
            if (relay == 1)
            {
                bitField = owner;
                bitField <<= 8;
                if (enable) resourceMatrix.heater |= bitField;
                else resourceMatrix.heater &= ~bitField;
            }
            else
            {
                bitField = owner;
                bitField <<= 4;
                if (enable) resourceMatrix.heater |= bitField;
                else resourceMatrix.heater &= ~bitField;
            }
        }

    }
    else if (*resource == resourceMatrix.airConditioner)
    {
        if (owner == 0)     // Parent
        {
            if (relay == 1)
            {
                if (enable) resourceMatrix.airConditioner |= resourceParentK1;
                else resourceMatrix.airConditioner &= ~resourceParentK1;
            }
            else
            {
                if (enable) resourceMatrix.airConditioner |= resourceParentK2;
                else resourceMatrix.airConditioner &= ~resourceParentK2;
            }
        }
        else
        {
            if (relay == 1)
            {
                bitField = owner;
                bitField <<= 8;
                if (enable) resourceMatrix.airConditioner |= bitField;
                else resourceMatrix.airConditioner &= ~bitField;
            }
            else
            {
                bitField = owner;
                bitField <<= 4;
                if (enable) resourceMatrix.airConditioner |= bitField;
                else resourceMatrix.airConditioner &= ~bitField;
            }
        }

    }
    else if (*resource == resourceMatrix.dehumidifier)
    {
        if (owner == 0) return(false);      // Parent

        if (relay == 1)
        {
            bitField = owner;
            bitField <<= 8;
            if (enable) resourceMatrix.dehumidifier |= bitField;
            else resourceMatrix.dehumidifier &= ~bitField;
        }
        else            // Must be relay #2
        {
            bitField = owner;
            bitField <<= 4;
            if (enable) resourceMatrix.dehumidifier |= bitField;
            else resourceMatrix.dehumidifier &= ~bitField;
        }
    }
    else if (*resource == resourceMatrix.airExchanger)
    {
        if (owner == 0) return(false);      // Parent can't have

        if (relay == 1)
        {
            bitField = owner;
            bitField <<= 8;
            if (enable) resourceMatrix.airExchanger |= bitField;
            else resourceMatrix.airExchanger &= ~bitField;
        }
        else            // Must be relay #2
        {
            bitField = owner;
            bitField <<= 4;
            if (enable) resourceMatrix.airExchanger |= bitField;
            else resourceMatrix.airExchanger &= ~bitField;
        }
    }
    else if (*resource == resourceMatrix.humidifier)
    {
        if (owner == 0) return(false);      // Parent can't have

        if (relay == 1)
        {
            bitField = owner;
            bitField <<= 8;
            if (enable) resourceMatrix.humidifier |= bitField;
            else resourceMatrix.humidifier &= ~bitField;
        }
        else            // Must be relay #2
        {
            bitField = owner;
            bitField <<= 4;
            if (enable) resourceMatrix.humidifier |= bitField;
            else resourceMatrix.humidifier &= ~bitField;
        }
    }
    else if (*resource == resourceMatrix.intFanTH)
    {
        if (owner == 0) return(false);      // Parent can't have

        if (relay == 1)
        {
            bitField = owner;
            bitField <<= 8;
            if (enable) resourceMatrix.intFanTH |= bitField;
            else resourceMatrix.intFanTH &= ~bitField;
        }
        else            // Must be relay #2
        {
            bitField = owner;
            bitField <<= 4;
            if (enable) resourceMatrix.intFanTH |= bitField;
            else resourceMatrix.intFanTH &= ~bitField;
        }
    }
    else if (*resource == resourceMatrix.outsideTH)
    {
        if (owner == 0) return(false);      // Parent can't have
        bitField = owner;
        if (enable) resourceMatrix.outsideTH |= bitField;
        else resourceMatrix.outsideTH &= ~bitField;
    }
    return(true);
}