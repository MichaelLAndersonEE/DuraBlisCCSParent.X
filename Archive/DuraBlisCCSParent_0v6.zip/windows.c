/* File:   windows.c user IO objects
 * Author: Michael L Anderson
 * Contact: MichaelLAndersonEE@gmail.com
 * Platform: PIC32MX350F256H on DuraBlis-CCS-Main_v4 board.
 * LCD:  NHD NHD-C12864WC-FSW-FBW-3V3, 128 x 64 pixels
 * Created: 18 Sep14
 */

#include <xc.h>
#include <stdbool.h>
#include "DuraBlisCCSParent.h"
#include "lcd.h"
#include "time.h"
#include "keypad.h"
#include "resources.h"

    // Window states  // TODO move to .h
    // TODO needed:  calibration consts, sysinfo
#define WIN_MAIN                 0
#define WIN_SET1                 1
#define WIN_SET2                 2
#define WIN_CZ                   3
#define WIN_SET_CZ_T             4
#define WIN_SET_CZ_RH            5
#define WIN_CONFIG               6
#define WIN_SET_HVAC             7
#define WIN_SET_TIME             8
//#define WIN_ASSIGN_NODES         9
#define WIN_SET_CHILDREN        10
#define WIN_UNITS               11
#define WIN_SET_UNITS_TEMP      12
#define WIN_SET_UNITS_HUMID     13
#define WIN_SYSINFO             14
#define WIN_WIFI                15
#define WIN_SET_WIFI_MAC        16
#define WIN_SET_WIFI_IP         17

#define SET_TEMP_MAX        95
#define SET_TEMP_MIN        60
#define SET_RH_MAX          75
#define SET_RH_MIN          30

char bfr2[11];
static void windowMain(void);
static void windowHVAC(char keyIn);
static void windowSetTime(char keyIn);
static void windowComfortZone(byte keyIn);
static void windowSetChildren(char keyIn);
static void windowModifyChild(byte child);
static byte windowState;    // State machine index
static byte field;      // Index into fields in a given state
static byte child = 1;
struct t_struct timeBuffer;
extern struct t_struct time;
extern bool resourceFloodSensor[NUM_CHILDREN];

    // State machine manager
void windowManager(byte keyIn)
{
    static byte windowStateOld = 0xFF;       // State machine index buffer
    //static double parameter;    // Some parameter to be edited
    extern byte mainScreen[];
   
    
    if (windowState != windowStateOld)  // This erases previous content
    {
        lcdScreen(mainScreen);
        windowStateOld = windowState;
        sprintf(ioBfr, "\tSt %d\r\n", windowStateOld);    // DEB
        putStr(ioBfr);      // DEB
    }

    switch(windowState)
    {
        case WIN_MAIN:
            windowMain();
            if (keyIn & KEY_D) windowState = WIN_SET1;
            break;

        case WIN_SET1:
            lcdCenter(7, "Setup 1");
            lcdSoftkeys1("Com-", "Set", "Con-", "More");
            lcdSoftkeys0(" fort", " Time", " fig", "");
            if (keyIn & KEY_A) windowState = WIN_CZ;
            else if (keyIn & KEY_B)
            {
                windowState = WIN_SET_TIME;
                timeBuffer = time;
                if (timeBuffer.month == 0)      // Need valid values for formatted string
                {
                    timeBuffer.dayMonth = 10;
                    timeBuffer.month = 11;
                    timeBuffer.year = 75;
                }
            }
            else if (keyIn & KEY_C) windowState = WIN_CONFIG;
            else if (keyIn & KEY_D) windowState = WIN_SET2;
            break;

        case WIN_SET2:
            lcdCenter(7, "Setup 2");
            lcdSoftkeys1("Units", "Sys", "Set", "Esc");
            lcdSoftkeys0("", "Info", " WiFi", "");
            if (keyIn & KEY_A) windowState = WIN_UNITS;
            else if (keyIn & KEY_B) windowState = WIN_SYSINFO;
            else if (keyIn & KEY_C) windowState = WIN_WIFI;
            else if (keyIn & KEY_D) windowState = WIN_MAIN;
            break;

        case WIN_CZ:
            windowComfortZone(keyIn);
            break;

        case WIN_CONFIG:
            lcdCenter(7, "Configure Resources");
            lcdUpDnEnEs();
            strcpy(ioBfr, "Setup Children");
            if (field == 0) lcdStrAt(4, 116, "<");
            else strcat(ioBfr, "    ");
            lcdStrAt(4, 4, ioBfr);

            strcpy(ioBfr, "Setup HVAC");
            if (field == 1) lcdStrAt(3, 116, "<");
            else strcat(ioBfr, "    ");
            lcdStrAt(3, 4, ioBfr);

            if (keyIn & (KEY_A | KEY_B))
            {
                if (field == 0)
                {
                    field = 1;
                    lcdStrAt(4, 116, " ");
                }
                else
                {
                    field = 0;
                    lcdStrAt(3, 116, " ");
                }
            }
            else if (keyIn & KEY_C)
            {
                if (field == 0)
                {
                    windowState = WIN_SET_CHILDREN;
                }
                else
                {
                    windowState = WIN_SET_HVAC;
                    field = 0;
                }
            }
            else if (keyIn & KEY_D) windowState = WIN_SET1;
            break;

        case WIN_SET_HVAC:
            windowHVAC(keyIn);
            break;

        case WIN_SET_TIME:
            windowSetTime(keyIn);
            break;

        case WIN_SET_CHILDREN:
            windowSetChildren(keyIn);
            break;

        case WIN_UNITS:     // TODO just a stub
            lcdCenter(7, "Select Units");
            lcdSoftkeys1("", "", "", "Esc");
            if (keyIn) windowState = WIN_MAIN;
            break;

        case WIN_SYSINFO:   // TODO just a stub
            lcdCenter(7, "System Info");
            lcdSoftkeys1("", "", "", "Esc");
            if (keyIn) windowState = WIN_MAIN;
            break;

        case WIN_WIFI:      // TODO just a stub
            lcdCenter(7, "Setup WiFi");
            lcdSoftkeys1("", "", "", "Esc");
            if (keyIn) windowState = WIN_MAIN;
            break;
    }
}

    // ---------------------------------------
void windowMain(void)
{   
    extern double temperNowF, rhumidNow;   
    extern double setPointRelHum;   // All relhums normalized to 100

    lcdCenter(7, "DuraBlis");
    lcdCenter(6, "Climate Control");

    timeRead(TIME_UPDATE);
    if (time.month == 0) strcpy(ioBfr, "Time: not set");
    else
        sprintf(ioBfr, "%02d %s %02d - %02d:%02d%s",
            timeBuffer.dayMonth, monStr[time.month-1], time.year, (time.hour % 12) + 1, time.minute, time.hour > 11 ? "pm" : "am" );
    lcdStrAt(5, 4, ioBfr);

    strcpy(ioBfr, "Temperature: ");
    if (temperNowF == 0.0) strcat(ioBfr, "WAIT");
    else
    {
        sprintf(bfr2, "%2.01f[F", temperNowF);
        strcat(ioBfr, bfr2);
    }
    lcdStrAt(4, 4, ioBfr);

    strcpy(ioBfr, "Status: ");
    if (rhumidNow > 1.15 * setPointRelHum) strcpy(bfr2, "Damp       ");
    else if (rhumidNow < 0.85 * setPointRelHum) strcpy(bfr2, "Dry        ");
    else if (rhumidNow = 0.0) strcpy(bfr2, "WAIT");
    else strcpy(bfr2, "Comfortable");         // TODO not quite right. Temp could still be way off
    strcat(ioBfr, bfr2);
    lcdStrAt(3, 4, ioBfr);

    lcdSoftkeys1("", "", "", "Setup");
}

    // ---------------------------------------
    // TODO use resourceQuery() Assign()
void windowHVAC(char keyIn)
{   
    lcdCenter(7, "Setup Parent HVAC");
    lcdUpDnEnEs();
    strcpy(ioBfr, "Switch 1: ");
    if (resourceQuery((unsigned *) resourceMatrix.heater, 0) & 0x01) strcat(ioBfr, "Heater");
    else if (resourceQuery((unsigned *) resourceMatrix.airConditioner, 0) & 0x01) strcat(ioBfr, "Air Cond");
    else strcat(ioBfr, "Free");
    if (field == 0)
    {
        lcdStrAt(4, 116, "<");
        lcdSoftkeys1("Sw 2", "Chan", "", "");
        lcdSoftkeys0("", " ge", "", "");
    }
    else strcat(ioBfr, "    ");
    lcdStrAt(4, 4, ioBfr);
    strcpy(ioBfr, "Switch 2: ");
    if (resourceQuery((unsigned *) resourceMatrix.heater, 0) & 0x02) strcat(ioBfr, "Heater");
    else if (resourceQuery((unsigned *) resourceMatrix.airConditioner, 0) & 0x02) strcat(ioBfr, "Air Cond");
    else strcat(ioBfr, "Free");
    if (field == 1)
    {
        lcdStrAt(3, 116, "<");
        lcdSoftkeys1("Sw 1", "Chan", "", "");
        lcdSoftkeys0("", " ge", "", "");
    }
    else strcat(ioBfr, "    ");
    lcdStrAt(3, 4, ioBfr);

    if (keyIn & KEY_A)
    {
        if (field == 0) field = 1; else field = 0;
    }
    else if (keyIn & KEY_B)
    {
        if (field == 0)
        {
            if (resourceQuery((unsigned *) resourceMatrix.heater, 0) & 0x01)
            {
                resourceChange((unsigned *) resourceMatrix.heater, 0, 1, false);
                resourceChange((unsigned *) resourceMatrix.airConditioner, 0, 1, true);
            }

            // TODO TODO TODO
//            if (resourceMatrix.heater & PARENT_EQPT_K1)
//            {
//                resourceMatrix.heater &= ~PARENT_EQPT_K1;
//                resourceMatrix.airConditioner |= PARENT_EQPT_K1;
//            }
//            else if (resourceMatrix.airConditioner & PARENT_EQPT_K1)
//            {
//                resourceMatrix.airConditioner &= ~PARENT_EQPT_K1;
//            }
//            else resourceMatrix.heater |= PARENT_EQPT_K1;
        }
        else
        {
            /// TODO TODO
//            if (resourceMatrix.heater & PARENT_EQPT_K2)
//            {
//                resourceMatrix.heater &= ~PARENT_EQPT_K2;
//                resourceMatrix.airConditioner |= PARENT_EQPT_K2;
//            }
//            else if (resourceMatrix.airConditioner & PARENT_EQPT_K2)
//            {
//                resourceMatrix.airConditioner &= ~PARENT_EQPT_K2;
//            }
//            else resourceMatrix.heater |= PARENT_EQPT_K2;
        }
    }
    else if (keyIn & KEY_C)
    {
        if (field == 0) field++;
        else
        {
            field = 0;
            windowState = WIN_SET1;
        }
    }
    else if (keyIn & KEY_D)     // TODO buffer for
    {
        windowState = WIN_SET1;
        field = 0;
    }
}

    // 0-0--0----1--1--1-
    // 0-2--5----0--3--6-
    // 10Nov14 - 05:55am
void windowSetTime(char keyIn)
{
    lcdCenter(7, "Set Date & Time");
    lcdUpDnEnEs();
    sprintf(ioBfr, "%02d %s %02d - %02d:%02d%s",
        timeBuffer.dayMonth, monStr[timeBuffer.month-1], timeBuffer.year, (timeBuffer.hour % 12) + 1, timeBuffer.minute, timeBuffer.hour > 11 ? "pm" : "am" );
    lcdStrAt(4, 4, ioBfr);
    if (field == 0) lcdStrAt(3, 4, "^^");
    else if (field == 1) { lcdStrAt(3, 4, "  "); lcdStrAt(3, 22, "^^^"); }
    else if (field == 2) { lcdStrAt(3, 22, "   "); lcdStrAt(3, 46, "^^"); }
    else if (field == 3) { lcdStrAt(3, 46, "  "); lcdStrAt(3, 76, "^^"); }
    else if (field == 4) { lcdStrAt(3, 76, "  "); lcdStrAt(3, 94, "^^"); }
    else { field = 5; lcdStrAt(3, 94, "  "); lcdStrAt(3, 112, "^^"); }

    if (keyIn & KEY_A)
    {
        switch(field)
        {
            case 0:
                if (timeBuffer.dayMonth < daysInMonth(timeBuffer.month, timeBuffer.year)) timeBuffer.dayMonth++;       // TODO Do reality check final date
                else timeBuffer.dayMonth = 1;
                break;
            case 1:
                if (timeBuffer.month < 12) timeBuffer.month++;
                else timeBuffer.month = 1;
                break;
            case 2:
                if (timeBuffer.year < 99) timeBuffer.year++;
                else timeBuffer.year = 0;
                break;
            case 3:
                if (timeBuffer.hour < 23) timeBuffer.hour++;
                else timeBuffer.hour = 0;
                break;
            case 4:
                if (timeBuffer.minute < 59) timeBuffer.minute++;
                else timeBuffer.minute = 0;
                break;
        }
    }
    else if (keyIn & KEY_B)
    {
        switch(field)
        {
            case 0:
                if (timeBuffer.dayMonth > 1) timeBuffer.dayMonth--;
                else timeBuffer.dayMonth = daysInMonth(timeBuffer.month, timeBuffer.year);
                break;
            case 1:
                if (timeBuffer.month > 1) timeBuffer.month--;
                else timeBuffer.month = 12;
                break;
            case 2:
                if (timeBuffer.year > 0) timeBuffer.year--;
                else timeBuffer.year = 99;
                break;
            case 3:
                if (timeBuffer.hour > 0) timeBuffer.hour--;
                else timeBuffer.hour = 23;
                break;
            case 4:
                if (timeBuffer.minute > 0) timeBuffer.minute--;
                else timeBuffer.minute = 59;
                break;
        }
    }
    else if (keyIn & KEY_C)
    {
        time = timeBuffer;
        timeWrite();
        if (field < 4) field++;
        else
        {
            windowState = WIN_SET1;
            field = 0;
        }
    }
    else if (keyIn & KEY_D)     
    {
        windowState = WIN_SET1;
        field = 0;
    }
}

    // ------------------
void windowComfortZone(byte keyIn)
{
    extern double setPointTempF, setPointRelHum;
    lcdCenter(7, "Comfort Zone");
    lcdUpDnEnEs();
    strcpy(ioBfr, "Temperature: ");
    sprintf(bfr2, "%2.0f[F", setPointTempF);
    strcat(ioBfr, bfr2);
    if (field == 0) strcat(ioBfr, " <");
    else strcat(ioBfr, "    ");
    lcdStrAt(4, 4, ioBfr);

    strcpy(ioBfr, "Rel humidity: ");
    sprintf(bfr2, "%2.0f%%", setPointRelHum);
    strcat(ioBfr, bfr2);
    if (field == 1) strcat(ioBfr, " <");
    else strcat(ioBfr, "    ");
    lcdStrAt(3, 4, ioBfr);

    if (keyIn & KEY_A)
    {
        if (field == 0)
        {
            if (setPointTempF < SET_TEMP_MAX) setPointTempF += 1;
            else setPointTempF = SET_TEMP_MIN;
        }
        else
        {
            if (setPointRelHum < SET_RH_MAX) setPointRelHum += 1;
            else setPointRelHum = SET_RH_MIN;
        }
    }

    else if (keyIn & KEY_B)
    {
        if (field == 0)
        {
            if (setPointTempF > SET_TEMP_MIN) setPointTempF -= 1;
            else setPointTempF = SET_TEMP_MAX;       
        }
        else
        {
            if (setPointRelHum > SET_RH_MIN) setPointRelHum -= 1;
            else setPointRelHum = SET_RH_MAX;
        }
    }

    else if (keyIn & KEY_C)
    {
        if (field == 0) field = 1;
        else
        {
            field = 0;
            windowState = WIN_SET1;
        }
    }

    else if (keyIn & KEY_D)
    {
        field = 0;
        windowState = WIN_SET1;
    }
}
          
    // --------------------------
    // child is 1-idx'd, 0 used for parent
void windowSetChildren(char keyIn)
{
    lcdCenter(7, "Setup Children");
    lcdUpDnEnEs();
    strcpy(ioBfr, "Child ");
    sprintf(bfr2, "%d", child);
    strcat(ioBfr, bfr2);
    lcdStrAt(6, 4, ioBfr);
    strcpy(ioBfr, "Rly 1: ");
    if (resourceQuery((unsigned *) resourceMatrix.heater, child) & 0x01) strcat(ioBfr, "Heater");
    else if (resourceQuery((unsigned *) resourceMatrix.airConditioner, child) & 0x01) strcat(ioBfr, "Air Cond'r");
    else if (resourceQuery((unsigned *) resourceMatrix.dehumidifier, child) & 0x01) strcat(ioBfr, "Dehumid'r");
    else if (resourceQuery((unsigned *) resourceMatrix.airExchanger, child) & 0x01) strcat(ioBfr, "Air Exchg'r");
    else if (resourceQuery((unsigned *) resourceMatrix.humidifier, child) & 0x01) strcat(ioBfr, "Humidifier");
    else if (resourceQuery((unsigned *) resourceMatrix.intFanTH, child) & 0x01) strcat(ioBfr, "Internal Fan");
    else strcat(ioBfr, "Free");
    lcdStrAt(5, 4, ioBfr);

    strcpy(ioBfr, "Rly 2: ");
    if (resourceQuery((unsigned *) resourceMatrix.heater, child) & 0x02) strcat(ioBfr, "Heater");
    else if (resourceQuery((unsigned *) resourceMatrix.airConditioner, child) & 0x02) strcat(ioBfr, "Air Cond'r");
    else if (resourceQuery((unsigned *) resourceMatrix.dehumidifier, child) & 0x02) strcat(ioBfr, "Dehumid'r");
    else if (resourceQuery((unsigned *) resourceMatrix.airExchanger, child) & 0x02) strcat(ioBfr, "Air Exchg'r");
    else if (resourceQuery((unsigned *) resourceMatrix.humidifier, child) & 0x02) strcat(ioBfr, "Humidifier");
    else if (resourceQuery((unsigned *) resourceMatrix.intFanTH, child) & 0x02) strcat(ioBfr, "Internal Fan");
    else strcat(ioBfr, "Free");
    lcdStrAt(4, 4, ioBfr);

    strcpy(ioBfr, "Extra:");
    strcat(ioBfr, " None");
    if (resourceQuery((unsigned *) resourceMatrix.outsideTH, child) & 0x04) strcat(ioBfr, " Outside TH");
    if (resourceFloodSensor[child]) strcat(ioBfr, " Flood Sen");
    lcdStrAt(3, 4, ioBfr);

    if (keyIn & KEY_A)
    {
        if (child < NUM_CHILDREN) child++; else child = 1;
    }
    else if (keyIn & KEY_B)
    {
        if (child > 1) child--; else child = NUM_CHILDREN;
    }
    else if (keyIn & KEY_C)
    {
        windowModifyChild(child);
    }
    else if (keyIn & KEY_D)     
    {
        windowState = WIN_SET1;
        field = 0;
    }
}

    // ------------------------------------
void windowModifyChild(byte child)
{

}