/* File:   BW-CCS.h  Project wide defines and global variables
 * Author: Michael L Anderson
 * Contact: MichaelLAndersonEE@gmail.com
 * Platform: PIC32MX350F256H on BW-CCS-Main_v2 board
 * Created: 16 May 14
 */

#ifndef DURABLISCCSPARENT_H
#define	DURABLISCCSPARENT_H

#include <stdbool.h>    // To use bool type throughout

#define SET_TEMP_MAX        95
#define SET_TEMP_MIN        55
#define SET_RH_MAX          80
#define SET_RH_MIN          25
#define CAL_FACTOR_MAX      1.6
#define CAL_FACTOR_MIN      0.4

    //  Primary external osc freq
#define SYS_FREQ	(25000000)
#define IO_BFR_SIZE     65          // Volatile general purpose IO buffer
#define NUM_CHILDREN    8
#define UID_SIZE        11          // Number chars including ASCII-0 in Unique Identifier

  // This is awkward, but need to keep these packaged for SEEPROM
struct operatingParms_struct
{
    unsigned sysStat;           // [2 bytes]
    unsigned dlRecordsSaved;    // [2]
    double setPointTempF;       // [4]
    double setPointRelHum;      // [4] All hums normalized to 100
    double temperCalFactor;     // [4] For Fahrenheit
    double rhumidCalFactor;     // [4]
    double kpadSensit[4];       // [16]
    char uniqueID[UID_SIZE];    // [12] Ostensibly, mmddyy and 4-alpha serial num
};

    // Parent sysFault bits  TODO review set & clr
    // These may be cleared by user in Main window, or in pwr cycle.
#define FLT_LOSTCHILD            0x8000
#define FLT_CHILDFAULT           0x4000
#define FLT_PARENT_TSENSOR       0x2000
#define FLT_PARENT_HSENSOR       0x1000
#define FLT_CANNOTCONTROLTEMP    0x0800
#define FLT_CANNOTCONTROLHUM     0x0400
#define FLT_SYSTEMERROR          0x0200
#define FLT_SMEM                 0x0080
#define FLT_PARENT_TSEN_NOISY    0x0004
#define FLT_PARENT_HSEN_NOISY    0x0002

    // Parent sysStat bits.  Saved every 5 sec to SEEPROM.
#define ST_SENSORSNOTCALIB      0x0100      // Clear both T & RH cal'd
#define ST_CLOCKNOTSET          0x0010      // Clear when RTCC set
#define ST_USE_CELSIUS          0x0080
#define ST_USE_DEWPOINT         0x0040
#define ST_ALWAYS_TRUE          0x1000      // Aids screening for smem errors

    // Child status, which Parent may inquire
#define CHILD_TSEN_OKAY         0x0001
#define CHILD_TSEN_OVERRANGE    0x0002
#define CHILD_TSEN_UNDERRANGE   0x0004
#define CHILD_TSEN_NOISY        0x0008
#define CHILD_HSEN_OKAY         0x0010
#define CHILD_HSEN_OVERRANGE    0x0020
#define CHILD_HSEN_UNDERRANGE   0x0040
#define CHILD_HSEN_NOISY        0x0080
#define CHILD_K1_ON             0x0100
#define CHILD_K2_ON             0x0200
#define	CHILD_LIQUID_DETECTED   0x0400
#define CHILD_COMMUNICATING     0x0800

    // EQQ word, child reports this per PNet
    // This info gets recorded in the resourceMatrix
#define EQPT_TH_OUTSIDE     0x0001
#define EQPT_TH_INTFAN      0x0002
#define EQPT_DEHUM_K1       0x0004
#define EQPT_EXTFAN_K1      0x0008
#define EQPT_HUMIDIFIER_K1  0x0010
#define EQPT_DEHUM_K2       0x0020
#define EQPT_EXTFAN_K2      0x0040
#define EQPT_HUMIDIFIER_K2  0x0080
#define EQPT_LIQUIDSENSOR   0x0100
#define EQPT_HEATER_K1      0x0200
#define EQPT_HEATER_K2      0x0400
#define EQPT_AIRCON_K1      0x0800
#define EQPT_AIRCON_K2      0x1000

    /**** Hardware mapping definitions...   ****/

    // Analog channels
#define ANCH_ISEN1      4    // AN4 U4.12 = RB4
#define ANCH_ISEN2      5    // AN5 U4.11 = RB5
#define ANCH_ISEN3      6    // AN6 U4.17 = RB6
#define ANCH_ISEN4      7    // AN7 U4.18 = RB7
#define ANCH_ISEN5      8    // AN8 U4.21 = RB8
#define ANCH_ISEN6      9    // AN9 U4.22 = RB9
#define ANCH_ISEN7      14   // AN14 U4.29 = RB14
#define ANCH_ISEN8      15   // AN15 U4.30 = RB15
#define ANCH_RELHUM     24   // AN24 U4.49 = RD1
#define ANCH_TEMPER     25   // AN25 U4.50 = RD2
#define ANCH_CAPKEY1    20   // AN20 U4.62 = RE2
#define ANCH_CAPKEY2    21   // AN21 U4.64 = RE4
#define ANCH_CAPKEY3    22   // AN22 U4.1 = RE5
        // #define CapKe1     PORTEbits.RE2       // i U4.62 = AN20
#define ANCH_CAPKEY4    23   // AN23 U4.2 = RE6

    // Hardware lines, TODO use LAT?
#define LED_GREEN   LATEbits.LATE3       // o0 U4.63
#define LED_RED     LATEbits.LATE7       // o0 U4.3
#define BUZZER      PORTFbits.RF6

//#define LCD_E       LATFbits.LATF4      // o0 U4.31
#define LCD_RD_n    LATFbits.LATF4      // o0 U4.35 alias
//#define LCD_DC      LATFbits.LATF5      // o0 U4.32
#define LCD_A0      LATFbits.LATF5      // o0 U4.32 alias
//#define LCD_RW      LATGbits.LATG2      // o0 U4.37
#define LCD_WR_n    LATGbits.LATG2      // o0 U4.37 alias
#define LCD_RES_n   LATGbits.LATG3      // o1 U4.36
#define LCD_CS1_n   LATDbits.LATD0      // o1 U4.46
#define LCD_WD0     LATDbits.LATD4      // o0 U4.52
#define LCD_WD1     LATDbits.LATD5      // o0 U4.53
#define LCD_WD2     LATDbits.LATD6      // o0 U4.54
#define LCD_WD3     LATDbits.LATD7      // o0 U4.55
#define LCD_WD4     LATDbits.LATD8      // o0 U4.42
#define LCD_WD5     LATDbits.LATD9      // o0 U4.43
#define LCD_WD6     LATDbits.LATD10     // o0 U4.44
#define LCD_WD7     LATDbits.LATD11     // o0 U4.45
#define LCD_RD0     PORTDbits.RD4       // For reads..
#define LCD_RD1     PORTDbits.RD5
#define LCD_RD2     PORTDbits.RD6
#define LCD_RD3     PORTDbits.RD7
#define LCD_RD4     PORTDbits.RD8
#define LCD_RD5     PORTDbits.RD9
#define LCD_RD6     PORTDbits.RD10
#define LCD_RD7     PORTDbits.RD11

//#define LCD_CS2_n   PORTDbits.RD3       // o1 U4.51
#define COMM_RX_ENA_n  LATBbits.LATB2       // o1 U4.36
#define COMM_SHDN_n    LATBbits.LATB3       // o1 U4.37
#define SMEM_CS_n   PORTGbits.RG9       // o1 U4.8
#define RELAY1      LATEbits.LATE0       // o1 U4.60
#define RELAY2      LATEbits.LATE1       // o1 U4.61

#define JTAG_TDO    LATBbits.LATB11     // JTAG.5 used for timing analysis only now

typedef unsigned char byte;
extern char ioBfr[];

//void delay_ms(unsigned t);        // Dumb delay fcn.
void delay_us(unsigned t);        // Dumb delay fcn.

#endif	
