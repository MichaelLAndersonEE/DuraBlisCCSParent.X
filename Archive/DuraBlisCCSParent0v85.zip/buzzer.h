/* 
 * File:   buzzer.h
 * Author: Lonely Bull
 *
 * Created on September 24, 2014, 3:48 PM
 */

#ifndef BUZZER_H
#define	BUZZER_H

#ifdef	__cplusplus
extern "C" {
#endif

#define BUZ_CLEARSTATUS         0x01
#define BUZ_STATUSBAD           0x02
#define BUZ_STARTUP             0x04
#define BUZ_NEWCHILD            0x08
#define BUZ_KEYA                0x10
#define BUZ_KEYB                0x20
#define BUZ_KEYC                0x40
#define BUZ_KEYD                0x80

void buzzerControl(byte buzz, byte t_100ms);


#ifdef	__cplusplus
}
#endif

#endif	/* BUZZER_H */

