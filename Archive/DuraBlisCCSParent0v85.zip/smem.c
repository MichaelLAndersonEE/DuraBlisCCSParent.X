/* File:   smem.c  SEEPROM SPI2-based functions, incl datalog
 * Author: Michael L Anderson
 * Contact: MichaelLAndersonEE@gmail.com
 * Platform: PIC32MX350F256H on DuraBlis-CCS-Main_v4 board.
 * SEEPROM: 25AA128, 16 Kbyte, 256 64-byte pages
 * Created: 02 Oct 14
 * A flote is a signed int = float * 100.  (Obsolete)
 */

#include <xc.h>
#include <string.h>
#include "DuraBlisCCSParent.h"
#include "smem.h"
#include "serial.h"
#include "time.h"
#include "keypad.h"

    // SMEM semantics
#define SMEM_DUMMY  0x00
#define SMEM_READ   0x03
#define SMEM_WRITE  0x02
#define SMEM_WRDI   0x04
#define SMEM_WREN   0x06
#define SMEM_RDSR   0x05
#define SMEM_WRSR   0x01

#define SMEM_NUM_PAGES      256
#define SMEM_PAGE_SIZE       64
#define SMEM_ARRAY_SIZE      64     // Max bytes in buffer for any one rd/wr block
#define SMEM_ADDR_TIME        0     // Page 0 for time save.
#define SMEM_ADDR_CHECKSUMS  32     // Page 0 for checksums
#define SMEM_ADDR_PARMS      64     // Page 1 for parms (cal consts, etc)
#define SMEM_ADDR_ISEN_CAL  128     // Page 2 for iSen cal factors
#define SMEM_ADDR_RESMTX    192     // Page 3 for resourceMatrix
#define SMEM_ADDR_DATALOG   256     // Pages 4..204 for DL

#define DL_MAX_RECORDS     1600     // 8 doubles per page x 200 pgs
#define DL_RECORD_SIZE        8     // Bytes, = 2 flotes now
#define DL_RECORDS_PER_PAGE   8     // 64 bytes per pg / (4 bytes per float * 2 floats per record)
#define DL_PAGES            200

static int smem_ReadArray(unsigned addr, byte *arrayPtr, unsigned arraySize);
static int smem_WriteArray(unsigned addr, byte *arrayPtr, unsigned arraySize);
static bool smem_Busy(void);
static byte spi2_WRBuffer(byte datum);

extern struct t_struct time;                    // Page 0
extern struct operatingParms_struct oP;         // Page 1
extern double iSenCalFactor [NUM_CHILDREN];     // Page 2
extern struct res_struct resourceMatrix;        // Page 3.  Datalog uses Pages 4..204

    // Volatile
extern float temperNowF, rhumidNow;
static unsigned dlPage;
static byte dlPageIdx;      // Bytes on a page

    // dlPtr and dlRecordsSaved form a wrap around buffer.  dlPtr increments to DL_MAX_RECORDS * DL_RECORD_SIZE, then
    // resets to 0 again.  dlRecordsSaved increases by DL_RECORD_SIZE until it hits DL_MAX_RECORDS * DL_RECORD_SIZE.
//byte dAx = 0;       // dataArray index  TODO??
char smemBfr[31];   // For debugging
//byte *dlogPtr;

    // Destructive erasure of entire SEEPROM.
void smemEraseAll(void)
{
    unsigned page, d;

    for (d = 0; d < SMEM_ARRAY_SIZE; d++) ioBfr[d] = 0xFF;

    putStr("\tSmem destructive erase all...\r\n");
    for (page = 0; page < SMEM_NUM_PAGES; page++)
    {
         if (smem_WriteArray(page * SMEM_PAGE_SIZE, (byte *) ioBfr, SMEM_ARRAY_SIZE) != SMEM_ARRAY_SIZE)
         {
             putStr("\tsmemEraseAll failed.\r\n");
             return;
         }        
         petTheDog();
    }

    sprintf(ioBfr, "\tErased %d pages of smem.\r\n", SMEM_NUM_PAGES);
    putStr(ioBfr);
}

        // Destructive write to entire SEEPROM.  TODO Test cross-page writes.
void smemWriteTest(void)
{
    unsigned page, d;
    char testStr[SMEM_ARRAY_SIZE + 1];

    // "Page 000 : 012345678901234567890123456789012345678901234567890123456789

    for (d = 0; d < 40; d++) testStr[d] = '0' + (d % 10);
    testStr[d] = 0;

    putStr("\tsmem destructive write test...\r\n");
    for (page = 0; page < SMEM_NUM_PAGES; page++)
    {
         sprintf(ioBfr, "Page %03d : ", page);
         strcat(ioBfr, testStr);
         if (smem_WriteArray(page * SMEM_PAGE_SIZE, (byte *) ioBfr, SMEM_ARRAY_SIZE) != SMEM_ARRAY_SIZE)
         {
             putStr("\tsmemWriteTest failed.\r\n");
             return;
         }
         else
         {
             putStr(ioBfr);
             putStr("\r\n");
         }
         petTheDog();
    }
   
    sprintf(ioBfr, "\tWrote %d pages to smem.", SMEM_NUM_PAGES);
    putStr(ioBfr);    
}

void smemReadTest(void)
{
    unsigned page;
    for (page = 0; page < SMEM_NUM_PAGES; page++)
    {
         if (smem_ReadArray(page * SMEM_PAGE_SIZE, (byte *) ioBfr, SMEM_ARRAY_SIZE) != SMEM_ARRAY_SIZE)
         {
             putStr("\tsmemReadTest failed.\r\n");
             return;
         }
         else
         {
             putStr(ioBfr);
             putStr("\r\n");
         }
         petTheDog();
    }

}

    // Called nominally every 5 mins to keep a rough nonvol clock
int smemWriteTime(void)
{
    ioBfr[0] = time.year;
    ioBfr[1] = time.month;
    ioBfr[2] = time.dayMonth;
    ioBfr[3] = time.hour;
    ioBfr[4] = time.minute;

    return (smem_WriteArray(SMEM_ADDR_TIME, (byte *) ioBfr, 5));
}

    // Called at reset.  Has non-recursive retry.
int smemReadTime(void)
{
    bool success = true;
    
    if (smem_ReadArray(SMEM_ADDR_TIME, (byte *) ioBfr, 5) < 5) success = false;

    if (ioBfr[0] > 0 && ioBfr[0] < 100) time.year = ioBfr[0];   // Years from (20)14 - (20)99
    else success = false;
    if (ioBfr[1] > 0 && ioBfr[1] < 13) time.month = ioBfr[1];
    else success = false;
    if (ioBfr[2] > 0 && ioBfr[2] < 32) time.dayMonth = ioBfr[2];
    else success = false;
    if (ioBfr[3] < 60) time.hour = ioBfr[3];
    else success = false;
    if (ioBfr[4] < 60) time.minute = ioBfr[4];
    else success = false;

    if (success == false)
    {
        if (smem_ReadArray(SMEM_ADDR_TIME, (byte *) ioBfr, 5) == 5) return(-1);

        if (ioBfr[0] > 0 && ioBfr[0] < 100) time.year = ioBfr[0];
        else return(-2);
        if (ioBfr[1] > 0 && ioBfr[1] < 13) time.month = ioBfr[1];
        else return(-3);
        if (ioBfr[2] > 0 && ioBfr[2] < 32) time.dayMonth = ioBfr[2];
        else return(-4);
        if (ioBfr[3] < 60) time.hour = ioBfr[3];
        else return(-5);
        if (ioBfr[4] < 60) time.minute = ioBfr[4];
        else return(-6);
    }

//    sprintf(ioBfr, "\ty%d m%d d%d h%d m%d\n\r", time.year, time.month, time.dayMonth, time.hour, time.minute );    // DEB
//    putStr(ioBfr);  // DEB
    oP.sysStat &= ~ST_CLOCKNOTSET;
    return (5);
}

    // TODO regenerate actual times
int smemDatalogReport(void)
{   
    unsigned r;
    double T, RH, *dPtr;
    unsigned address;

    if (oP.dlRecordsSaved == 0)
    {
        putStr("\tNo datalog records saved.\n\r");
        return(0);
    }                      

        // Start at present location
    address = SMEM_ADDR_DATALOG + dlPage * DL_RECORDS_PER_PAGE + dlPageIdx;

    sprintf(ioBfr, "\n\r// #,\toF,\t%%RH\t[%d records]\n\r", oP.dlRecordsSaved);
    putStr(ioBfr);

    for (r = 0; r < oP.dlRecordsSaved; r++)
    {
        smem_ReadArray(address, (byte *) ioBfr, DL_RECORD_SIZE);
        dPtr = (double *) (&ioBfr[0]);
        T = *dPtr;       
        dPtr = (double *) (&ioBfr[4]);
        RH = *dPtr;
        sprintf(smemBfr, "%3d, \t%2.1f, \t%2.1f,\n\r", r + 1, T, RH);
        putStr(smemBfr);

        if (address > SMEM_ADDR_DATALOG + DL_RECORD_SIZE) address -= DL_RECORD_SIZE;
        else address = SMEM_ADDR_DATALOG + DL_MAX_RECORDS - DL_RECORD_SIZE;
        petTheDog();
    }
    return(r);        
}

    // Called every time t (nom 5 min).  Smem writes latest T & RH as doubles.
void smemDatalog(void)
{
    static byte dlBfr[SMEM_ARRAY_SIZE];
    union dl_union
    {
        byte bubble[4];
        double dubble;      // MPLAB XC double is 4 byte
    } dlU;

    dlU.dubble = temperNowF;
    dlBfr[dlPageIdx] = dlU.bubble[3];       // Little-endian. The first shall be last.
    dlBfr[dlPageIdx + 1] = dlU.bubble[2];
    dlBfr[dlPageIdx + 2] = dlU.bubble[1];
    dlBfr[dlPageIdx + 3] = dlU.bubble[0];
    dlU.dubble = rhumidNow;
    dlBfr[dlPageIdx + 4] = dlU.bubble[3];
    dlBfr[dlPageIdx + 5] = dlU.bubble[2];
    dlBfr[dlPageIdx + 6] = dlU.bubble[1];
    dlBfr[dlPageIdx + 7] = dlU.bubble[0];

//    sprintf(smemBfr, "[%02X %02X %02X %02X | %02X %02X %02X %02X]\r\n",
//        dlBfr[dlPageIdx], dlBfr[dlPageIdx + 1], dlBfr[dlPageIdx + 2], dlBfr[dlPageIdx + 3],
//        dlBfr[dlPageIdx + 4], dlBfr[dlPageIdx + 5], dlBfr[dlPageIdx + 6], dlBfr[dlPageIdx + 7] );   // DEB
    dlU.bubble[3] = dlBfr[dlPageIdx];   // DEB
    dlU.bubble[2] = dlBfr[dlPageIdx + 1];
    dlU.bubble[1] = dlBfr[dlPageIdx + 2];
    dlU.bubble[0] = dlBfr[dlPageIdx + 3];
    sprintf(smemBfr, "\t[%3.02f oF]\r\n", dlU.dubble);
    putStr(smemBfr);       // DEB

    oP.dlRecordsSaved++;
    dlPageIdx += DL_RECORD_SIZE;
    if (dlPageIdx >= SMEM_PAGE_SIZE)
    {
        dlPageIdx = 0;
        smem_WriteArray(SMEM_ADDR_DATALOG + (dlPage * SMEM_PAGE_SIZE), dlBfr, SMEM_ARRAY_SIZE);             
        if (dlPage++ > DL_PAGES) dlPage = 0;    // Wrap around
    }
}

//int smemReadParmsTest(void)
//{
//    unsigned dummyUns;
//    unsigned dummyFlo;
//    char dummyStr[31];
//    byte i;
//
//    putStr("\r\n\t* sRP Test *\r\n");
//    smem_ReadArray(SMEM_ADDR_PARMS, (byte *) ioBfr, SMEM_ARRAY_SIZE);
//
//
//    dummyUns = smem_UnstuffUnsigned();
//    sprintf(smemBfr, " sysStat: %04X\r\n", dummyUns);
//    putStr(smemBfr);
//
//    dummyUns = smem_UnstuffUnsigned();
//    sprintf(smemBfr, " dlRecordsSaved: %04X\r\n", dummyUns);
//    putStr(smemBfr);
//
//    smem_UnstuffString(dummyStr, 11);
//    sprintf(smemBfr, " uniqueID: %s\r\n", dummyStr);
//    putStr(smemBfr);
//
//    dummyFlo = smem_UnstuffFlote();
//    sprintf(smemBfr, " setPointTempF: %3.02f\r\n", dummyFlo);
//    putStr(smemBfr);
//
//    dummyFlo = smem_UnstuffFlote();
//    sprintf(smemBfr, " setPointRelHum: %3.02f\r\n", dummyFlo);
//    putStr(smemBfr);
//
//    dummyFlo = smem_UnstuffFlote();
//    sprintf(smemBfr, " temperCalFactor: %3.02f\r\n", dummyFlo);
//    putStr(smemBfr);
//
//    dummyFlo = smem_UnstuffFlote();
//    sprintf(smemBfr, " rhumidCalFactor: %3.02f\r\n\n", dummyFlo);
//    putStr(smemBfr);
//}

    // Called on startup reset and as factory setting restore of operating parms
    // One non-recursive retry.  TODO non-self-referential checksum.
    // Returns num bytes read on success or neg failure code.
int smemReadParms(void)
{
    struct operatingParms_struct oPBfr;
    int success = 1;
    byte d, *dPtr;
    byte ch;

    if (smem_ReadArray(SMEM_ADDR_PARMS, (byte *) ioBfr, SMEM_ARRAY_SIZE) < SMEM_ARRAY_SIZE) success = -1;

    dPtr = (byte *) &oPBfr;
    for (d = 0; d < SMEM_ARRAY_SIZE; d++)
        *(dPtr + d) = ioBfr[d];

    if (oPBfr.sysStat & ST_ALWAYS_TRUE) oP.sysStat = oPBfr.sysStat;
    else success = -2;

    if (oPBfr.dlRecordsSaved < DL_MAX_RECORDS) oP.dlRecordsSaved = oPBfr.dlRecordsSaved;
    else success = -3;

    if (oPBfr.setPointTempF > SET_TEMP_MIN && oPBfr.setPointTempF <  SET_TEMP_MAX) oP.setPointTempF = oPBfr.setPointTempF;
    else success = -4;

    if (oPBfr.setPointRelHum > SET_RH_MIN && oPBfr.setPointRelHum <  SET_RH_MAX) oP.setPointRelHum = oPBfr.setPointRelHum;
    else success = -5;

    if (oPBfr.temperCalFactor > CAL_FACTOR_MIN && oPBfr.temperCalFactor < CAL_FACTOR_MAX) oP.temperCalFactor = oPBfr.temperCalFactor;
    else success = -6;

    if (oPBfr.rhumidCalFactor > CAL_FACTOR_MIN && oPBfr.rhumidCalFactor < CAL_FACTOR_MAX) oP.rhumidCalFactor = oPBfr.rhumidCalFactor;
    else success = -7;

    if (oPBfr.rhumidCalFactor > CAL_FACTOR_MIN && oPBfr.rhumidCalFactor < CAL_FACTOR_MAX) oP.rhumidCalFactor = oPBfr.rhumidCalFactor;
    else success = -8;

    if (oPBfr.kpadSensit[0] > KEYPAD_SENSIT_MIN && oPBfr.kpadSensit[0] < KEYPAD_SENSIT_MAX) oP.kpadSensit[0] = oPBfr.kpadSensit[0];
    else success = -9;

    if (oPBfr.kpadSensit[1] > KEYPAD_SENSIT_MIN && oPBfr.kpadSensit[1] < KEYPAD_SENSIT_MAX) oP.kpadSensit[1] = oPBfr.kpadSensit[1];
    else success = -10;

    if (oPBfr.kpadSensit[2] > KEYPAD_SENSIT_MIN && oPBfr.kpadSensit[2] < KEYPAD_SENSIT_MAX) oP.kpadSensit[2] = oPBfr.kpadSensit[2];
    else success = -11;

    if (oPBfr.kpadSensit[3] > KEYPAD_SENSIT_MIN && oPBfr.kpadSensit[3] < KEYPAD_SENSIT_MAX) oP.kpadSensit[3] = oPBfr.kpadSensit[3];
    else success = -12;

    oPBfr.uniqueID[UID_SIZE] = 0;
    for (ch = 0; ch < UID_SIZE; ch++)
        if (oPBfr.uniqueID[ch] > 31 && oPBfr.uniqueID[ch] < 128) oP.uniqueID[ch] = oPBfr.uniqueID[ch];

        // TODO now add iSens & resMtx

////    for (i = 0; i < NUM_CHILDREN; i++)
////    {
////        dummyFlo = smem_UnstuffFlote();
////        if (dummyFlo > CAL_FACTOR_MIN && dummyFlo < CAL_FACTOR_MAX) iSenCalFactor[i] = dummyFlo;
////        else success = -9;
////    }
//
//    if (success < 0)
//    {
//        sprintf(smemBfr, "(sRP %d)\n\r", success);       // DEB
//        putStr(smemBfr); // DEB
//
//        if (smem_ReadArray(SMEM_ADDR_PARMS, (byte *) ioBfr, SMEM_ARRAY_SIZE) < SMEM_ARRAY_SIZE) return(-1);
//
//        dAx = 0;
//        dummyUns = smem_UnstuffUnsigned();
//        if (dummyUns & ST_ALWAYS_TRUE) sysStat = dummyUns;
//        else return(-2);
//
//        dummyUns = smem_UnstuffUnsigned();      // Assure at least one record written
//        if (dummyUns > 0 && dummyUns < DL_MAX_RECORDS * DL_RECORD_SIZE) dlRecordsSaved = dummyUns;
//        else return(-3);
//
//        if (smem_UnstuffString(dummyStr, 11) == 11) strcpy(uniqueID, dummyStr);
//        else return(-4);
//
//        dummyFlo = smem_UnstuffFlote();
//        if (dummyFlo > SET_TEMP_MIN && dummyFlo < SET_TEMP_MAX) setPointTempF = dummyFlo;
//        else return(-5);
//
//        dummyFlo = smem_UnstuffFlote();
//        if (dummyFlo > SET_RH_MIN && dummyFlo < SET_RH_MAX) setPointRelHum = dummyFlo;
//        else return(-6);
//
//        dummyFlo = smem_UnstuffFlote();
//        if (dummyFlo > CAL_FACTOR_MIN && dummyFlo < CAL_FACTOR_MAX) temperCalFactor = dummyFlo;
//        else return(-7);
//
//        dummyFlo = smem_UnstuffFlote();
//        if (dummyFlo > CAL_FACTOR_MIN && dummyFlo < CAL_FACTOR_MAX) rhumidCalFactor = dummyFlo;
//        else return(-8);
////
////        for (i = 0; i < NUM_CHILDREN; i++)  TODO
////        {
////            dummyFlo = smem_UnstuffFlote();
////            if (dummyFlo > CAL_FACTOR_MIN && dummyFlo < CAL_FACTOR_MAX) iSenCalFactor[i] = dummyFlo;
////            else return(-9);
////        }
//    }
//    return(dAx);
}

    // Called periodically as operating parm backup
    // Returns num bytes written on success or neg failure code.
int smemWriteParms(void)
{
    byte d, *dPtr;
    dPtr = (byte *)&oP;
    for (d = 0; d < SMEM_ARRAY_SIZE; d++)
        ioBfr[d] = (byte) *(dPtr + d);
      
    return(smem_WriteArray(SMEM_ADDR_PARMS, ioBfr, SMEM_ARRAY_SIZE));
}

int smem_ReadArray(unsigned addr, byte *arrayPtr, unsigned arraySize)
{
    unsigned by;

    if (smem_Busy()) return(0);        // Pause till free
    SMEM_CS_n = 0;
    spi2_WRBuffer(SMEM_READ);
    spi2_WRBuffer(addr >> 8);
    spi2_WRBuffer(addr);

    for (by = 0; by < arraySize; by++)
    {
        arrayPtr[by] = spi2_WRBuffer(SMEM_DUMMY);
    }
    SMEM_CS_n = 1;
    return(by);
}

int smem_WriteArray(unsigned addr, byte *arrayPtr, unsigned arraySize)
{
    unsigned by;
   
    if (smem_Busy()) return(0);        // Pause till free
    SMEM_CS_n = 0;
    spi2_WRBuffer(SMEM_WREN);    //
    SMEM_CS_n = 1;
    delay_us(1);
    SMEM_CS_n = 0;
    spi2_WRBuffer(SMEM_WRITE);
    spi2_WRBuffer(addr >> 8);
    spi2_WRBuffer(addr);

    for (by = 0; by < arraySize; by++)
    {
        if ((addr + by) % 64 == 0 && by != 0)  // Hit 64 byte page boundary
        {
            SMEM_CS_n = 1;
            if (smem_Busy()) return(0);        // Pause till free
            SMEM_CS_n = 0;
            spi2_WRBuffer(SMEM_WREN);
            SMEM_CS_n = 1;
            delay_us(1);
            SMEM_CS_n = 0;
            spi2_WRBuffer(SMEM_WRITE);
            spi2_WRBuffer((addr + by) >> 8);
            spi2_WRBuffer(addr + by);
        }
        spi2_WRBuffer(arrayPtr[by]);

    }
    SMEM_CS_n = 1;
    return(arraySize);
}

bool smem_Busy(void)
{
    byte status = 0;
    unsigned timeOut = 0;

    do
    {
        SMEM_CS_n = 0;
        spi2_WRBuffer(SMEM_RDSR);    // Read status reg
        status = spi2_WRBuffer(0);  // Test datum
        SMEM_CS_n = 1;
        if (timeOut++ == 0xFFFF) { putChar('*'); return(true);  }  // DEB
    } while (status & 0x01);

    return(false);
}

 byte spi2_WRBuffer(byte datum)
 {
     SPI2BUF = datum;
     while (!SPI2STATbits.SPIRBF) ;
     return (SPI2BUF);
 }

