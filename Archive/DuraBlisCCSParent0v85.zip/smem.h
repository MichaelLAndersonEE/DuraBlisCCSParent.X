/* File:   smem.h  SEEPROM functions
 * Author: Michael L Anderson
 * Contact: MichaelLAndersonEE@gmail.com
 * Platform: PIC32MX350F256H on DuraBlis-CCS-Main_v4 board.
 * Created: 02 Oct 14
 */


#ifndef SMEM_H
#define	SMEM_H

#ifdef	__cplusplus
extern "C" {
#endif

void smemEraseAll(void);
int smemWriteTime(void);
int smemReadTime(void);
int smemReadParms(void);
int smemWriteParms(void);
int smemReadParmsTest(void);
void smemReadTest(void);
void smemWriteTest(void);

int smemDatalogReport(void);
void smemDatalog(void);

#ifdef	__cplusplus
}
#endif

#endif	/* SMEM_H */

