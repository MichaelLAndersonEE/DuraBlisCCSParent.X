/* File:   resources.h
 * Manages the matrix of needed control resoources versus parent / child owners
 * PNet ver A
 * Author: Michael L Anderson
 * Contact: MichaelLAndersonEE@gmail.com
 * Created: 18 Sep14
 */

#ifndef RESOURCES_H
#define	RESOURCES_H

#ifdef	__cplusplus
extern "C" {
#endif
           
#define RES_CYCLE_UP    0x01        // Used in screen editing
#define RES_CYCLE_DOWN  0x02

    // Child status bits
#define CHILD_ST_NODE_DEFINED       0x8000
#define CHILD_ST_NODE_ACTIVE        0x4000      // Ie, it's actively communicating
#define CHILD_ST_HAVE_FLOODSEN      0x2000
#define CHILD_ST_HAVE_TEMP2         0x1000      // Second, remote temper sensor option
#define CHILD_ST_EXTERNAL_TH        0x0800      // Measures outdoor conditions

    // These must match the byte status code passed in Pnet.
#define CHILD_ST_LIQUID_DETECTED    0x0080
#define CHILD_ST_TEMP1_OKAY         0x0040      // Ie, the sensor is operating within range
#define CHILD_ST_TEMP2_OKAY         0x0020
#define CHILD_ST_RHUMID_OKAY        0x0010
#define CHILD_ST_K1_ON              0x0008
#define CHILD_ST_K2_ON              0x0004
#define CHILD_ST_SWIPWR1_ON         0x0002
#define CHILD_ST_SWIPWR2_ON         0x0001

typedef enum Action_Types
    { SvcParentResources, MsgAttention, MsgRelay, MsgSwiPwr, MsgAskTemper, MsgAskRHumid } ActionType;
typedef enum Resource_Types
    { Free, AirConditioner, Heater, DeHumidifier, AirExchangerIn, AirExchangerOut, Humidifier, InternalFan } ResourceType;
typedef enum Output_Types
    { Relay1, Relay2, SwiPwr1, SwiPwr2  } OutputType;

ActionType actionType;      // These guys have file scope. They are prepared by indexNextResource() et al,
ResourceType resourceType;  // then used by messageXX()
OutputType outputType;

struct childResourceStruct
{
    unsigned status;
    byte    miaCtr;
    ResourceType    relay1;         // eg, child[0].relay1 = DeHumidifier;
    ResourceType    relay2;
    ResourceType    swiPwr1;
    ResourceType    swiPwr2;
    float   localTempF;
    float   localRHumid;
} child[NUM_CHILDREN];

struct parentResourceStruct
{
    ResourceType    relay1;
    ResourceType    relay2;
} parent;

struct resEval_struct
{
    unsigned    dayTotalCounter;    // If resourceManager() called every 3 sec, will reach 28800. Reset ay midnight.
    unsigned    tooHotTimer;        // Starts when temp high, stops on control convergence
    unsigned    tooColdTimer;       // What we want is the ratio of tHT / dTC.  TODO log these?  Average?
    unsigned    tooDampTimer;
    unsigned    tooDryTimer;
} resourceEvaluate;

int resourceManager(void);      // Resources
char *resourceQuery(byte node, char outChan);
int externalTHavailable(void);

#ifdef	__cplusplus
}
#endif

#endif	/* RESOURCES_H */

// ---------------------------------------
//#define RES_RELAY1          0x08
//#define RES_RELAY2          0x04
//#define RES_SWIPWR1         0x02
//#define RES_SWIPWR2         0x01
//
//struct resourceStruct
//{
//    byte    airConditioner;     // Each element has RES_ bits set
//    byte    heater;
//    byte    deHumidifier;
//    byte    airExchanger;       // This assumes also outsideTH sensor
//    byte    humidifier;
//    byte    internalFan;        // resourceManager() knows this is on PowerSwitch
//} resource[NUM_CHILDREN + 1];      // Parent is 0, then children 1..8

    // This maps needed resources to child node numbers or local control.
    // This is smem backed up
//struct res_struct
//{
//    unsigned long airConditioner;   // uns longs are bitfields RES_
//    unsigned long heater;           // Parent low-current thermostat K1 & K2 only for first two resources
//    unsigned long dehumidifier;
//    unsigned long airExchanger;
//    unsigned long humidifier;
//    unsigned long intFanTH;
//    byte outsideTH;                 // = child number with, 0 if none
//    unsigned floodSensor;           // Bitfield, 1-based
//} resourceMatrix;
   //#define IDX_PARENT  0       // Used in resource mgmt

                    // Resource bit field.  Any given resource, such as .heater, may have these set
                //#define RES_Ch1A    0x00001
                //#define RES_Ch1B    0x00002
                //#define RES_Ch2A    0x00004
                //#define RES_Ch2B    0x00008
                //#define RES_Ch3A    0x00010
                //#define RES_Ch3B    0x00020
                //#define RES_Ch4A    0x00040
                //#define RES_Ch4B    0x00080
                //#define RES_Ch5A    0x00100
                //#define RES_Ch5B    0x00200
                //#define RES_Ch6A    0x00400
                //#define RES_Ch6B    0x00800
                //#define RES_Ch7A    0x01000
                //#define RES_Ch7B    0x02000
                //#define RES_Ch8A    0x04000
                //#define RES_Ch8B    0x08000
                //#define RES_ParA    0x10000
                //#define RES_ParB    0x20000