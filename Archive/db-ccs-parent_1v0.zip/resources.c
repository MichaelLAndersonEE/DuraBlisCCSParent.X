/* File:   resources.c
 * Serves as middleware between the available dynamic resources and communication
 * with nodes, with all of the intricacies thereof.
 * Author: Michael L Anderson
 * Contact: MichaelLAndersonEE@gmail.com
 * Platform: PIC32MX350F256H on DB-CCS-Main board
 * Created: 18 Sep14
 * Passim: Node 0 = parent, child nodes are 1 - 8. For child[idx], idx = node - 1.
 * Some resources require additional communication.  IntFan requires that we first ask the
 * local RH.  Air Exchangers require that ask the outside T.
 */

#include <xc.h>
#include <string.h>
#include <stdlib.h>
#include "DuraBlisCCSParent.h"
#include "resources.h"
#include "pnet.h"
#include "serial.h"
#include "time.h"

#define TOO_HOT     0x01
#define TOO_COLD    0x02
#define TOO_DAMP    0x04
#define TOO_DRY     0x08

static int ascii2Hex(char ch);
static bool childHasAirExch(byte nod);
static bool childHasIntFan(byte nod);
static void indexNextResource(void);
static int messageAskRHumid(void);
static int messageAskTemper(void);
static int messageAttention(void);
static int messageRelay(void);
static int messageSwiPwr(void);
static byte nextNodeNum(byte nodeStart);
static int serviceParentResources(void);

static byte climateStatus;     // TOO_...
static byte nodeNum;    // Valid 0 - 8.  The node presently being communicated with.
  
    // Called periodically by taskSchedular to work available child resouces.  Parent is nodeNum 0
    // Returns 1 for nominal performance, exceptions < 0 are passed back.
int resourceManager(void)
{
    extern double temperNowF, rhumidNow;
    extern struct operatingParms_struct oP;
   
    climateStatus = 0;
    if (temperNowF > ( (1.0 + oP.deadBandFactor) * oP.setPointTempF)) climateStatus |= TOO_HOT;
    else if (temperNowF < ( (1.0 - oP.deadBandFactor) * oP.setPointTempF)) climateStatus |= TOO_COLD;
    if (rhumidNow > ( (1.0 + oP.deadBandFactor) * oP.setPointRelHum)) climateStatus |= TOO_DAMP;
    else if (rhumidNow < ( (1.0 - oP.deadBandFactor) * oP.setPointRelHum)) climateStatus |= TOO_DRY;

        // We send one message per cycle. Parent is in same process but does not need messaging.  Every
        // child gets an ATn to start.  Some resources require follow up queries / msgs.
    indexNextResource();
    
    switch(actionType)
    {
        case SvcParentResources:
            return(serviceParentResources());         

        case MsgAttention:
            return(messageAttention());       

        case MsgRelay:
            return(messageRelay());

        case MsgSwiPwr:
            return(messageSwiPwr());

        case MsgAskTemper:
            return(messageAskTemper());

        case MsgAskRHumid:
            return(messageAskRHumid());
    }
}

    // Write formatted str with resources associated with nodeNumber. 
    // outChan A = relay1, B = relay2, C = swipwr1, D = swipwr2
    // Limit to 10 chars.
char *resourceQuery(byte nodeNumber, char outChan)
{
    char *rsrcStr[8] = {       // This has to match the enum.
        "Free", "AirCond", "Heater", "Dehumid", "AirExchIn",
        "AirExchOut", "Humidif", "IntFan" };

    if (nodeNumber == 0)
    {
        if (outChan == 'A') return(rsrcStr[(int)parent.relay1]);
        else return(rsrcStr[(int)parent.relay2]);
    }
    else
    {
        if (outChan == 'A') return(rsrcStr[(int)child[nodeNumber - 1].relay1]);
        else if (outChan == 'B') return(rsrcStr[(int)child[nodeNumber - 1].relay2]);
        else if (outChan == 'C') return(rsrcStr[(int)child[nodeNumber - 1].swiPwr1]);
        else if (outChan == 'D') return(rsrcStr[(int)child[nodeNumber - 1].swiPwr2]);
    }

    return("Error");
}

    // There can only be one outside temperature. Or we need a way to arbitrate.
    // So here we scan through the active children and return numNode of first
    // that qualifies, or 0 OW.
int externalTHavailable(void)
{
    extern double temperNowExteriorF, rhumidNowExterior;

    unsigned ch;
    for (ch = 0; ch < NUM_CHILDREN; ch++)
    {
        if ((child[ch].status & CHILD_ST_EXTERNAL_TH) && (child[ch].status & CHILD_ST_NODE_ACTIVE))
        {
            temperNowExteriorF = child[ch].localTempF;
            rhumidNowExterior = child[ch].localRHumid;  // TODO best place?
            return(ch + 1);
        }
    }
    return(0);
}

    /* ----------- Private functions -------------- */

int ascii2Hex(char ch)
{
    if (ch >= '0' && ch <'9') return(ch - '0');
    if (ch >= 'a' && ch <'f') return(ch - 'a' + 10);
    if (ch >= 'A' && ch <'F') return(ch - 'A' + 10);
    return(-1);
}

    // For now AirExch only on relays.
bool childHasAirExch(byte nod)
{
    if (child[nod - 1].relay1 == AirExchangerIn) return(true);
    if (child[nod - 1].relay1 == AirExchangerOut) return(true);
    if (child[nod - 1].relay2 == AirExchangerIn) return(true);
    if (child[nod - 1].relay2 == AirExchangerOut) return(true);
    return(false);
}

    // For now IntFans are only on SwiPwr
bool childHasIntFan(byte nod)
{
    if (child[nod - 1].swiPwr1 == InternalFan) return(true);
    if (child[nod - 1].swiPwr2 == InternalFan) return(true);
    return(false);
}

    // Decide next actionType. This is the manager for active nodeNum.  Parent  = node 0.
    // Then scan through the child[] for the next resource item we should handle.
    // The resources may change dynamically.  There are presently 4 basic child
    // resource outputs: 2 rlys & 2 SwiPwrs.  Set actionType, outputType, resourceType.
void indexNextResource(void)
{
    static byte oldNodeNum, outputCtr = 0;

    if (nodeNum == 0)
    {
        actionType = SvcParentResources;
        nodeNum = nextNodeNum(nodeNum);
        return;
    }

    if (nodeNum != oldNodeNum)
    {
        actionType = MsgAttention;
        oldNodeNum = nodeNum;
        return;
    }

    if ((childHasIntFan(nodeNum)) && (actionType != MsgAskRHumid))
    {
        actionType = MsgAskRHumid;      // Local RH, not outside
        return;
    }

    if ((childHasAirExch(nodeNum)) && (actionType != MsgAskTemper))
    {
        actionType = MsgAskTemper;      // For now just use outside T
        return;
    }

    do
    {
        if ((outputCtr == 0) && (child[nodeNum - 1].relay1 != Free))
        {
            outputType = Relay1;
            resourceType = child[nodeNum - 1].relay1;
            return;
        }
        else outputCtr++;

        if ((outputCtr == 1) && (child[nodeNum - 1].relay2 != Free))
        {
            outputType = Relay2;
            resourceType = child[nodeNum - 1].relay2;
            return;
        }
        else outputCtr++;

        if ((outputCtr == 2) && (child[nodeNum - 1].swiPwr1 != Free))
        {
            outputType = SwiPwr1;
            resourceType = child[nodeNum - 1].swiPwr1;
            return;
        }
        else outputCtr++;

        if ((outputCtr == 3) && (child[nodeNum - 1].swiPwr2 != Free))
        {
            outputType = SwiPwr2;
            resourceType = child[nodeNum - 1].swiPwr2;
            return;
        }
        else outputCtr = 0;
    } while(nextNodeNum(nodeNum));
}

int messageAskRHumid(void)
{
    char bfr[8];
    float fVal;

    sprintf(ioBfr, "H?%c\r", nodeNum + '0');    // Must end in CR only
    putStr(ioBfr, true);
    rs485TransmitEna(0);
    if (getStr(ioBfr, TIMEOUT_PNET) < 1) return(-1);    // No one there; end of story.
    if(ioBfr[0] != 'h') return(-2);
    if(ioBfr[1] != 'k') return(-3);
    if(ioBfr[2] != nodeNum + '0') return(-4);
    strncpy(bfr, &ioBfr[3], 7);
    bfr[7] = 0;
    fVal = atof(bfr);
    if ((fVal >= REASONABLE_RH_MIN) && (fVal <= REASONABLE_RH_MAX))
        child[nodeNum - 1].localRHumid = fVal;
    else return(-5);
    return(nodeNum);
}

int messageAskTemper(void)
{
    char bfr[8];
    float fVal;

    sprintf(ioBfr, "T?%c\r", nodeNum + '0');    // Must end in CR only
    putStr(ioBfr, true);
    rs485TransmitEna(0);
    if (getStr(ioBfr, TIMEOUT_PNET) < 1) return(-1);    // No one there; end of story.
    if(ioBfr[0] != 't') return(-2);
    if(ioBfr[1] != 'k') return(-3);
    if(ioBfr[2] != nodeNum + '0') return(-4);
    strncpy(bfr, &ioBfr[3], 7);
    bfr[7] = 0;
    fVal = atof(bfr);
    if ((fVal >= REASONABLE_TEMP_MIN) && (fVal <= REASONABLE_TEMP_MAX))
        child[nodeNum - 1].localTempF = fVal;
    else return(-5);
    return(nodeNum);
}

    // -------------------------------------------
    // Set/clr child[].status CHILD_NODE_ACTIVE
    // Returns nodeNum on success, 0 > code o.w.
    // TODO use miaCtr to allow rare lost comms
int messageAttention(void)
{
    extern char pnetVer;
    int bfr, bfr2;
    sprintf(ioBfr, "AT%c\r", nodeNum + '0');    // Must end in CR only
    putStr(ioBfr, true);
    child[nodeNum - 1].status &= ~CHILD_ST_NODE_ACTIVE;
    rs485TransmitEna(0);
    if (getStr(ioBfr, TIMEOUT_PNET) < 1) return(-1);    // No one there; end of story.
    if(ioBfr[0] != 'a') return(-2);
    if(ioBfr[1] != 'k') return(-3);
    if(ioBfr[2] != nodeNum + '0') return(-4);
    if(ioBfr[3] != pnetVer) return(-5);
    if ((bfr = ascii2Hex(ioBfr[4])) >= 0) bfr2 = bfr << 4;
    if ((bfr = ascii2Hex(ioBfr[5])) >= 0) bfr2 += bfr;
    child[nodeNum -1].status &= 0xFF00;
    child[nodeNum -1].status += bfr2;
    child[nodeNum - 1].status |= CHILD_ST_NODE_ACTIVE;
    return(nodeNum);
}

    // Relays presently used only for AirCond, Heater, Dehum, Humid.
    // indexNextResource() has determined: nodeNum, outputType, resourceType
    // resourceManager() has determined: climateStatus
    // But we make the climate call here.  Pass back any neg exception codes.
int messageRelay(void)    
{
    extern struct operatingParms_struct oP;
    extern unsigned sysFault;
    char relayChar = 0, polarityChar = 0;

    if (outputType == Relay1) relayChar = 'a';          // Pnet syntax
    else if (outputType == Relay2) relayChar = 'b';
    else return(-10);                                   // System error OW

    switch(resourceType)
    {
        case AirConditioner:
            if (climateStatus & TOO_HOT)
            {
                if (oP.sysStat & ST_AIR_EXCHGR_ON) polarityChar = '-';
                else polarityChar = '+';
            }
            else polarityChar = '-';       // OW just turn that thing off
            break;

        case Heater:
            if (climateStatus & TOO_COLD)
            {
                if (oP.sysStat & ST_AIR_EXCHGR_ON) polarityChar = '-';
                else polarityChar = '+';
            }
            else polarityChar = '-';
            break;

        case Humidifier:
            if (climateStatus & TOO_DRY) polarityChar = '+';
            else polarityChar = '-';
            break;

        case DeHumidifier:
            if (climateStatus & TOO_DAMP) polarityChar = '+';
            else polarityChar = '-';
            break;

        default:
            return(-11);        // OW system error
    }

    sprintf(ioBfr, "K%c%c%c\r", nodeNum + '0', relayChar, polarityChar);
 
    putStr(ioBfr, true);                           
    rs485TransmitEna(0); 
    if (getStr(ioBfr, TIMEOUT_PNET) < 1) { sysFault |= FLT_LOSTCHILD; return(-1); }    // No one there; end of story.
    if (ioBfr[0] != 'K') { sysFault |= FLT_COMMUNICATION; return(-2); }                // Protocol fail
    if(ioBfr[1] != 'k') { sysFault |= FLT_COMMUNICATION;  return(-2); }
    if(ioBfr[2] != nodeNum + '0') { sysFault |= FLT_COMMUNICATION; return(-2); }
    if(ioBfr[3] != relayChar) { sysFault |= FLT_COMMUNICATION; return(-2); }
    if(ioBfr[4] != polarityChar) { sysFault |= FLT_COMMUNICATION; return(-2); }
    return(nodeNum);
}

    // SwiPwrs presently used only for Internal fans
    // indexNextResource() has determined: nodeNum, outputType, resourceType
    // We must have already determined the associated local Rhumid.
int messageSwiPwr(void)
{
    extern unsigned sysFault;
    char swipwrChar = 0, polarityChar = 0;

    if (outputType == SwiPwr1) swipwrChar = 'a';          // Pnet syntax
    else if (outputType == SwiPwr2) swipwrChar = 'b';
    else return(-10);                                   // System error OW

    if (child[nodeNum - 1].localRHumid > LOCAL_RH_MAX) polarityChar = '+';
    else polarityChar = '-';

    sprintf(ioBfr, "P%c%c%c\r", nodeNum + '0', swipwrChar, polarityChar);

    putStr(ioBfr, true);
    rs485TransmitEna(0); 
    if (getStr(ioBfr, TIMEOUT_PNET) < 1) { sysFault |= FLT_LOSTCHILD; return(-1); }    // No one there; end of story.
    if (ioBfr[0] != 'P') { sysFault |= FLT_COMMUNICATION; return(-2); }                // Protocol fail
    if(ioBfr[1] != 'k') { sysFault |= FLT_COMMUNICATION;  return(-2); }
    if(ioBfr[2] != nodeNum + '0') { sysFault |= FLT_COMMUNICATION; return(-2); }
    if(ioBfr[3] != swipwrChar) { sysFault |= FLT_COMMUNICATION; return(-2); }
    if(ioBfr[4] != polarityChar) { sysFault |= FLT_COMMUNICATION; return(-2); }
    return(nodeNum);
}

    // Nodes range form 0 (parent) - 8.  What is the next valid node?
byte nextNodeNum(byte nodeStart)
{
    byte nod;

    if (nodeStart == NUM_CHILDREN) return(0);   // Return to parent.
    if (nodeStart == 0) nodeStart = 1;
    for (nod = nodeStart; nod <= NUM_CHILDREN; nod++)
    {
        if (child[nod - 1].status & CHILD_ST_NODE_DEFINED) return(nod);
    }
    return(0);      // Ie, we didn't find a nonzero node
}

  // -----------------------------------------
    // Also updates our discomfort timers
int serviceParentResources(void)
{
    extern struct operatingParms_struct oP;
    resourceEvaluate.dayTotalCounter++;         // These are all reset at midnight

    if (climateStatus & TOO_HOT)
    {
        resourceEvaluate.tooHotTimer++;
        if ( !(oP.sysStat & ST_AIR_EXCHGR_ON))      // Air exchanger trumps AC, heater
        {
            if (parent.relay1 == AirConditioner) RELAY1 = 1;
            if (parent.relay2 == AirConditioner) RELAY2 = 1;
        }
        if (parent.relay1 == Heater) RELAY1 = 0;
        if (parent.relay2 == Heater) RELAY2 = 0;
    }

    if (climateStatus & TOO_COLD)
    {
        resourceEvaluate.tooColdTimer++;
        if ( !(oP.sysStat & ST_AIR_EXCHGR_ON))
        {
            if (parent.relay1 == Heater) RELAY1 = 1;
            if (parent.relay2 == Heater) RELAY2 = 1;
        }
        if (parent.relay1 == AirConditioner) RELAY1 = 0;
        if (parent.relay2 == AirConditioner) RELAY2 = 0;
    }

    if (climateStatus & TOO_DAMP)
    {
        resourceEvaluate.tooDampTimer++;
        if (parent.relay1 == DeHumidifier) RELAY1 = 1;
        if (parent.relay2 == DeHumidifier) RELAY2 = 1;
    }
    
    if (climateStatus & TOO_DRY)
    {
        resourceEvaluate.tooDryTimer++;
        if (parent.relay1 == Humidifier) RELAY1 = 1;
        if (parent.relay2 == Humidifier) RELAY2 = 1;
    }

    return(1);      // All good
}


