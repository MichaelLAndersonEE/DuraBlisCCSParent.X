/* File:   BW-CCS.h  Project wide defines, typedefs, structs, bitfields & externs
 * Author: Michael L Anderson
 * Contact: MichaelLAndersonEE@gmail.com
 * Platform: PIC32MX350F256H on DB-CCS-Main_v2.x board.  
 * Created: 16 May 14
 */

#ifndef DURABLISCCSPARENT_H
#define	DURABLISCCSPARENT_H

#include <stdbool.h>    // To use bool type throughout

#define SET_TEMP_MAX        95
#define SET_TEMP_MIN        55
#define REASONABLE_TEMP_MAX 180
#define REASONABLE_TEMP_MIN -60
#define SET_RH_MAX          80
#define SET_RH_MIN          25
#define LOCAL_RH_MAX        55      // Turn on IntFans
#define REASONABLE_RH_MAX  100
#define REASONABLE_RH_MIN    0
#define CAL_FACTOR_MAX      1.6
#define CAL_FACTOR_MIN      0.4

    //  Primary external osc freq
#define SYS_FREQ	(25000000)
#define IO_BFR_SIZE     65          // Volatile general purpose IO buffer
#define NUM_CHILDREN    8
#define UID_SIZE        7           // Number chars including ASCII-0 in Unique Identifier, 000000 - 999999
#define SID_SIZE        11          // Zip + 4

typedef unsigned char byte;
extern char ioBfr[];
void delay_us(unsigned t);        // Dumb delay fcn.

  // This is awkward, but need to keep these packaged for SEEPROM
struct operatingParms_struct
{
    byte initializer;           // [1]   
    unsigned sysStat;           // [2 bytes]
    unsigned dlRecordsSaved;    // [2]
    double setPointTempF;       // [4]
    double setPointRelHum;      // [4] All hums normalized to 100
    double temperCalFactor;     // [4] For Fahrenheit
    double rhumidCalFactor;     // [4]
    double deadBandFactor;      // [4] Typ 0.2.  Control is based on (1.0 +/- deadBandFactor)
    byte   channelEnable;       // [1] 0 - 7
    byte checkSum;              // [1]  Just a space, smem will calc & fill
};

    // Parent sysFault bits  TODO review set & clr
    // These may be cleared by user in Main window, or in pwr cycle.
#define FLT_LOSTCHILD            0x8000
#define FLT_CHILDFAULT           0x4000
#define FLT_PARENT_TSENSOR       0x2000
#define FLT_PARENT_HSENSOR       0x1000
#define FLT_CANNOTCONTROLTEMP    0x0800
#define FLT_CANNOTCONTROLHUM     0x0400
#define FLT_SYSTEMERROR          0x0200
#define FLT_SMEM                 0x0100
#define FLT_SENSORSNOTCALIB      0x0080      // Clear both T & RH cal'd
#define FLT_CLOCKNOTSET          0x0040      // Clear when RTCC set
#define FLT_PARENT_TSEN_NOISY    0x0020
#define FLT_PARENT_RHSEN_NOISY   0x0010
#define FLT_COMMUNICATION        0x0008

    // Parent sysStat bits.  Saved every 5 sec to SEEPROM.
//#define ST_CLOCK_SET            0x01
#define ST_ECHO_SERIALIN        0x02
#define ST_USE_CELSIUS          0x04
#define ST_USE_DEWPOINT         0x08
#define ST_AIR_EXCHGR_ON        0x10

    /**** Hardware mapping definitions...   ****/

    // Analog channels
#define ANCH_ISEN1      22   // AN22 U7.1 = RE5
#define ANCH_ISEN2      23   // AN23 U7.2 = RE6
#define ANCH_ISEN3      27   // AN27 U7.3 = RE7
#define ANCH_ISEN4       5   // AN5 U7.11 = RB5
#define ANCH_ISEN5       4   // AN4 U7.12 = RB4
#define ANCH_ISEN6       1   // AN9 U7.15 = RB1
#define ANCH_ISEN7       6   // AN6 U7.17 = RB6
#define ANCH_ISEN8       7   // AN7 U7.18 = RB7
#define ANCH_RELHUM      8   // AN8 U7.21 = RB8
#define ANCH_TEMPER      9   // AN9 U7.22 = RB9

    // Hardware lines
#define LED_GREEN   LATEbits.LATE4      // o0 U7.64
#define LED_RED     LATEbits.LATE3      // o0 U7.63
#define BUZZER      PORTFbits.RF6       // Uses PWM on RPF6

#define LCD_WR_n    LATDbits.LATD3      // o0 IC4.51
#define LCD_RD_n    LATEbits.LATE0      // o0 IC4.60
#define LCD_A0      LATEbits.LATE1      // o0 IC4.61
#define LCD_RES_n   LATDbits.LATD2      // o1 IC4.50
#define LCD_CS1_n   LATDbits.LATD1      // o1 IC4.49
#define LCD_WD0     LATDbits.LATD4      // o0 U7.52
#define LCD_WD1     LATDbits.LATD5      // o0 U7.53
#define LCD_WD2     LATDbits.LATD6      // o0 U7.54
#define LCD_WD3     LATDbits.LATD7      // o0 U7.55
#define LCD_WD4     LATDbits.LATD8      // o0 U7.42
#define LCD_WD5     LATDbits.LATD9      // o0 U7.43
#define LCD_WD6     LATDbits.LATD10     // o0 U7.44
#define LCD_WD7     LATDbits.LATD11     // o0 U7.45
#define LCD_RD0     PORTDbits.RD4       // For reads..
#define LCD_RD1     PORTDbits.RD5
#define LCD_RD2     PORTDbits.RD6
#define LCD_RD3     PORTDbits.RD7
#define LCD_RD4     PORTDbits.RD8
#define LCD_RD5     PORTDbits.RD9
#define LCD_RD6     PORTDbits.RD10
#define LCD_RD7     PORTDbits.RD11

//#define RS232_ENA_n  LATFbits.LATF5       // o1 U7.32
//#define RS232_SHDN_n LATFbits.LATF4       // o1 U7.31
#define RS485_RE_n   LATBbits.LATB13      // o1 IC4.28
#define RS485_DE     LATBbits.LATB12      // o1 IC4.27
#define SMEM_CS_n    LATGbits.LATG9       // o1 IC4.8
#define RELAY1       LATBbits.LATB14      // o1 IC4.29
#define RELAY2       LATBbits.LATB15      // o1 IC4.30

#define IIC_SCL     PORTGbits.RG2         //LATGbits.LATG2
#define IIC_SDA     PORTGbits.RG3           //LATGbits.LATG3
#define IIC_SDA_TRIS    TRISGbits.TRISG3

//#define STD_KEY1    PORTGbits.RG2       // Mechanical MOM keys
//#define STD_KEY2    PORTGbits.RG3
//#define STD_KEY3    PORTDbits.RD0
//#define STD_KEY4    PORTEbits.RE2
#endif	
