/* File:   smem.c  SEEPROM SPI2-based functions, incl datalog
 * Author: Michael L Anderson
 * Contact: MichaelLAndersonEE@gmail.com
 * Platform: PIC32MX350F256H on DB-CCS-Main_v2.x board
 * SEEPROM: 25AA128, 16 Kbyte, 256 64-byte pages
 * Microchip is little-endian, so I keep to this convention here. Eg, 0x01020304 is
 * stored byte sequentially as 0x04, 0x03, 0x02, 0x01.
 * Created: 02 Oct 14
 */

#include <xc.h>
#include <string.h>
#include "DuraBlisCCSParent.h"
#include "smem.h"
#include "serial.h"
#include "time.h"
//#include "keypad.h"
#include "resources.h"

    // SMEM semantics
#define SMEM_DUMMY  0x00
#define SMEM_READ   0x03
#define SMEM_WRITE  0x02
#define SMEM_WRDI   0x04
#define SMEM_WREN   0x06
#define SMEM_RDSR   0x05
#define SMEM_WRSR   0x01

#define SMEM_NUM_PAGES      256
//#define SMEM_PAGE_SIZE       64
#define SMEM_ARRAY_SIZE      64     // Max bytes in buffer for any one rd/wr block
#define SMEM_ADDR_TIME        0     // Page 0 for time save.
#define SMEM_ADDR_PARMS      64     // Page 1 for parms (cal consts, etc)
#define SMEM_ADDR_UID       128     // Page 2 for UID string
#define SMEM_ADDR_ISEN_CAL  192     // Page 3 for iSen cal factors
#define SMEM_ADDR_RESMTX    256     // Page 4 for resourceMatrix
#define SMEM_ADDR_DATALOG   320     // Pages 5..205 for DL

#define DL_MAX_RECORDS     1600     // 8 doubles per page x 200 pgs
#define DL_RECORD_SIZE        8     // Bytes, 2 doubles now
#define DL_RECORDS_PER_PAGE   8     // 64 bytes per pg / (4 bytes per float * 2 doubles per record)
#define DL_PAGES            200

static int smem_ReadArray(unsigned addr, byte *arrayPtr, unsigned arraySize);
static int smem_WriteArray(unsigned addr, byte *arrayPtr, unsigned arraySize);
static bool smem_Busy(void);
static byte spi2_WRBuffer(byte datum);
static double unpackDbl(byte idx, byte *cs);
static void packDbl(byte idx, double datum, byte *cs);
static unsigned unpackUns(byte idx, byte *cs);
static void packUns(byte idx, unsigned datum, byte *cs);

extern struct t_struct time;                    // Page 0
extern struct operatingParms_struct oP;         // Page 1
extern char uniqueID[UID_SIZE];                 // Page 2
extern double iSenCalFactor [NUM_CHILDREN];     // Page 3
extern struct res_struct resourceMatrix;        // Page 4.  Datalog uses Pages 5..205

    // Volatile
extern float temperNowF, rhumidNow;
static unsigned dlPage;
static byte dlPageIdx;      // Bytes on a page
static byte smemBfr[SMEM_ARRAY_SIZE];   // All smem traffic here.  Use ioBfr for auxilliary.
static union pack_union
{
    byte byte_pk[4];
    double dubPrec_pk;          // XC32 double is 4 byte
    unsigned long unsLong_pk;   // Ditto
    unsigned unsShort_pk;       // 2 byte, jagged sizes okay in unions
} pack;

    // TODO regenerate actual times
int smemDatalogReport(void)
{   
    unsigned r;
    double T, RH;   
    unsigned address = SMEM_ADDR_DATALOG;

    if (oP.dlRecordsSaved == 0)
    {
        putStr("\tNo datalog records saved.\n\r", true);
        return(0);
    }                      

        // Start at present location, then work down.
    //address = SMEM_ADDR_DATALOG + dlPage * DL_RECORDS_PER_PAGE + dlPageIdx;

    sprintf(ioBfr, "\n\r// #,\toF,\t%%RH\t[%d records]\n\r", oP.dlRecordsSaved);
    putStr(ioBfr, true);

    for (r = 0; r < oP.dlRecordsSaved; r++)
    {
        smem_ReadArray(address, smemBfr, DL_RECORD_SIZE);
        pack.byte_pk[3]  = smemBfr[0];
        pack.byte_pk[2]  = smemBfr[1];
        pack.byte_pk[1]  = smemBfr[2];
        pack.byte_pk[0]  = smemBfr[3];
        T = pack.dubPrec_pk;
        pack.byte_pk[3]  = smemBfr[4];
        pack.byte_pk[2]  = smemBfr[5];
        pack.byte_pk[1]  = smemBfr[6];
        pack.byte_pk[0]  = smemBfr[7];
        RH = pack.dubPrec_pk;

        if ((T > REASONABLE_TEMP_MIN && T < REASONABLE_TEMP_MAX) && (RH > REASONABLE_RH_MIN && RH < REASONABLE_RH_MAX))
        {
            sprintf(ioBfr, "%3d, \t%2.1f, \t%2.1f,\n\r", r + 1, T, RH);
            putStr(ioBfr, true);
        }
        else
        {
            sprintf(ioBfr, "%3d, \t0.0, \t0.0,\n\r", r + 1);
            putStr(ioBfr, true);
        }

        address += DL_RECORD_SIZE;      // TODO wraparound
        petTheDog();
    }
    return(r);        
}

    // Called every time t (nom 5 min).  Smem writes latest T & RH as doubles.
int smemDatalog(void)
{
    static byte dlBfr[SMEM_ARRAY_SIZE];
 
    pack.dubPrec_pk = temperNowF;
    dlBfr[dlPageIdx] = pack.byte_pk[3];       // Little-endian. The first shall be last.
    dlBfr[dlPageIdx + 1] = pack.byte_pk[2];
    dlBfr[dlPageIdx + 2] = pack.byte_pk[1];
    dlBfr[dlPageIdx + 3] = pack.byte_pk[0];
    pack.dubPrec_pk = rhumidNow;
    dlBfr[dlPageIdx + 4] = pack.byte_pk[3];
    dlBfr[dlPageIdx + 5] = pack.byte_pk[2];
    dlBfr[dlPageIdx + 6] = pack.byte_pk[1];
    dlBfr[dlPageIdx + 7] = pack.byte_pk[0];

    if (smem_WriteArray(SMEM_ADDR_DATALOG + (dlPage * SMEM_ARRAY_SIZE), dlBfr, SMEM_ARRAY_SIZE) < SMEM_ARRAY_SIZE) return(-1);
    dlPageIdx += DL_RECORD_SIZE;
    if (dlPageIdx >= SMEM_ARRAY_SIZE)
    {
        dlPageIdx = 0;
        if (dlPage++ > DL_PAGES) dlPage = 0;    // Wrap around
    }
    oP.dlRecordsSaved++;
    if (smemWriteParms(SMEM_SILENT) < 0) return(-2);       // To record dlRecordsSaved
    return(SMEM_ARRAY_SIZE);
}

    // Called on startup reset and as factory setting restore of operating parms
    // TODO One non-recursive retry. 
    // Returns num bytes read on success or neg failure code.
int smemReadParms(byte mode)
{
    byte chkSum = 0;
    struct operatingParms_struct oPBfr;
    byte d, ch, *dPtr;

    if (mode == SMEM_LOQUACIOUS) putStr("\tsRP Test...\r\n", true);
    if (smem_ReadArray(SMEM_ADDR_PARMS, smemBfr, SMEM_ARRAY_SIZE) < SMEM_ARRAY_SIZE)
    {
        if (mode == SMEM_LOQUACIOUS) putStr("\tsRA read 1 fail.\r\n", true);
        return(-1);
    }

    if (smemBfr[0] != 0x5A)
    {
        if (mode == SMEM_LOQUACIOUS) putStr("\tfHI\n\r", true);
        factoryHardInit();
        smemWriteParms(mode);
        return(0);
    }

        // Matches order in sWP
    oPBfr.sysStat = unpackUns(1, &chkSum);
    oPBfr.dlRecordsSaved = unpackUns(3, &chkSum);
    oPBfr.setPointTempF = unpackDbl(5, &chkSum);
    oPBfr.setPointRelHum = unpackDbl(9, &chkSum);
    oPBfr.temperCalFactor = unpackDbl(13, &chkSum);
    oPBfr.rhumidCalFactor = unpackDbl(17, &chkSum);
    if (smemBfr[21] == chkSum)
    {
        oP = oPBfr;
        if (mode == SMEM_LOQUACIOUS) putStr("\tsRP confirmed\n\r", true);
    }
    else if (mode == SMEM_LOQUACIOUS) putStr("\tsRP CS fail\n\r", true);

    if (mode == SMEM_LOQUACIOUS)
    {
        sprintf(ioBfr, "\tsysStat: %04X\r\n", oPBfr.sysStat); putStr(ioBfr, true);
        sprintf(ioBfr, "\tdlRS: %d\r\n", oPBfr.dlRecordsSaved); putStr(ioBfr, true);
        sprintf(ioBfr, "\tsPTF: %3.02f\r\n", oPBfr.setPointTempF); putStr(ioBfr, true);
        sprintf(ioBfr, "\tsPRH: %3.02f\r\n", oPBfr.setPointRelHum); putStr(ioBfr, true);
        sprintf(ioBfr, "\ttCalF: %3.02f\r\n", oPBfr.temperCalFactor); putStr(ioBfr, true);
        sprintf(ioBfr, "\trhCalF: %3.02f\r\n", oPBfr.rhumidCalFactor); putStr(ioBfr, true);
        sprintf(ioBfr, "\tCS sto: %02X, calc: %02X", smemBfr[21], chkSum); putStr(ioBfr, true);
    }
    petTheDog();
        // Now do UID
    if (smem_ReadArray(SMEM_ADDR_UID, smemBfr, UID_SIZE) < UID_SIZE)
    {
        if (mode == SMEM_LOQUACIOUS) putStr("\tsRA read 2 fail.\r\n", true);
        return(-12);
    }
    smemBfr[UID_SIZE] = 0;
    for (d = 0; d < UID_SIZE; d++)
    {
        ch = smemBfr[d];        // Limit to ASCII-Z and printables
        if ((ch == 0) || ((ch >= 32) && (ch <= 127)))
            uniqueID[d] = ch;
    }    
    if (mode == SMEM_LOQUACIOUS)
    {
        sprintf(ioBfr, "\tuID: %s\r\n", uniqueID);
        putStr(ioBfr, true);
    }
    petTheDog();

    if (smem_ReadArray(SMEM_ADDR_RESMTX, smemBfr, SMEM_ARRAY_SIZE) < SMEM_ARRAY_SIZE) return(-20);

        // Obviously, this all must match what is written in sWP
//    pack.byte_pk[3] = smemBfr[0]; pack.byte_pk[2] = smemBfr[1]; pack.byte_pk[1] = smemBfr[2]; pack.byte_pk[0] = smemBfr[3];     // LSB first
//    resourceMatrix.airConditioner = pack.unsLong_pk;
//    if (mode == SMEM_LOQUACIOUS) { sprintf(ioBfr, "\trM.AC: %08lX\r\n", resourceMatrix.airConditioner); putStr(ioBfr, true); }
//
//    pack.byte_pk[3] = smemBfr[4]; pack.byte_pk[2] = smemBfr[5]; pack.byte_pk[1] = smemBfr[6]; pack.byte_pk[0] = smemBfr[7];
//    resourceMatrix.airExchanger = pack.unsLong_pk;
//    if (mode == SMEM_LOQUACIOUS) { sprintf(ioBfr, "\trM.AX: %08lX\r\n", resourceMatrix.airExchanger); putStr(ioBfr, true); }
//
//    pack.byte_pk[3] = smemBfr[8]; pack.byte_pk[2] = smemBfr[9]; pack.byte_pk[1] = smemBfr[10]; pack.byte_pk[0] = smemBfr[11];
//    resourceMatrix.dehumidifier = pack.unsLong_pk;
//    if (mode == SMEM_LOQUACIOUS) { sprintf(ioBfr, "\trM.DH: %08lX\r\n", resourceMatrix.dehumidifier); putStr(ioBfr, true); }
//
//    pack.byte_pk[3] = smemBfr[12]; pack.byte_pk[2] = smemBfr[13]; pack.byte_pk[1] = smemBfr[14]; pack.byte_pk[0] = smemBfr[15];
//    resourceMatrix.heater = pack.unsLong_pk;
//    if (mode == SMEM_LOQUACIOUS) { sprintf(ioBfr, "\trM.HE: %08lX\r\n", resourceMatrix.heater); putStr(ioBfr, true); }
//
//    pack.byte_pk[3] = smemBfr[16]; pack.byte_pk[2] = smemBfr[17]; pack.byte_pk[1] = smemBfr[18]; pack.byte_pk[0] = smemBfr[19];
//    resourceMatrix.humidifier = pack.unsLong_pk;
//    if (mode == SMEM_LOQUACIOUS) { sprintf(ioBfr, "\trM.HU: %08lX\r\n", resourceMatrix.humidifier); putStr(ioBfr, true); }
//
//    pack.byte_pk[3] = smemBfr[20]; pack.byte_pk[2] = smemBfr[21]; pack.byte_pk[1] = smemBfr[22]; pack.byte_pk[0] = smemBfr[23];
//    resourceMatrix.intFanTH = pack.unsLong_pk;
//    if (mode == SMEM_LOQUACIOUS) { sprintf(ioBfr, "\trM.IF: %08lX\r\n", resourceMatrix.intFanTH); putStr(ioBfr, true); }
//
//    pack.byte_pk[1] = smemBfr[24]; pack.byte_pk[0] = smemBfr[25];
//    resourceMatrix.floodSensor = pack.unsShort_pk;
//    if (mode == SMEM_LOQUACIOUS) { sprintf(ioBfr, "\trM.FS: %04X\r\n", resourceMatrix.floodSensor); putStr(ioBfr, true); }
//
//    resourceMatrix.outsideTH = smemBfr[26];
//    if (mode == SMEM_LOQUACIOUS) { sprintf(ioBfr, "\trM.XS: %04X\r\n", resourceMatrix.outsideTH); putStr(ioBfr, true); }
//    
    return(SMEM_ARRAY_SIZE);
}

    // Little-endian unsigned pack
void packUns(byte idx, unsigned datum, byte *cs)
{
    *cs += (smemBfr[idx] = (byte) datum);
    *cs += (smemBfr[idx+1] = (byte) (datum >> 8));
}

unsigned unpackUns(byte idx, byte *cs)
{
    unsigned retVal;
    *cs += (retVal = smemBfr[idx]);  // Little byte first
    retVal += ((unsigned) smemBfr[idx+1]) << 8;     // Big byte
    *cs += smemBfr[idx+1];
    return(retVal);
}

double unpackDbl(byte idx, byte *cs)
{
    double retVal;

    *cs += (pack.byte_pk[0] = smemBfr[idx]);    // LSB
    *cs += (pack.byte_pk[1] = smemBfr[idx+1]);
    *cs += (pack.byte_pk[2] = smemBfr[idx+2]);
    *cs += (pack.byte_pk[3] = smemBfr[idx+3]);
    retVal = pack.dubPrec_pk;
    return(retVal);
}

    // Little-endian double pack
void packDbl(byte idx, double datum, byte *cs)
{
    pack.dubPrec_pk = datum;
    *cs += (smemBfr[idx] = pack.byte_pk[0]);    // LSB
    *cs += (smemBfr[idx+1] = pack.byte_pk[1]);
    *cs += (smemBfr[idx+2] = pack.byte_pk[2]);
    *cs += (smemBfr[idx+3] = pack.byte_pk[3]);
}

    // Called periodically as operating parm backup
    // Returns num bytes written on success or neg failure code.
    // Assume data in struct / union not contiguous.
int smemWriteParms(byte opMode)
{
    extern char uniqueID[UID_SIZE];
    byte d, chkSum = 0;

    smemBfr[0] = 0x5A;      // Initializer, not checksummed
    packUns(1, oP.sysStat, &chkSum);
    packUns(3, oP.dlRecordsSaved, &chkSum);
    packDbl(5, oP.setPointTempF, &chkSum);
    packDbl(9, oP.setPointRelHum, &chkSum);
    packDbl(13, oP.temperCalFactor, &chkSum);
    packDbl(17, oP.rhumidCalFactor, &chkSum);
    smemBfr[21] = chkSum;

    if (opMode == SMEM_LOQUACIOUS)
    {
        putStr("\n\r\tsWP:\r\n", true);
        for (d = 0; d < SMEM_ARRAY_SIZE; d++)
        {
            sprintf(ioBfr, "%02X ", smemBfr[d]);
            putStr(ioBfr, true);
            if (d % 10 == 9) putStr("\r\n", true);
        }
    }

    if (smem_WriteArray(SMEM_ADDR_PARMS, smemBfr, SMEM_ARRAY_SIZE) < SMEM_ARRAY_SIZE)
    {
        if (opMode == SMEM_LOQUACIOUS) putStr("\ts_WA fail -1\n\r", true);
        return(-1);
    }

    for (d = 0; d < UID_SIZE; d++)
        smemBfr[d] = uniqueID[d];
    smemBfr[d] = 0;
    if (smem_WriteArray(SMEM_ADDR_UID, smemBfr, UID_SIZE + 1) < UID_SIZE + 1)
    {
        if (opMode == SMEM_LOQUACIOUS) putStr("\ts_WA fail -2\n\r", true);
        return(-2);
    }

       // TODO this is trashing the vals
//    pack.unsLong_pk = resourceMatrix.airConditioner;
//    smemBfr[0] = pack.byte_pk[0]; smemBfr[1] = pack.byte_pk[1]; smemBfr[2] = pack.byte_pk[2]; smemBfr[3] = pack.byte_pk[3];
//
//    pack.unsLong_pk = resourceMatrix.airExchanger;
//    smemBfr[4] = pack.byte_pk[3]; smemBfr[5] = pack.byte_pk[2]; smemBfr[6] = pack.byte_pk[1]; smemBfr[7] = pack.byte_pk[0];
//    pack.unsLong_pk = resourceMatrix.dehumidifier;
//    smemBfr[8] = pack.byte_pk[3]; smemBfr[9] = pack.byte_pk[2]; smemBfr[10] = pack.byte_pk[1]; smemBfr[11] = pack.byte_pk[0];
//    pack.unsLong_pk = resourceMatrix.heater;
//    smemBfr[12] = pack.byte_pk[3]; smemBfr[13] = pack.byte_pk[2]; smemBfr[14] = pack.byte_pk[1]; smemBfr[15] = pack.byte_pk[0];
//    pack.unsLong_pk = resourceMatrix.humidifier;
//    smemBfr[16] = pack.byte_pk[3]; smemBfr[17] = pack.byte_pk[2]; smemBfr[18] = pack.byte_pk[1]; smemBfr[19] = pack.byte_pk[0];
//    pack.unsLong_pk = resourceMatrix.intFanTH;
//    smemBfr[20] = pack.byte_pk[3]; smemBfr[21] = pack.byte_pk[2]; smemBfr[22] = pack.byte_pk[1]; smemBfr[23] = pack.byte_pk[0];
//    pack.unsShort_pk = resourceMatrix.floodSensor;
//    smemBfr[24] = pack.byte_pk[1]; smemBfr[25] = pack.byte_pk[0];
//    smemBfr[26] = resourceMatrix.outsideTH;

    if (smem_WriteArray(SMEM_ADDR_RESMTX, smemBfr, SMEM_ARRAY_SIZE) < SMEM_ARRAY_SIZE)
        return(-3);
    
    return(2 * SMEM_ARRAY_SIZE);      // 2 pages written
}

int smem_ReadArray(unsigned addr, byte *arrayPtr, unsigned arraySize)
{
    unsigned by;

    if (smem_Busy()) return(0);        // Pause till free
    SMEM_CS_n = 0;
    spi2_WRBuffer(SMEM_READ);
    spi2_WRBuffer(addr >> 8);
    spi2_WRBuffer(addr);

    for (by = 0; by < arraySize; by++)
    {
        arrayPtr[by] = spi2_WRBuffer(SMEM_DUMMY);
    }
    SMEM_CS_n = 1;
    return(by);
}

int smem_WriteArray(unsigned addr, byte *arrayPtr, unsigned arraySize)
{
    unsigned by;
   
    if (smem_Busy()) return(0);        // Pause till free
    SMEM_CS_n = 0;
    spi2_WRBuffer(SMEM_WREN);    //
    SMEM_CS_n = 1;
    delay_us(1);
    SMEM_CS_n = 0;
    spi2_WRBuffer(SMEM_WRITE);
    spi2_WRBuffer(addr >> 8);
    spi2_WRBuffer(addr);

    for (by = 0; by < arraySize; by++)
    {
//        if ((addr + by) % 64 == 0 && by != 0)  // Hit 64 byte page boundary
//        {
//            SMEM_CS_n = 1;
//            if (smem_Busy()) return(0);        // Pause till free
//            SMEM_CS_n = 0;
//            spi2_WRBuffer(SMEM_WREN);
//            SMEM_CS_n = 1;
//            delay_us(1);
//            SMEM_CS_n = 0;
//            spi2_WRBuffer(SMEM_WRITE);
//            spi2_WRBuffer((addr + by) >> 8);
//            spi2_WRBuffer(addr + by);
//        }   
        spi2_WRBuffer(arrayPtr[by]);

    }
    SMEM_CS_n = 1;
    return(arraySize);
}

    // Returns true if times out busy, which is a fault.
bool smem_Busy(void)
{
    byte status = 0;
    unsigned timeOut = 0;

    do
    {
        SMEM_CS_n = 0;
        spi2_WRBuffer(SMEM_RDSR);    // Read status reg
        status = spi2_WRBuffer(0);  // Test datum
        SMEM_CS_n = 1;
        if (timeOut++ == 0xFFFF) return(true); 
    } while (status & 0x01);

    return(false);
}

 byte spi2_WRBuffer(byte datum)
 {
     interruptsEnable(false);
     SPI2BUF = datum;
     while (!SPI2STATbits.SPIRBF) ;
     interruptsEnable(true);
     return (SPI2BUF);
 }

// ----- Utility --------

    // Destructive erasure of entire SEEPROM.
void smemEraseAll(void)
{
    unsigned page, d;

    for (d = 0; d < SMEM_ARRAY_SIZE; d++) smemBfr[d] = 0xFF;

    putStr("\tsmem destructive erase all...\r\n", true);
    for (page = 0; page < SMEM_NUM_PAGES; page++)
    {
         if (smem_WriteArray(page * SMEM_ARRAY_SIZE, smemBfr, SMEM_ARRAY_SIZE) != SMEM_ARRAY_SIZE)
         {
             putStr("\tsmemEraseAll failed.\r\n", true);
             return;
         }
         petTheDog();
    }

    sprintf(ioBfr, "\tErased %d pages of smem.\r\n", SMEM_NUM_PAGES);
    putStr(ioBfr, true);
}

        // Destructive write to entire SEEPROM.  TODO Test cross-page writes.
void smemWriteTest(void)
{
    unsigned page, d;
    char testStr[SMEM_ARRAY_SIZE + 1];

    // "Page 000 : 012345678901234567890123456789012345678901234567890123456789

    for (d = 0; d < 40; d++) testStr[d] = '0' + (d % 10);
    testStr[d] = 0;

    putStr("\tsmem destructive write test...\r\n", true);
    for (page = 0; page < SMEM_NUM_PAGES; page++)
    {
         sprintf(smemBfr, "Page %03d : ", page);
         strcat(smemBfr, testStr);
         if (smem_WriteArray(page * SMEM_ARRAY_SIZE, smemBfr, SMEM_ARRAY_SIZE) != SMEM_ARRAY_SIZE)
         {
             putStr("\tsmemWriteTest failed.\r\n", true);
             return;
         }
         else
         {
             putStr(smemBfr, true);
             putStr("\r\n", true);
         }
         petTheDog();
    }

    sprintf(ioBfr, "\tWrote %d pages to smem.", SMEM_NUM_PAGES);
    putStr(ioBfr, true);
}

void smemReadTest(void)
{
    unsigned page;
    for (page = 0; page < SMEM_NUM_PAGES; page++)
    {
         if (smem_ReadArray(page * SMEM_ARRAY_SIZE, smemBfr, SMEM_ARRAY_SIZE) != SMEM_ARRAY_SIZE)
         {
             putStr("\tsmemReadTest failed.\r\n", true);
             return;
         }
         else
         {
             putStr(smemBfr, true);
             putStr("\r\n", true);
         }
         petTheDog();
    }
}

    // Called nominally every 5 mins to keep a rough nonvol clock
int smemWriteTime(void)
{
    smemBfr[0] = time.year;
    smemBfr[1] = time.month;
    smemBfr[2] = time.dayMonth;
    smemBfr[3] = time.hour;
    smemBfr[4] = time.minute;

    return (smem_WriteArray(SMEM_ADDR_TIME, smemBfr, 5));
}

    // Called at reset.  Has non-recursive retry.
int smemReadTime(void)
{
    extern unsigned sysFault;
    bool success = true;

    if (smem_ReadArray(SMEM_ADDR_TIME, smemBfr, 5) < 5) success = false;

    if (smemBfr[0] > 0 && smemBfr[0] < 100) time.year = smemBfr[0];   // Years from (20)14 - (20)99
    else success = false;
    if (smemBfr[1] > 0 && smemBfr[1] < 13) time.month = smemBfr[1];
    else success = false;
    if (smemBfr[2] > 0 && smemBfr[2] < 32) time.dayMonth = smemBfr[2];
    else success = false;
    if (smemBfr[3] < 60) time.hour = smemBfr[3];
    else success = false;
    if (smemBfr[4] < 60) time.minute = smemBfr[4];
    else success = false;

    if (success == false)
    {
        if (smem_ReadArray(SMEM_ADDR_TIME, smemBfr, 5) == 5) return(-1);

        if (smemBfr[0] > 0 && smemBfr[0] < 100) time.year = smemBfr[0];
        else return(-2);
        if (smemBfr[1] > 0 && smemBfr[1] < 13) time.month = smemBfr[1];
        else return(-3);
        if (smemBfr[2] > 0 && smemBfr[2] < 32) time.dayMonth = smemBfr[2];
        else return(-4);
        if (smemBfr[3] < 60) time.hour = smemBfr[3];
        else return(-5);
        if (smemBfr[4] < 60) time.minute = smemBfr[4];
        else return(-6);
    }

    sysFault &= ~FLT_CLOCKNOTSET;       // Assume that we have an approx clock now
    return (5);
}
