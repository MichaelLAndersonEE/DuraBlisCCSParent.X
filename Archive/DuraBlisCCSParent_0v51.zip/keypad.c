/* File:   keypad.c
 * Use CTMU to measure 4 capacitive keys
 * Author: Michael L Anderson
 * Contact: MichaelLAndersonEE@gmail.com
 * Platform: PIC32MX350F256H on DuraBlis-CCS-Main_v4 board.
 * Created: 17 Sep14
 */

#include <xc.h>
#include "DuraBlisCCSParent.h"
#include "keypad.h"
#define NUM_CAPKEYS  4
const byte keypadADCchan[NUM_CAPKEYS] = { 20, 21, 22, 23 };

void keypadInit(void)
{
    CTMUCONbits.ON = 0;
    CTMUCONbits.CTMUSIDL = 0;   // CTMU runs in Idle
    CTMUCONbits.EDG2STAT = 0;   // Leave this 0 to avoid double trig
    CTMUCONbits.IRNG = 0b10;    // Current range 10 x base (550 nA nominal)  ***
        // Next 2 are not actual, but preferable to defaulting to 0b0000 Timer1 event as source
    CTMUCONbits.EDG1SEL = 0b0001;   // OC1 is Edge 1 source
    CTMUCONbits.EDG2SEL = 0b0001;   // OC1 is Edge 1 source
    CTMUCONbits.ON = 1;
}

    // Todo put in time marks for duration
void keypadTest(void)
{
    unsigned adcMeas;                       // Meas voltages, 1023 full scale
    double iirSlow[NUM_CAPKEYS] = { 420.0, 420.0, 420.0, 420.0 };
    double iirSlowCoeff = 0.0143;
    double iirFast[NUM_CAPKEYS] = { 420.0, 420.0, 420.0, 420.0 };
    double iirFastCoeff = 0.275;            // TODO do adaptive in begin
    byte keyState = 0;                      // Bit image, set-reset
    unsigned dropThreshold = 6;
    byte chan = 0;
    unsigned d;
    char charCh;      
        //byte counter = 0;     // Use set-reset instead

    putStr("\tKeypad test. Any serial input ends.\r\n");

    AD1CHSbits.CH0NA = 0;       // Sample A Ch 0 neg input is Vrefl
    while(1)
    {
        ctmuSample(chan);
        if (++chan > NUM_CAPKEYS) chan = 0;

       
        iirSlow += 0.01 * (adcMeas - iirSlow);
        iirFast += 0.27 * (adcMeas - iirFast);

        if ((iirSlow - iirFast) > threshold && counter == 0)
        {
//            sprintf(ioBfr, "%d\n\r", (int) Viir - adcMeas);
//            putStr(ioBfr);
            counter = 3;
            putChar('A');
        }

        if (counter > 0) counter--;

  //      sprintf(ioBfr, "%2.1f %2.1f\n\r", iirSlow, iirFast);
  //      putStr(ioBfr);

        for (d=0; d<500; d++)
        {
            charCh = getChar();
            if (charCh > 31)
            {
                 putChar(charCh);
                 return;
            }
            delay_us(1000);
        }
    }
}

ctmuSample(byte chan)
{
    AD1CON1bits.SAMP = 0;       // End sampling & start conver
            // AD1CHSbits.CH0NA = 0;       // Sample A Ch 0 neg input is Vrefl
            //  iChan = keypadADCchan[iButton];
        AD1CHSbits.CH0SA = 20;  // iChan;
            //  ADC_Sum = 0;
        AD1CSSL = 0;                // Write to scan buff 0
            //AD1CON1bits.SAMP = 1; // Manual sampling start
        CTMUCONbits.IDISSEN = 1; // Ground charge pump
        delay_us(10);           // Wait for grounding
        CTMUCONbits.IDISSEN = 0; // End drain of circuit

        CTMUCONbits.EDG1STAT = 1; // Begin charging the circuit
        AD1CON1bits.SAMP = 1;       // Start sampling
        delay_us(220);   // ***     // Charge time
        AD1CON1bits.SAMP = 0; // Begin analog-to-digital conversion
        CTMUCONbits.EDG1STAT = 0; // Stop charging circuit
        while (!AD1CON1bits.DONE); // Wait for ADC conversion

        AD1CON1bits.DONE = 0; // ADC conversion done, clear flag
        adcMeas = ADC1BUF0; // Get the value from the ADC
}

