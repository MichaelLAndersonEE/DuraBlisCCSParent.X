/* File:   keypad.h
 * Author: Michael L Anderson
 * Contact: MichaelLAndersonEE@gmail.com
 * Platform: PIC32MX350F256H on DuraBlis-CCS-Main_v4 board
 * Created: 17 Sep14
 */

#ifndef KEYPAD_H
#define	KEYPAD_H

#ifdef	__cplusplus
extern "C" {
#endif

void keypadInit(void);
void keypadTest(void);

#ifdef	__cplusplus
}
#endif

#endif	/* KEYPAD_H */

