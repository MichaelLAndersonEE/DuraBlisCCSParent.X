/* File:        BW-CCS.c  Main source file
 * Author:      Michael L Anderson
 * Contact:     MichaelLAndersonEE@gmail.com
 * Platform:    PIC32MX350F256H on BW-CCS-Main_v2 board
 * Created:     16 May 14
 * Version 0.2 - 11 Jun 14
 */

#include <stdlib.h>
#include <plib.h>
#include "configs.h"
#include "BW-CCS.h"
#include "serial.h"
#include "child.h"      // Child emulation for T&D

void hardwareInit(void);
void menuDisplay(void);
void systemInit(void);
void reportInfo(void);

unsigned sysStat;
//byte  temperSenStat;        // The parent's internal sensors
//byte  rhumidSenStat;

const char pnetCommProtocolVer = '1';

int main(void)
{
    char charCh;
 
    hardwareInit();
    systemInit();
    putStr("\n\r BW CCS Monitor, v0.2, MLA\n\r");
    if (sysStat & ST_CHILDMODE) putStr("\t*Child mode*\n\r");
    else putStr("\t*Parent mode*\n\r");

    menuDisplay();
    putStr("\n\r > ");

    while (1)
    {
        charCh = getChar();
        if (!charCh) continue;
        putChar(charCh);  
        if (charCh == '/')      // Super commands for Monitor
        {
           // putChar(charCh);
            charCh = 0;
            while (!charCh)
            {
                charCh = getChar();
                if (!charCh) continue;
                putChar(charCh);
                switch(charCh)
                {
                case 'C':
                    sysStat ^= ST_CHILDMODE;
                    if (sysStat & ST_CHILDMODE) putStr("\t*Child mode*\n\r");
                    else putStr("\t*Parent mode*\n\r");
                    putStr("\n\r > ");
                    break;

                case 'r':
                    reportInfo();
                    break;

                case '?':
                    menuDisplay();
                    putStr("\n\r > ");
                    break;
                    }
                }
            }

            // Child emulation
        if (sysStat & ST_CHILDMODE) childModeStMach(charCh);

    };      // EO while (1)
}


    // --------------------------------
void reportInfo(void)
{
     putPrompt();
     putStr("  * System info *\n\r");
     putStr(" PNet protocol ver: ");
     putChar(pnetCommProtocolVer);
     putStr("\n\r System status: ");
     putByte2Hex(sysStat);
     putChar('h');
     putStr("\n\r Mode: ");
     putStr(sysStat & ST_CHILDMODE ? "Child" : "Parent");
     if (sysStat & ST_CHILDMODE) childReportInfo();
     putPrompt();
}
   
void delay_us(unsigned T)   // TODO calibrate
{
    unsigned t;
    for (t=0; t<T; t++ ) ;
}

void hardwareInit(void)
{
       // Configure the device for maximum performance, but do not change the PBDIV clock divisor.
        // Given the options, this function will change the program Flash wait states,
        // RAM wait state and enable prefetch cache, but will not change the PBDIV.
        // The PBDIV value is already set via the pragma FPBDIV option above.
    SYSTEMConfig(SYS_FREQ, SYS_CFG_WAIT_STATES | SYS_CFG_PCACHE);

    PORTSetPinsAnalogIn(IOPORT_B, BIT_15 | BIT_14 | BIT_9 | BIT_8 | BIT_7 | BIT_6 | BIT_5 | BIT_4);
        // Could also use mPORTDSetPinsDigitalOut(BIT_6 | BIT_7);
    PORTSetPinsDigitalOut(IOPORT_B, BIT_3 | BIT_2);
    LATB = PORTB = 0x00000008;
    PORTSetPinsDigitalIn(IOPORT_B, BIT_13 | BIT_12 | BIT_11 | BIT_10 | BIT_1 | BIT_0);

    PORTSetPinsDigitalOut(IOPORT_C, BIT_14);
    LATC = PORTC = 0x00000000;
    PORTSetPinsDigitalIn(IOPORT_C, BIT_13);

    PORTSetPinsAnalogIn(IOPORT_D, BIT_1 | BIT_0);
    PORTSetPinsDigitalOut(IOPORT_D, BIT_11 | BIT_10 | BIT_9 | BIT_8 | BIT_7 | BIT_6 | BIT_5 | BIT_4 |
        BIT_3 | BIT_0);
    LATD = PORTD = 0x00000009;
    PORTSetPinsDigitalIn(IOPORT_D, BIT_2 | BIT_1);

    PORTSetPinsAnalogIn(IOPORT_E, BIT_6 | BIT_5 | BIT_4 | BIT_2);
    PORTSetPinsDigitalOut(IOPORT_E, BIT_1 | BIT_0);
    LATE = PORTE = 0x00000000;

    PORTSetPinsDigitalOut(IOPORT_F, BIT_6 | BIT_5 | BIT_4 | BIT_3);
    LATF = PORTF = 0x00000020;
    PORTSetPinsDigitalIn(IOPORT_F, BIT_2);

    PORTSetPinsDigitalOut(IOPORT_G, BIT_9 | BIT_8 | BIT_6 | BIT_3 | BIT_2);
    LATF = PORTF = 0x00000204;
    PORTSetPinsDigitalIn(IOPORT_G, BIT_7);

        // This is the waggle to set reprogrammable peripheral
        // Assume ints & DMA disa
    SYSKEY = 0xAA996655;
    SYSKEY = 0x556699AA;
    U1RXR = 0b1111;     // Selects RPF2 as RxD input
    RPF3R = 0b0011;     // Selects U1TX as TxD output
    SDI2R = 0b0001;     // Selects pin 5 as SDI (PICO)
    RPG8R = 0b0110;     // Selects pin 6 as SDO (POCI)
    SYSKEY = 0x33333333;    // Junk relocks it

        // Serial port on UART1
        // Note, Mode & Sta have atomic bit clr, set, & inv registers
    U1MODEbits.ON = 1;      // Ena UART1, per UEN, with UTXEN
    U1MODEbits.SIDL = 0;    // Continue oper in idle mode
    U1MODEbits.IREN = 0;    // Disa IrDA
    U1MODEbits.RTSMD = 1;   // U1RTS_n pin in simplex mode
    U1MODEbits.UEN = 0b00;  // U1CTS_n & U1RTS_n unused
    U1MODEbits.WAKE = 0;    // Disa wakeup
    U1MODEbits.LPBACK = 0;  // Disa loopback
    U1MODEbits.ABAUD = 0;   // Disa autobaud
    U1MODEbits.RXINV = 0;   // U1Rx idle is 1
    U1MODEbits.BRGH = 0;    // Std speed 16x, 1: high speed is 4x baud clk
    U1MODEbits.PDSEL = 0b00;    // 8 bit data, no parity
    U1MODEbits.STSEL = 0;   // 1 stop bit

    U1STAbits.ADM_EN = 0;   // Disa automatic address mode detect
    U1STAbits.UTXISEL = 0b01;   // Interrupt gen when all chars transmitted
    U1STAbits.UTXINV = 0;   // U1Tx idle is 1
    U1STAbits.URXEN = 1;    // Ena U1Rx
    U1STAbits.UTXBRK = 0;   // Disa Break (Start bit, then 12 0's, Stop)
    U1STAbits.UTXEN = 1;    // Ena U1Tx
    U1STAbits.URXISEL = 0b01;   // Interrupt flag asserted while buffer is 1/2 or more full
    U1STAbits.ADDEN = 0;    // Disa address mode

    U1BRG = 80;             // 19200 baud = PBCLK / (16 x (BRG + 1)), PBCLK = 25 MHz @ div / 1, Jitter 0.47%
    COMM_RX_ENA_n = 0;
    COMM_SHDN_n = 1;
}

void menuDisplay(void)
{
    putStr("\n\r Use / for these commands\n\r");
    putStr(" C - toggle parent / child mode\n\r");
    putStr(" D - init NHD C12864 display * \n\r");
    putStr(" i - read channel currents * \n\r");
    putStr(" I - calibrate channel i meas * \n\r");
    putStr(" k - keypad test * \n\r");
    putStr(" r - report basic info\n\r");
    putStr(" R - smem Read *\n\r");
    putStr(" t - read Temperature & RH *\n\r");
    putStr(" T - set rtcc Time *\n\r");
    putStr(" W - smem Write *\n\r");
    putStr(" 1 - toggle relay 1 *\n\r");
    putStr(" 2 - toggle relay 2 *\n\r");
    putStr(" ? - show this menu\n\r");   
}

void systemInit(void)
{
    sysStat = ST_OKAY;
 //  childInits();

        // TODO let these be initialized by analog function modules
//    temperSenStat = SEN_OKAY;
//    rhumidSenStat = SEN_OKAY;
}