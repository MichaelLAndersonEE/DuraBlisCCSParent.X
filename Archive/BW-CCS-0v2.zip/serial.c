/* File:   serial.c  UART consoleIO
 * Author: Michael L Anderson
 * Contact: MichaelLAndersonEE@gmail.com
 * Platform: PIC32MX350F256H on BW-CCS-Main_v2 board.  Specifically the Exar SP3222 RS232 driver
 * Created: 16 May 14
 */


#include <plib.h>
#include "BW-CCS.h"
#include "serial.h"

void putUns2Hex(unsigned uns)
{
    char outBfr[5];
    outBfr[4] = 0;
    outBfr[3] = uns;
    uns >>= 4;
    outBfr[2] = uns;
    uns >>= 4;
    outBfr[1] = uns;
    uns >>= 4;
    outBfr[0] = uns;
    putStr(outBfr);
}

void putByte2Hex(byte me)
{
    putChar((me >> 4) + '0');
    putChar((me & 0x0F) +'0');
}

void putPrompt(void)
{
    putStr("\r\n > ");
}

    // This is a noninterrupt UART read. It is transparent;
    // returning 0 if there is nothing in.
char getChar(void)
{
    char ch;

   // COMM_RX_ENA_n = COMM_SHDN_n = 0;
    if (U1STAbits.URXDA)
    {
        ch =  U1RXREG;      // Clears URXDA
        return(ch);
    }
    else return(0);
}

    // Print string up to 40 chars
void putStr(const char *str)
{
    byte me;

   // COMM_RX_ENA_n = COMM_SHDN_n = 1;
    for (me=0; me<41; me++)
    {
        if (str[me] == 0) return;
        //putChar(str[me]);
        U1TXREG = str[me];
        while (U1STAbits.UTXBF) ;
    }
  //delay_us(2000);
  //COMM_RX_ENA_n = COMM_SHDN_n = 0;
}

void putChar(char c)
{
    //COMM_RX_ENA_n = COMM_SHDN_n = 1;
    U1TXREG = c;
    while (U1STAbits.UTXBF) ;
   // delay_us(2000);
    //COMM_RX_ENA_n = COMM_SHDN_n = 0;
}

char *itoa(char *buf, int val, int base)
{
    char *cp = buf;

    if(val < 0)
    {
	*buf++ = '-';
	val = -val;
    }
    utoa(buf, val, base);
    return cp;
}

char *utoa(char *buf, unsigned val, int base)
{
    unsigned	v;
    char	c;

    v = val;
    do
    {
	v /= base;
	buf++;
    } while(v != 0);
    *buf-- = 0;
    do
    {
	c = val % base;
	val /= base;
	if(c >= 10)
	c += 'A'-'0'-10;
	c += '0';
	*buf-- = c;
    } while(val != 0);
    return buf;
}
