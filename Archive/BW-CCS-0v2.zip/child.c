/* File:   child.c  Child emulation for T&D.  May be useful to maintain.
 * Author: Michael L Anderson
 * Contact: MichaelLAndersonEE@gmail.com
 * Platform: PIC32MX350F256H on BW-CCS-Main_v2 board.  Specifically the Exar SP3222 RS232 driver
 * Created: 25 Jun 14
 */

#include <plib.h>
#include "BW-CCS.h"
#include "child.h"

const byte childNodeSetting = 3;        // Fake. For child emulation.
const byte childEqWord = 0b00000001;    // Fake. For child emulation.
const float childTemperature = 95.6;    // Fake.
const float childRHumidity = 45.6;      // Fake.
const unsigned childStatus = CHILD_TSEN_OKAY + CHILD_TSEN_OKAY;   // Fake.
    // TODO for child, check impossible combos

// void childInits(void) {}

    // TODO assure version compat
    // TODO timeout
    // TODO the putPrompt()'s here are solely for emulation
    // Refer to PNet Communication Protocol doc
void childModeStMach(char charCh)   // Child emulation
{
    static unsigned int stMach = 0;
    static byte childNodeNumber;
    static byte childRelayNumber;

    switch(stMach)
    {
        case 0:
            if (charCh == 'A') stMach = 10;
            else if (charCh == 'S') stMach = 20;
            else if (charCh == 'T') stMach = 30;
            else if (charCh == 'H') stMach = 40;
            else if (charCh == 'V') stMach = 50;
            else if (charCh == 'P') stMach = 60;
            else if (charCh == 'R') stMach = 70;

        case 10:        // Reading A messages
             if (charCh == 'T') stMach = 11;
             break;

        case 11:
            if (charCh > '0' && charCh < '9')
            {
                stMach = 0;     // Terminus
                childNodeNumber = charCh - '0';
                respondAttention(childNodeNumber);
            }
            break;

        case 20:        // Reading S messages
            if (charCh == '?') stMach = 21;
            break;

        case 21:
            if (charCh > '0' && charCh < '9')
            {
                stMach = 0;     // Terminus
                childNodeNumber = charCh - '0';
                respondStatus(childNodeNumber);
            }
            break;

        case 30:        // Reading T messages
            if (charCh == '?') stMach = 31;
            break;

        case 31:
            if (charCh > '0' && charCh < '9')
            {
                stMach = 0;     // Terminus
                childNodeNumber = charCh - '0';
                respondTemperature(childNodeNumber);
            }
            break;

        case 40:        // Reading H messages
            if (charCh == '?') stMach = 41;
            break;

        case 41:
            if (charCh > '0' && charCh < '9')
            {
                stMach = 0;     // Terminus
                childNodeNumber = charCh - '0';
                respondRHumidity(childNodeNumber);
            }
            break;

        case 50:        // Reading V service requests / queries
            if (charCh > '0' && charCh < '9')
            {
                stMach = 51;
                childNodeNumber = charCh - '0';
            }
            else if (charCh == '?')
            {
                stMach = 55;
            }
            break;

        case 51:
            if (charCh == '1' || charCh == '2')
            {
                stMach = 52;
                childRelayNumber = charCh;
            }
            break;

        case 52:
            stMach = 0;     // Terminus
            if (charCh == '+') respondServiceRequest(childNodeNumber, childRelayNumber, '+');
            else if (charCh == '-') respondServiceRequest(childNodeNumber, childRelayNumber, '-');
            break;

        case 55:
            if (charCh > '0' && charCh < '9')
            {
                stMach = 0;     // Terminus
                childNodeNumber = charCh - '0';
                respondServiceQuery(childNodeNumber);
            }

        default:
            stMach = 0;     // Any syntax error resets
    }
}

     // ---------------------------
void childReportInfo(void)
{
    putStr("\n\r Child node setting: ");
    putChar('0' + childNodeSetting);
    putStr("\n\r Child Eq word: ");
    putByte2Hex(childEqWord);
    putChar('h');
    putStr("\n\r Child status: ");
    putUns2Hex(childStatus);
    putChar('h');
}

    // ---------------------------
void respondAttention(byte ch)
{
    if (ch == childNodeSetting)
    {
        putPrompt();
        putStr("ak");
        putChar('0' + childNodeSetting);
        putByte2Hex(childEqWord);
        putPrompt();
    }
    else return;
}

    // ---------------------------
void respondRHumidity(byte ch)
{
    char outBfr[11];

    if (ch == childNodeSetting)
    {
        putPrompt();
        putStr("hk");
        putChar('0' + childNodeSetting);
        if (childEqWord & CH_RESOURCE_TH_OUTSIDE)
        {
            if (childStatus & CHILD_HSEN_OKAY)
            {
                sprintf(outBfr, "%04.1f", childRHumidity);
                putStr(outBfr);
            }
            else
            {
                putStr("sf");
                //putChar('0' + childSenStatus);
            }
        }
        else
        {
            putStr("ir");
        }
        putPrompt();
    }
    else return;
}

    // --------------------------
void respondServiceQuery(byte ch)
{
    if (ch == childNodeSetting)
    {
        putPrompt();
        putChar('v');
        putChar('0' + childNodeSetting);
        putChar('1');
        if (childStatus & CHILD_K1_ON) putChar('+');
        else putChar('-');
        putChar('2');
        if (childStatus & CHILD_K2_ON) putChar('+');
        else putChar('-');
    }
}

    // ------------------------
void respondServiceRequest(byte ch, char relayNo, char onOff)
{
    if (ch == childNodeSetting)
    {
        putPrompt();
        putStr("vk");
        putChar('0' + childNodeSetting);
        if (relayNo == '1')
        {
            if (childEqWord & (CH_RESOURCE_EXTFANOUT_K1 | CH_RESOURCE_EXTFANIN_K1  | CH_RESOURCE_INTFAN_K1))
            {
                // TODO...
                putChar('1');
                putChar(onOff);
            }
            else
            {
                putStr("ir");
            }
        }
        else if (relayNo == '2')
        {
            if (childEqWord & (CH_RESOURCE_EXTFANOUT_K2 | CH_RESOURCE_EXTFANIN_K2  | CH_RESOURCE_INTFAN_K2))
            {
                // TODO...
                putChar('2');
                putChar(onOff);
            }
            else
            {
                putStr("ir");
            }
        }
        putPrompt();
    }
    else return;
}

    // ---------------------------
void respondStatus(byte ch)
{
    if (ch == childNodeSetting)
    {
        putPrompt();
        putStr("sk");
        putChar('0' + childNodeSetting);
        putChar('t');
        if (!(childEqWord & CH_RESOURCE_TH_OUTSIDE)) putChar('0');
        else if (childStatus & CHILD_TSEN_OKAY) putChar('+');
        else putChar('-');

        putChar('h');
        if (!(childEqWord & CH_RESOURCE_TH_OUTSIDE)) putChar('0');
        else if (childStatus & CHILD_HSEN_OKAY) putChar('+');
        else putChar('-');

        putChar('1');
        if (childStatus & CHILD_K1_ON) putChar('+');
        else putChar('-');

        putChar('2');
        if (childStatus & CHILD_K2_ON) putChar('+');
        else putChar('-');
        putPrompt();
    }
    else return;
}

    // ---------------------------
void respondTemperature(byte ch)
{
    char outBfr[11];

    if (ch == childNodeSetting)
    {
        putPrompt();
        putStr("tk");
        putChar('0' + childNodeSetting);
        if (childEqWord & CH_RESOURCE_TH_OUTSIDE)
        {
            if (childStatus & CHILD_TSEN_OKAY)
            {
                sprintf(outBfr, "%04.1f", childTemperature);
                putStr(outBfr);
            }
            else
            {
                putStr("sf");
                //putChar('0' + childSenStatus);
            }
        }
        else
        {
            putStr("ir");
        }
        putPrompt();
    }
    else return;
}



 


