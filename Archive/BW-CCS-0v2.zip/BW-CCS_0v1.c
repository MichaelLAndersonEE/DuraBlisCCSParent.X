/* File:   BW-CCS2.c  Main source file
 * Author: Michael L Anderson
 * Contact: MichaelLAndersonEE@gmail.com
 * Platform: PIC32MX350F256H on BW-CCS-Main_v2 board
 * Created: 16 May 14
 */

//#include <stdio.h>
#include <stdlib.h>
#include <plib.h>
#include "BW-CCS.h"
#include "Serial.h"

    // Configuration Bits
#pragma config FSRSSEL  = PRIORITY_0    // Shadow register set priority select
#pragma config PMDL1WAY = OFF           // Allow multiple peripheral reconfigs
#pragma config IOL1WAY = OFF            // Allow multiple peripheral pin reconfigs
#pragma config FPLLIDIV = DIV_1         // PLL input divider = 1x
#pragma config FPLLMUL = MUL_20         // PLL mult = 20x
#pragma config FPLLODIV = DIV_1         // PLL out clk div by 1
#pragma config FNOSC = PRI              // Osc select XT, HS, EC
#pragma config FSOSCEN = OFF            // Secondary osc disa TODO
#pragma config IESO = OFF               // Int/ext switchover disa
#pragma config POSCMOD = HS             // Pri osc config
#pragma config OSCIOFNC = OFF           // CLKO output disa
#pragma config FPBDIV = DIV_1           // Peri clk divisor is /1
#pragma config FCKSM = CSDCMD           // Clk swi disa, FSCM disa
#pragma config WDTPS = PS4              // WDT postscaler 1:4
#pragma config WINDIS = OFF             // WDT in non-window mode
#pragma config FWDTEN = OFF             // WDT disa
#pragma config FWDTWINSZ = WINSZ_50     // WDT window 50%
#pragma config DEBUG = OFF              // Background debugger disa
#pragma config JTAGEN = OFF             // JTAG disa
#pragma config ICESEL = ICS_PGx1        // ICE/ICD on PGEx1
#pragma config PWP = OFF                // Program flash write protect range, disa
#pragma config BWP = OFF                // Boot flash write protect bit
#pragma config CP = OFF                 // Code protect disa

    //  The following is used by the main application
#define SYS_FREQ		(25000000)

    // IOPORT bit masks can be found in ports.h
//#define CONFIG          (CND_ON)
//#define PINS            (CND7_ENABLE)
//#define PULLUPS         (CND6_PULLUP_ENABLE | CND7_PULLUP_ENABLE)
//#define INTERRUPT       (CHANGE_INT_ON | CHANGE_INT_PRI_2)

unsigned int dummy;

int main(void)
{
    unsigned ctr1, ctr2, ctr3;
    char charCh;
    char strIn[11];
    byte strCtr = 0;

        // Configure the device for maximum performance, but do not change the PBDIV clock divisor.
        // Given the options, this function will change the program Flash wait states,
        // RAM wait state and enable prefetch cache, but will not change the PBDIV.
        // The PBDIV value is already set via the pragma FPBDIV option above.
    SYSTEMConfig(SYS_FREQ, SYS_CFG_WAIT_STATES | SYS_CFG_PCACHE);

    PORTSetPinsAnalogIn(IOPORT_B, BIT_15 | BIT_14 | BIT_9 | BIT_8 | BIT_7 | BIT_6 | BIT_5 | BIT_4);
        // Could also use mPORTDSetPinsDigitalOut(BIT_6 | BIT_7);
    PORTSetPinsDigitalOut(IOPORT_B, BIT_3 | BIT_2);
    LATB = PORTB = 0x00000008;
    PORTSetPinsDigitalIn(IOPORT_B, BIT_13 | BIT_12 | BIT_11 | BIT_10 | BIT_1 | BIT_0);

    PORTSetPinsDigitalOut(IOPORT_C, BIT_14);
    LATC = PORTC = 0x00000000;
    PORTSetPinsDigitalIn(IOPORT_C, BIT_13);

    PORTSetPinsAnalogIn(IOPORT_D, BIT_1 | BIT_0);
    PORTSetPinsDigitalOut(IOPORT_D, BIT_11 | BIT_10 | BIT_9 | BIT_8 | BIT_7 | BIT_6 | BIT_5 | BIT_4 |
        BIT_3 | BIT_0);
    LATD = PORTD = 0x00000009;
    PORTSetPinsDigitalIn(IOPORT_D, BIT_2 | BIT_1);

    PORTSetPinsAnalogIn(IOPORT_E, BIT_6 | BIT_5 | BIT_4 | BIT_2);
    PORTSetPinsDigitalOut(IOPORT_E, BIT_1 | BIT_0);
    LATE = PORTE = 0x00000000;

    PORTSetPinsDigitalOut(IOPORT_F, BIT_6 | BIT_5 | BIT_4 | BIT_3);
    LATF = PORTF = 0x00000020;
    PORTSetPinsDigitalIn(IOPORT_F, BIT_2);

    PORTSetPinsDigitalOut(IOPORT_G, BIT_9 | BIT_8 | BIT_6 | BIT_3 | BIT_2);
    LATF = PORTF = 0x00000204;
    PORTSetPinsDigitalIn(IOPORT_G, BIT_7);

        // This is the waggle to set reprogrammable peripheral
        // Assume ints & DMA disa
    SYSKEY = 0xAA996655;
    SYSKEY = 0x556699AA;
    U1RXR = 0b1111;     // Selects RPF2 as RxD input
    RPF3R = 0b0011;     // Selects U1TX as TxD output
    SDI2R = 0b0001;     // Selects pin 5 as SDI (PICO)
    RPG8R = 0b0110;     // Selects pin 6 as SDO (POCI)
    SYSKEY = 0x33333333;    // Junk relocks it

        // Serial port on UART1
        // Note, Mode & Sta have atomic bit clr, set, & inv registers
    U1MODEbits.ON = 1;      // Ena UART1, per UEN, with UTXEN
    U1MODEbits.SIDL = 0;    // Continue oper in idle mode
    U1MODEbits.IREN = 0;    // Disa IrDA
    U1MODEbits.RTSMD = 1;   // U1RTS_n pin in simplex mode
    U1MODEbits.UEN = 0b00;  // U1CTS_n & U1RTS_n unused
    U1MODEbits.WAKE = 0;    // Disa wakeup
    U1MODEbits.LPBACK = 0;  // Disa loopback
    U1MODEbits.ABAUD = 0;   // Disa autobaud
    U1MODEbits.RXINV = 0;   // U1Rx idle is 1 
    U1MODEbits.BRGH = 0;    // Std speed 16x, 1: high speed is 4x baud clk
    U1MODEbits.PDSEL = 0b00;    // 8 bit data, no parity
    U1MODEbits.STSEL = 0;   // 1 stop bit

    U1STAbits.ADM_EN = 0;   // Disa automatic address mode detect
    U1STAbits.UTXISEL = 0b01;   // Interrupt gen when all chars transmitted
    U1STAbits.UTXINV = 0;   // U1Tx idle is 1
    U1STAbits.URXEN = 1;    // Ena U1Rx
    U1STAbits.UTXBRK = 0;   // Disa Break (Start bit, then 12 0's, Stop)
    U1STAbits.UTXEN = 1;    // Ena U1Tx
    U1STAbits.URXISEL = 0b01;   // Interrupt flag asserted while buffer is 1/2 or more full
    U1STAbits.ADDEN = 0;    // Disa address mode

     U1BRG = 80;             // 19200 baud = PBCLK / (16 x (BRG + 1)), PBCLK = 25 MHz @ div / 1
                            // Jitter 0.47%
    //U1BRG = 162;            // 9600 baud = PBCLK / (16 x (BRG + 1)), PBCLK = 25 MHz @ div / 1
                            // Jitter -0.15%
    COMM_RX_ENA_n = 0;
    COMM_SHDN_n = 1;
    // configure the Change Notice Feature
    // Note: It is recommended to disable vectored interrupts prior to
    // configuring the change notice module, (if they are enabled).
    // The user must read one or more IOPORTs to clear any IO pin
    // change notice mismatch condition, then clear the change notice
    // interrupt flag before re-enabling the vector interrupts.

    // Enable change notice, enable discrete pins and weak pullups
   // mCNDOpen(CONFIG, PINS, PULLUPS);

    // Read the port to clear any mismatch on change notice pins
    dummy = mPORTDRead();

    // Clear change notice interrupt flag
  //  ConfigIntCND(INTERRUPT);

    // Ok now to enable multi-vector interrupts
  //  INTEnableSystemMultiVectoredInt();

    // loop here polling for SW1, SW2 is handled by Change Notice Interrupt

  
//
    delay_us(1000);
    putStr("\n\rBW CCS Monitor, v0.1\n\r");
    putStr("MichaelLAndersonEE@gmail.com\n\r");
    putStr(" *Parent mode*\n\r");
    
    delay_us(0xFFFF);
    while (1)
    {
        // Parent
//        if (ctr1++ > 12000)
//        {
//            LCD_DC = 0;
////            //COMM_SHDN_n = 1;    // DEB
//            if (ctr2++ > 15000)
//            {
////                //printf("AT6TEM\r\n");   //", ctr3++);
////               putStr("AT6TEM");
//               //putChar(ctr3+32);
//             //   putChar('*');
////                if (ctr3++ > 32) ctr3 = 0;
////               putStr("\r\n");
//                ctr2 = 0;
//            }
////             //COMM_SHDN_n = 0; // DEB
////            ctr1 = 0;
////            LCD_DC = 1;
//        }

// Child
        charCh = getChar();
        if (charCh > 0)
        {
            putChar(charCh);
        }
//        {
//            if (charCh == '?') putChar('A');
//            else
//            {
//                strIn[strCtr] = charCh;
//                if (strCtr++ > 10) strCtr = 0;      // TODO use string.h fcns  TODO reset on first mismatch
//                if (strIn[0] == 'A' && strIn[1] == 'T' && strIn[2] == '6' && strIn[3] == 'T' &&
//                    strIn[4] == 'E' && strIn[0] == 'M')
//                {
//                    strCtr = 0;
//                    putStr("76.5 oF\n\r");
//                }
//            }
//        }
        //U1TXREG = 'A';
   
        
       
       
//        if (PORTDbits.RD6 == 0) // 0 = switch is pressed
//        {
//            PORTSetBits(IOPORT_D, BIT_0); // RED LED = on (same as LATDSET = 0x0001)
//            if (last_sw_state == 1) {
//                last_sw_state = 0;
//            }
//        } else // 1 = switch is not pressed
//        {
//            PORTClearBits(IOPORT_D, BIT_0); // RED LED = off (same as LATDCLR = 0x0001)
//            if (last_sw_state == 0) {
//                last_sw_state = 1;
//            }
//        }
    };

}

/******************************************************************************
 *	Change Notice Interrupt Service Routine
 *
 *   Note: Switch debouncing is not performed.
 *   Code comes here if SW2 (CN16) PORTD.RD7 is pressed or released.
 *   The user must read the IOPORT to clear the IO pin change notice mismatch
 *   condition first, then clear the change notice interrupt flag.
 *   Hint - To debug this ISR, use a breakpoint within the routine.
 ******************************************************************************/
void __ISR(_CHANGE_NOTICE_VECTOR, ipl2) ChangeNotice_Handler(void) {
    // Step #1 - always clear the mismatch condition first
    dummy = PORTReadBits(IOPORT_D, BIT_7);

    // Step #2 - then clear the interrupt flag
    mCNDClearIntFlag();

    // Step #3 - process the switches
    if (dummy == BIT_7) {
        PORTClearBits(IOPORT_D, BIT_1); // turn off LED2
    } else {
        PORTSetBits(IOPORT_D, BIT_1); // turn on LED2
    }

    // add additional processing here...

}

void delay_us(unsigned T)
{
    unsigned t;
    for (t=0; t<T; t++ ) ;
}