/* File:   time.h  RTCC and high level time functions
 * Author: Michael L Anderson
 * Contact: MichaelLAndersonEE@gmail.com
 * Platform: PIC32MX350F256H on DuraBlis-CCS-Main_v4 board.
 * Created: 18 Sep14
 */

#ifndef TIME_H
#define	TIME_H

#ifdef	__cplusplus
extern "C" {
#endif

    // Time read modes
#define TIME_UPDATE             0x01
//#define TIME_NEW_MINUTE         0x02
//#define TIME_NEW_SECOND         0x03
#define TIME_LOQUACIOUS         0x04
#define TIMEOUT_HUMAN           0xAAAA   // Related factor
#define TIMEOUT_PNET            0x2000

struct t_struct
{
    byte year;      // 00 - 99    Processes are set by readTime, clrd by user fcn
    byte month;     // 1 - 12
    byte dayMonth;  // 1 - 31
    byte weekday;   // 0 (Sun) - 6  Not presently used.  But in RTCC.  Keep for now.
    byte hour;      // 0 - 23
    byte minute;    // 0 - 59   Only first six saved to SEEPROM

    byte second;    // 0 - 59
    unsigned msec;      // 0 - 1024
    bool process1Flag;  // Network polling. Clr by exec loop.   TODO assure processes survive power cycle
    bool process2Flag;  // LED & buzzer timer.  Fixed at 1 Hz
    bool process3Flag;  // 32 ms used for keypad and hence windows
    bool process4Flag;  // 5 min datalog
};

const char monStr[12][4];

byte daysInMonth(byte mo, byte yr);
void delay_us(unsigned T);
//void fastTimer(void);
void timeRead(byte modeRead);
void timeWrite(void);
bool timeInBounds(void);

#ifdef	__cplusplus
}
#endif

#endif	/* TIME_H */

