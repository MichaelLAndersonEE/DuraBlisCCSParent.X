/* File:   windows.c user IO objects
 * Author: Michael L Anderson
 * Contact: MichaelLAndersonEE@gmail.com
 * Platform: PIC32MX350F256H on DuraBlis-CCS-Main_v4 board.
 * LCD:  NHD NHD-C12864WC-FSW-FBW-3V3, 128 x 64 pixels
 * Created: 18 Sep14
 */

#include <xc.h>
#include <string.h>
#include "DuraBlisCCSParent.h"
#include "lcd.h"
#include "time.h"
#include "keypad.h"
#include "resources.h"
#include "adc.h"            // For Sys Info, pg 3
#include "smem.h"           // For last save defaults
#include "wifi.h"


    // Window states  // TODO move to .h
    // TODO needed:  calibration consts, sysinfo
#define WIN_MAIN                 0
#define WIN_FAULT                1
#define WIN_SETUP1               2
#define WIN_SETUP2               3
#define WIN_SETUP3               4
#define WIN_COMFORT_BASE         5
#define WIN_CZ_SET_TEMP          6
#define WIN_CZ_SET_RH            7
#define WIN_SET_TIME             8
#define WIN_RESOURCES_BASE       9
#define WIN_RES_SET_HVAC        10
#define WIN_RES_MODULES         11
#define WIN_RES_SET_MODULE      12
#define WIN_MEAS_UNITS          13
#define WIN_SYSINFO             14
#define WIN_SET_WIFI            15
#define WIN_SET_CALIBRATIONS    16
#define WIN_NETWORK_INFO        17
#define WIN_DEFAULTS_BASE       18
#define WIN_EXECUTE_DEFAULTS    19

#define TIMEOUT_T           2812       // 45 sec typ

static void windowMain(char keyIn);
static void windowFault(char keyIn);
static void windowSetParent(char keyIn);
static void windowSetTime(char keyIn);
static void windowComfortZone(char keyIn);
static void windowCZTemper(char keyIn);
static void windowCZRHumid(char keyIn);
static void windowReviewModules(char keyIn);
static void windowModifyModules(char keyIn);
static void windowMeasUnits(char keyIn);
static void windowSysInfo(char keyIn);
static void windowDefaults(char keyIn);
static void windowSetWiFi(char keyIn);
static void windowCalibrate(char keyIn);

static unsigned windowTimeout;
static byte windowState;    // State machine index
static byte field;      // Index into fields in a given state
static byte childFocus = 1;
struct t_struct timeBuffer;
char bfr2[11];

extern struct operatingParms_struct oP;
extern struct t_struct time;
extern byte mainScreen[];
//extern unsigned sysStat;
extern unsigned sysFault;
//extern double setPointTempF, setPointRelHum;
extern struct ch_struct
{
    unsigned eqWord;
    unsigned status;
} child[NUM_CHILDREN];

    // State machine manager
void windowManager(char keyIn)
{
    static byte windowStateOld = 0xFF;       // State machine index buffer

    if (windowState != windowStateOld)  // This erases previous content
    {
        lcdScreen(mainScreen);
        windowStateOld = windowState;
        windowTimeout = TIMEOUT_T;
//        sprintf(ioBfr, "\tSt %d\r\n", windowStateOld);    // DEB
//        putStr(ioBfr);      // DEB
    }

    if (windowTimeout > 0) windowTimeout--;
    else windowState = WIN_MAIN;

    switch(windowState)
    {
        case WIN_MAIN:
            if (sysFault) { windowState = WIN_FAULT; break; }
            windowMain(keyIn);
            break;

        case WIN_FAULT:
            windowFault(keyIn);
            if (sysFault == 0) windowState = WIN_MAIN;
            break;

        case WIN_SETUP1:
            lcdCenter(7, "Setup 1");
            lcdSoftkeys1("Com", "Set", "Con", "More");
            lcdSoftkeys0(" fort", " Time", " fig", "");
            if (keyIn & KEY_A) windowState = WIN_COMFORT_BASE;
            else if (keyIn & KEY_B)
            {
                windowState = WIN_SET_TIME;
                timeBuffer = time;
                if (timeBuffer.month == 0)      // Need valid values for formatted string
                {
                    timeBuffer.dayMonth = 10;
                    timeBuffer.month = 11;
                    timeBuffer.year = 15;
                }
            }
            else if (keyIn & KEY_C) windowState = WIN_RESOURCES_BASE;
            else if (keyIn & KEY_D) windowState = WIN_SETUP2;
            break;

        case WIN_SETUP2:
            lcdCenter(7, "Setup 2");
            lcdSoftkeys1("Units", "Sys", "Set", "More");
            lcdSoftkeys0("", "Info", " WiFi", "");
            if (keyIn & KEY_A) windowState = WIN_MEAS_UNITS;
            else if (keyIn & KEY_B) windowState = WIN_SYSINFO;
            else if (keyIn & KEY_C) windowState = WIN_SET_WIFI;
            else if (keyIn & KEY_D) windowState = WIN_SETUP3;
            break;

        case WIN_SETUP3:
            lcdCenter(7, "Setup 3");
            lcdSoftkeys1("Calib", "Net", "Defau", "Esc");
            lcdSoftkeys0(" rate", " work", " lts", "");
            if (keyIn & KEY_A) windowState = WIN_SET_CALIBRATIONS;
            else if (keyIn & KEY_B) windowState = WIN_NETWORK_INFO ;
            else if (keyIn & KEY_C) windowState = WIN_DEFAULTS_BASE ;
            else if (keyIn & KEY_D) windowState = WIN_MAIN;
            break;

        case WIN_COMFORT_BASE:
            windowComfortZone(keyIn);
            break;

        case WIN_CZ_SET_TEMP:
            windowCZTemper(keyIn);
            break;

        case WIN_CZ_SET_RH:
            windowCZRHumid(keyIn);
            break;

        case WIN_RESOURCES_BASE:
            lcdCenter(7, "Configure Resources");
            lcdUpDnEnEs();
            strcpy(ioBfr, "Setup modules");
            if (field == 0) lcdStrAt(4, 116, "<");
            else strcat(ioBfr, "    ");
            lcdStrAt(4, 4, ioBfr);

            strcpy(ioBfr, "Setup HVAC");
            if (field == 1) lcdStrAt(3, 116, "<");
            else strcat(ioBfr, "    ");
            lcdStrAt(3, 4, ioBfr);

            if (keyIn & (KEY_A | KEY_B))
            {
                if (field == 0)
                {
                    field = 1;
                    lcdStrAt(4, 116, " ");
                }
                else
                {
                    field = 0;
                    lcdStrAt(3, 116, " ");
                }
            }
            else if (keyIn & KEY_C)
            {
                if (field == 0)
                {
                    windowState = WIN_RES_MODULES;
                }
                else
                {
                    windowState = WIN_RES_SET_HVAC;
                    field = 0;
                }
            }
            else if (keyIn & KEY_D) windowState = WIN_SETUP1;
            break;

        case WIN_RES_SET_HVAC:
            windowSetParent(keyIn);
            break;

        case WIN_SET_TIME:
            windowSetTime(keyIn);
            break;

        case WIN_RES_MODULES:
            windowReviewModules(keyIn);
            break;

        case WIN_RES_SET_MODULE:
            windowModifyModules(keyIn);
            break;

        case WIN_MEAS_UNITS:
            windowMeasUnits(keyIn);
            break;

        case WIN_SYSINFO:   
            windowSysInfo(keyIn);
            break;

        case WIN_DEFAULTS_BASE:
            windowDefaults(keyIn);
            break;

        case WIN_EXECUTE_DEFAULTS:      // Uses field as index
            strcpy(ioBfr, field == 1 ? "Recover last save." : "Factory defaults");
            lcdCenter(5, ioBfr);
            lcdCenter(4, "Are you sure?");
            lcdSoftkeys1("", "", "Yes", "No");
            if (keyIn & KEY_C)
            {
                if (field) factoryHardInit();
                else smemReadParms(SMEM_SILENT);
                field = 0;
                windowState = WIN_MAIN;
            }
            else if (keyIn & KEY_D)
            {
                field = 0;
                windowState = WIN_SETUP3;
            }
            break;

        case WIN_SET_WIFI:      // TODO just a stub
            windowSetWiFi(keyIn);
            break;

         case WIN_SET_CALIBRATIONS:   // TODO just a stub
            windowCalibrate(keyIn);
            break;

        case WIN_NETWORK_INFO:      // TODO just a stub
            lcdCenter(7, "Network Info");
            lcdSoftkeys1("", "", "", "Esc");
            if (keyIn) windowState = WIN_SETUP3;
    }
    if (keyIn) windowTimeout = TIMEOUT_T;
}

    // ---------------------------------------
void windowMain(char keyIn)
{   
    extern double temperNowF, rhumidNow;
    extern double temperNowExteriorF, rhumidNowExterior;
    byte hourDisplayed;

    lcdCenter(7, "DuraBlis CCS");

    if (rhumidNow <= 5) strcpy(ioBfr, " * Measuring * ");
    else if (rhumidNow > 1.15 * oP.setPointRelHum) strcpy(ioBfr, "   * Damp *   ");
    else if (rhumidNow < 0.85 * oP.setPointRelHum) strcpy(ioBfr, "    * Dry *    ");
    else strcpy(ioBfr, "* Comfortable *");     // TODO expand this to include T
    lcdCenter(6, ioBfr);

    timeRead(TIME_UPDATE);
    if (!(sysFault & FLT_CLOCKNOTSET) && timeInBounds())
    {
        if (time.hour == 0) hourDisplayed = 12;
        else if (time.hour > 12) hourDisplayed = time.hour - 12;
        else hourDisplayed = time.hour;

        sprintf(ioBfr, "%s %02d - %02d:%02d%s",
            monStr[time.month-1], time.dayMonth, hourDisplayed, time.minute, time.hour > 11 ? "pm" : "am" );
        lcdCenter(5, ioBfr);
    }
   
    strcpy(ioBfr, "Temp: ");
    if (temperNowF == 0.0) strcat(ioBfr, "WAIT");     // TODO inadequate
    else
    {
        if (oP.sysStat & ST_USE_CELSIUS) sprintf(bfr2, "%2.01f[C", 0.55556 * (temperNowF - 32));
        else sprintf(bfr2, "%2.01f[F (%2.01f)", temperNowF, temperNowExteriorF);
        strcat(ioBfr, bfr2);
    }
    lcdStrAt(4, 4, ioBfr);

    strcpy(ioBfr, "Humid: ");
    if (rhumidNow == 0.0) strcat(ioBfr, "WAIT");
    else
    {
        sprintf(bfr2, "%2.1f%% (%2.1f)", rhumidNow, rhumidNowExterior);
        strcat(ioBfr, bfr2);
    }

//    if (rhumidNow > 1.15 * oP.setPointRelHum) strcat(ioBfr, "Damp");
//    else if (rhumidNow < 0.85 * oP.setPointRelHum) strcat(ioBfr, "Dry ");
////    else if (rhumidNow = 0.0) strcpy(bfr2, "WAIT");
//    else strcat(ioBfr, "Okay");
//    strcat(ioBfr, bfr2);
   
    lcdStrAt(3, 4, ioBfr);

    lcdSoftkeys1("", "", "", "Setup");
    if (keyIn & KEY_D) windowState = WIN_SETUP1;
}

    // ---------------------------------------
void windowFault(char keyIn)
{    
    unsigned fltIdx;
    byte hourDisplayed;

    lcdCenter(7, "DuraBlis");
    lcdCenter(6, "Climate Control");

    timeRead(TIME_UPDATE);
    if (!(sysFault & FLT_CLOCKNOTSET) && timeInBounds())
    {
        if (time.hour == 0) hourDisplayed = 12;
        else if (time.hour > 12) hourDisplayed = time.hour - 12;
        else hourDisplayed = time.hour;

        sprintf(ioBfr, "%s %02d - %02d:%02d%s",
            monStr[time.month-1], time.dayMonth, hourDisplayed, time.minute, time.hour > 11 ? "pm" : "am" );
        lcdCenter(5, ioBfr);
    }
   
    for (fltIdx = 0x8000; fltIdx > 0; fltIdx >>= 1)
    {
        if (sysFault & fltIdx)
        {
            switch(fltIdx)
            {
                case FLT_LOSTCHILD:
                    strcpy(ioBfr, "MODULE LOST"); lcdCenter(4, ioBfr);      // TODO mechanism to say which one
                    strcpy(ioBfr, "FROM NETWORK"); lcdCenter(3, ioBfr);
                    break;

                case FLT_CHILDFAULT:
                    strcpy(ioBfr, "MODULE REPORTS"); lcdCenter(4, ioBfr);
                    strcpy(ioBfr, "MAJOR FAULT"); lcdCenter(3, ioBfr);
                    break;

                case FLT_PARENT_TSENSOR:
                    strcpy(ioBfr, "MAIN TEMPERATURE"); lcdCenter(4, ioBfr);
                    strcpy(ioBfr, "SENSOR FAULT"); lcdCenter(3, ioBfr);
                    break;

                case FLT_PARENT_HSENSOR:
                    strcpy(ioBfr, "MAIN HUMIDITY"); lcdCenter(4, ioBfr);
                    strcpy(ioBfr, "SENSOR FAULT"); lcdCenter(3, ioBfr);
                    break;

                case FLT_CANNOTCONTROLTEMP:
                    strcpy(ioBfr, "CANNOT REACH"); lcdCenter(4, ioBfr);
                    strcpy(ioBfr, "TEMPERATURE SETPOINT"); lcdCenter(3, ioBfr);
                    break;

                case FLT_CANNOTCONTROLHUM:
                    strcpy(ioBfr, "CANNOT REACH"); lcdCenter(4, ioBfr);
                    strcpy(ioBfr, "HUMIDITY SETPOINT"); lcdCenter(3, ioBfr);
                    break;

                case FLT_SYSTEMERROR:
                    strcpy(ioBfr, "GENERAL SYSTEM"); lcdCenter(4, ioBfr);
                    strcpy(ioBfr, "FAULT"); lcdCenter(3, ioBfr);
                    break;

                case FLT_SMEM:
                    strcpy(ioBfr, "SMEM"); lcdCenter(4, ioBfr);
                    strcpy(ioBfr, "FAULT"); lcdCenter(3, ioBfr);
                    break;

                case FLT_SENSORSNOTCALIB:
                    strcpy(ioBfr, "SENSORS NOT"); lcdCenter(4, ioBfr);
                    strcpy(ioBfr, "CALIBRATED"); lcdCenter(3, ioBfr);
                    break;

                case FLT_CLOCKNOTSET:
                    strcpy(ioBfr, "CLOCK NOT"); lcdCenter(4, ioBfr);
                    strcpy(ioBfr, "SET"); lcdCenter(3, ioBfr);
                    break;
            }
            break;              // Break for loop to preserve fltIdx
        }
    }

    lcdSoftkeys1("", "", "", "Clear");
    windowTimeout = TIMEOUT_T;      // There is no timeout from fault window
    
    if (keyIn & KEY_D) 
    {
        sysFault &= ~fltIdx;     // Clear each bit in succession from MSB on down  TODO
        //sysFault = 0;
//        sprintf(ioBfr, "[%d]", windowState);         // DEB
//        putStr(ioBfr); // DEB
        lcdScreen(mainScreen);       
    }
}

    // ---------------------------------------
    // TODO use resourceQuery() Assign()
void windowSetParent(char keyIn)
{
   // byte relay;
    lcdCenter(7, "Main module HVAC");
    lcdUpDnEnEs();
    strcpy(ioBfr, "Air Cond.: ");
        // if (resourceQuery(&resourceMatrix.airConditioner, IDX_PARENT) & 0x01) strcat(ioBfr, "Yes");  obsolete
    if (resourceMatrix.airConditioner & RES_ParA) strcat(ioBfr, "Yes");
    else strcat(ioBfr, "No "); 
    if (field == 0)
    {
        lcdStrAt(3, 116, " ");
        lcdStrAt(4, 116, "<");
    }
    lcdStrAt(4, 2, ioBfr);

    strcpy(ioBfr, "Heater: ");
    if (resourceMatrix.heater & RES_ParB) strcat(ioBfr, "Yes");
    else strcat(ioBfr, "No ");
    if (field == 1)
    {
        lcdStrAt(4, 116, " ");
        lcdStrAt(3, 116, "<");
    }
    lcdStrAt(3, 2, ioBfr);

    if (keyIn & (KEY_A | KEY_B))
    {
        if (field == 0) field = 1; else field = 0;
    }
    else if (keyIn & KEY_C)
    {
        if (field == 0) resourceMatrix.airConditioner ^= RES_ParA;
        else resourceMatrix.heater ^= RES_ParB;
    }
    else if (keyIn & KEY_D)     // TODO buffer?
    {
        field = 0;
        windowState =  WIN_RESOURCES_BASE;
    }
}

    // 0---0---0-----1--1-1-
    // 0---4---8-----4--7-9-    x 6
    // Nov 10, 2014  05:55am
void windowSetTime(char keyIn)
{
    byte hourDisplayed;

    lcdCenter(7, "Set Date & Time");
    lcdUpDnEnEs();
    if (timeBuffer.hour == 0) hourDisplayed = 12;
    else if (timeBuffer.hour > 12) hourDisplayed = timeBuffer.hour - 12;
    else hourDisplayed = timeBuffer.hour;
    sprintf(ioBfr, "%s %02d, 20%02d  %02d:%02d%s",
        monStr[timeBuffer.month-1], timeBuffer.dayMonth, timeBuffer.year, hourDisplayed, timeBuffer.minute, timeBuffer.hour > 11 ? "pm" : "am" );
    lcdStrAt(4, 2, ioBfr);
    if (field == 0) { lcdStrAt(3, 104, "  "); lcdStrAt(3, 2, "^^^"); }
    else if (field == 1) { lcdStrAt(3, 2, "   "); lcdStrAt(3, 26, "^^"); }
    else if (field == 2) { lcdStrAt(3, 26, "  "); lcdStrAt(3, 50, "^^^^"); }
    else if (field == 3) { lcdStrAt(3, 50, "    "); lcdStrAt(3, 86, "^^"); }
    else { field = 4; lcdStrAt(3, 86, "  "); lcdStrAt(3, 104, "^^"); }
  
    if (keyIn & KEY_A)
    {
        switch(field)
        {
            case 0:
                if (timeBuffer.month < 12) timeBuffer.month++;
                else timeBuffer.month = 1;
                break;
            case 1:
                if (timeBuffer.dayMonth < daysInMonth(timeBuffer.month, timeBuffer.year)) timeBuffer.dayMonth++;       // TODO Do reality check final date
                else timeBuffer.dayMonth = 1;
                break;
            case 2:
                if (timeBuffer.year < 99) timeBuffer.year++;
                else timeBuffer.year = 0;
                break;
            case 3:
                if (timeBuffer.hour < 23) timeBuffer.hour++;
                else timeBuffer.hour = 0;
                break;
            case 4:
                if (timeBuffer.minute < 59) timeBuffer.minute++;
                else timeBuffer.minute = 0;
                break;
        }
        //windowTimeout = TIMEOUT_T;
    }
    else if (keyIn & KEY_B)
    {
        switch(field)
        {
            case 0:
                if (timeBuffer.month > 1) timeBuffer.month--;
                else timeBuffer.month = 12;
                break;
            case 1:
                 if (timeBuffer.dayMonth > 1) timeBuffer.dayMonth--;
                else timeBuffer.dayMonth = daysInMonth(timeBuffer.month, timeBuffer.year);
                break;
            case 2:
                if (timeBuffer.year > 0) timeBuffer.year--;
                else timeBuffer.year = 99;
                break;
            case 3:
                if (timeBuffer.hour > 0) timeBuffer.hour--;
                else timeBuffer.hour = 23;
                break;
            case 4:
                if (timeBuffer.minute > 0) timeBuffer.minute--;
                else timeBuffer.minute = 59;
                break;
        }
       //windowTimeout = TIMEOUT_T;
    }
    else if (keyIn & KEY_C)
    {
        time = timeBuffer;
        sysFault &= ~FLT_CLOCKNOTSET;
        timeWrite();
        if (smemWriteTime() == 0) sysFault |= FLT_SMEM;
        if (field < 4) field++;
        else field = 0;
    }
    else if (keyIn & KEY_D)     
    {
        windowState = WIN_SETUP1;
        field = 0;
    }
}

    // ------------------
void windowComfortZone(char keyIn)
{   
    lcdCenter(7, "Comfort Zone");
    lcdUpDnEnEs();
    strcpy(ioBfr, "Temperature: ");
    if (oP.sysStat & ST_USE_CELSIUS) sprintf(bfr2, "%2.0f[C", temperF2C(oP.setPointTempF));
    else sprintf(bfr2, "%2.0f[F", oP.setPointTempF);
    strcat(ioBfr, bfr2);
    if (field == 0) strcat(ioBfr, " <");
    else strcat(ioBfr, "    ");
    lcdStrAt(4, 4, ioBfr);

    strcpy(ioBfr, "Rel Humidity: ");
    sprintf(bfr2, "%2.0f%%", oP.setPointRelHum);
    strcat(ioBfr, bfr2);
    if (field == 1) strcat(ioBfr, " <");
    else strcat(ioBfr, "    ");
    lcdStrAt(3, 4, ioBfr);

    if (keyIn & (KEY_A | KEY_B))
    {
        if (field == 0) field = 1; else field = 0;
    }

    else if (keyIn & KEY_C)
    {
        if (field == 0) windowState = WIN_CZ_SET_TEMP;
        else windowState = WIN_CZ_SET_RH;
        field = 0;
    }

    else if (keyIn & KEY_D)
    {
        field = 0;
        windowState = WIN_SETUP1;
    }
}

 // ------------------
void windowCZTemper(char keyIn)
{
    lcdCenter(7, "Comfort Zone");
    lcdUpDnEnEs();
    strcpy(ioBfr, "Temperature: ");
    if (oP.sysStat & ST_USE_CELSIUS) sprintf(bfr2, "%2.01f[C", temperF2C(oP.setPointTempF));
    else sprintf(bfr2, "%2.0f[F", oP.setPointTempF);
    strcat(ioBfr, bfr2);
    if (field == 0) strcat(ioBfr, " <");
    else strcat(ioBfr, "    ");
    lcdStrAt(4, 4, ioBfr);

    if (keyIn & KEY_A)
    {
        if (oP.setPointTempF < SET_TEMP_MAX) oP.setPointTempF += 1;
        else oP.setPointTempF = SET_TEMP_MIN;
    }
    else if (keyIn & KEY_B)
    {
        if (oP.setPointTempF > SET_TEMP_MIN) oP.setPointTempF -= 1;
        else oP.setPointTempF = SET_TEMP_MAX;
    }
    else if (keyIn & KEY_C)
    {
       windowState =  WIN_CZ_SET_RH;
    }
    else if (keyIn & KEY_D)
    {
        field = 0;
        windowState = WIN_COMFORT_BASE;
    }
}

 // ------------------
void windowCZRHumid(char keyIn)
{
    lcdCenter(7, "Comfort Zone");
    lcdUpDnEnEs();
    strcpy(ioBfr, "Rel Humid: ");
    sprintf(bfr2, "%2.0f%%", oP.setPointRelHum);
    strcat(ioBfr, bfr2);
    if (field == 0) strcat(ioBfr, " <");
    else strcat(ioBfr, "    ");
    lcdStrAt(4, 4, ioBfr);

    if (keyIn & KEY_A)
    {
        if (oP.setPointRelHum < SET_RH_MAX) oP.setPointRelHum += 1;
        else oP.setPointRelHum = SET_RH_MIN;
    }
    else if (keyIn & KEY_B)
    {
        if (oP.setPointRelHum > SET_RH_MIN) oP.setPointRelHum -= 1;
        else oP.setPointRelHum = SET_RH_MAX;
    }
    else if (keyIn & (KEY_C | KEY_D))
    {
        field = 0;
        windowState = WIN_COMFORT_BASE;
    }
}

    // --------------------------
    // child is 1-idx'd, 0 used for parent
void windowReviewModules(char keyIn)
{
    byte extraSensors;
    sprintf(ioBfr, "Module %d", childFocus);
    lcdCenter(7, ioBfr);
    lcdUpDnEnEs();

    resourceQuery(childFocus, 'A', bfr2);
    sprintf(ioBfr, "Relay 1: %s", bfr2);
    lcdStrAt(6, 4, ioBfr);

    resourceQuery(childFocus, 'B', bfr2);
    sprintf(ioBfr, "Relay 2: %s", bfr2);
    lcdStrAt(5, 4, ioBfr);

    extraSensors = 0;
    resourceQuery(childFocus, 'F', bfr2);
    if (strncmp(bfr2, "Free", 4) != 0)
    {
        extraSensors++;
        strcpy(ioBfr, bfr2);
        lcdStrAt(4, 4, ioBfr);
    }
    resourceQuery(childFocus, 'X', bfr2);
    if (strncmp(bfr2, "Free", 4) != 0)
    {
        extraSensors++;
        strcpy(ioBfr, bfr2);
        lcdStrAt(3, 4, ioBfr);
    }
    if (extraSensors == 0)
    {
        strcpy(ioBfr, "No extra sensors");
        lcdStrAt(4, 4, ioBfr);
    }

  //  strcpy(ioBfr, "Connected: ");
  //  if (child[childFocus - 1].status & CHILD_COMMUNICATING) strcat(ioBfr, "Yes");
  //  else strcat(ioBfr, "No");
  //  lcdStrAt(3, 6, ioBfr);

    if (keyIn & KEY_A)
    {
        if (childFocus < NUM_CHILDREN) childFocus++; else childFocus = 1;
        lcdScreen(mainScreen);
      //  windowTimeout = TIMEOUT_T;
    }
    else if (keyIn & KEY_B)
    {
        if (childFocus > 1) childFocus--; else childFocus = NUM_CHILDREN;
        lcdScreen(mainScreen);
       // windowTimeout = TIMEOUT_T;
    }
    else if (keyIn & KEY_C)
    {
        windowState = WIN_RES_SET_MODULE;       // Will use childFocus
        field = 0;
    }
    else if (keyIn & KEY_D)     
    {
        windowState = WIN_RESOURCES_BASE;
        field = 0;
    }
}

    // ------------------------------------
void windowModifyModules(char keyIn)
{
    sprintf(ioBfr, "Modify Module %d", childFocus);
    lcdCenter(7, ioBfr);
    lcdUpDnEnEs();
    
    resourceQuery(childFocus, 'A', bfr2);
    sprintf(ioBfr, "Relay 1: %s", bfr2);
    lcdStrAt(6, 4, ioBfr);
    if (field == 0)
    {
        lcdStrAt(3, 116, " ");
        lcdStrAt(6, 116, "<");
    }
   
    resourceQuery(childFocus, 'B', bfr2);
    sprintf(ioBfr, "Relay 2: %s", bfr2);
    lcdStrAt(5, 4, ioBfr);
    if (field == 1)
    {
        lcdStrAt(6, 116, " ");
        lcdStrAt(5, 116, "<");
    }
    lcdStrAt(5, 4, ioBfr);

    strcpy(ioBfr, "Flood sensor: ");
    resourceQuery(childFocus, 'F', bfr2);
    if (strncmp(bfr2, "Free", 4) == 0) strcat(ioBfr, "No");
    else strcat(ioBfr, "Yes");
    if (field == 2)
    {
        lcdStrAt(5, 116, " ");
        lcdStrAt(4, 116, "<");
    }
    lcdStrAt(4, 4, ioBfr);

    strcpy(ioBfr, "Exter. sensor: ");
    resourceQuery(childFocus, 'X', bfr2);
    if (strncmp(bfr2, "Free", 4) == 0) strcat(ioBfr, "No");
    else strcat(ioBfr, "Yes");

    if (field == 3)
    {
        lcdStrAt(4, 116, " ");
        lcdStrAt(3, 116, "<");
    }
    lcdStrAt(3, 4, ioBfr);

    if (keyIn & KEY_A)
    {
        if (field == 0) resourceKCycle(childFocus, 'A', RES_CYCLE_UP);
        else if (field == 1) resourceKCycle(childFocus, 'B', RES_CYCLE_UP);
        else if (field == 2) resourceMatrix.floodSensor ^= (0x0001 << (childFocus - 1));
        else
        {
            if (resourceMatrix.outsideTH == childFocus) resourceMatrix.outsideTH = 0;
            else resourceMatrix.outsideTH = childFocus;     // Preemptive and exclusive
        }
        lcdScreen(mainScreen);
       // windowTimeout = TIMEOUT_T;
    }
    else if (keyIn & KEY_B)
    {
        if (field == 0) resourceKCycle(childFocus, 'A', RES_CYCLE_DOWN);
        else if (field == 1) resourceKCycle(childFocus, 'B', RES_CYCLE_DOWN);
        else if (field == 2) resourceMatrix.floodSensor ^= (0x0001 << (childFocus - 1));
        else
        {
            if (resourceMatrix.outsideTH == childFocus) resourceMatrix.outsideTH = 0;
            else resourceMatrix.outsideTH = childFocus;     // Preemptive and exclusive
        }
        lcdScreen(mainScreen);
        //windowTimeout = TIMEOUT_T;
    }
    else if (keyIn & KEY_C)
    {
        if (field < 3) field++;        // Ie, we did relay 1, now do 2, then the extras
        else
        {
            field = 0;
            windowState = WIN_RES_MODULES;
        }
    }
    else if (keyIn & KEY_D)     // TODO buffer?
    {
        field = 0;
        windowState = WIN_RES_MODULES;
    }
}

 // ------------------
void windowMeasUnits(char keyIn)
{   
    lcdCenter(7, "Measurement Units");
    lcdSoftkeys1("Next", "Chan", "Enter", "Esc");
    lcdSoftkeys0("", " ge", "", "");

    strcpy(ioBfr, "Temper: ");
    if (oP.sysStat & ST_USE_CELSIUS) strcat(ioBfr, "Celsius ");
    else strcat (ioBfr, "Fahrenh.");
    if (field == 0) strcat(ioBfr, " <");
    else strcat(ioBfr, "    ");
    lcdStrAt(4, 4, ioBfr);

    strcpy(ioBfr, "Humid: ");
    if (oP.sysStat & ST_USE_DEWPOINT) strcat(ioBfr, "Dew point");
    else strcat (ioBfr, "Rel Humid");
    if (field == 1) strcat(ioBfr, " <");
    else strcat(ioBfr, "    ");
    lcdStrAt(3, 4, ioBfr);

    if (keyIn & KEY_A)
    {
        if (field == 0) field = 1;
        else field = 0;
 
    }
    else if (keyIn & KEY_B)
    {
        if (field == 0) oP.sysStat ^= ST_USE_CELSIUS;
        else oP.sysStat ^= ST_USE_DEWPOINT;
        if (smemWriteParms() <= 0) sysFault |= FLT_SMEM;
    }
    else if (keyIn & KEY_C)
    {
        if (field == 0) field = 1;
        else
        {
            field = 0;
            windowState = WIN_SETUP1;
        }
    }
    else if (keyIn & KEY_D)
    {
        field = 0;
        windowState = WIN_SETUP1;
    }
}

    // --------------------------
void windowSysInfo(char keyIn)
{
    extern char verStr[11];
//    extern char uniqueID[11];
//    extern double temperCalFactor;   // For Fahrenheit
//    extern double oP.rhumidCalFactor;
    extern double iSen[NUM_CHILDREN];
  
    lcdSoftkeys1("Page", "Page", "Page", "Esc");
    lcdSoftkeys0(" 1", " 2", " 3", "");

    lcdCenter(7, "System Info");
    if (field == 0)
    {
        sprintf(ioBfr, "Version: %s", verStr);
        lcdStrAt(6, 4, ioBfr);
        sprintf(ioBfr, "UID: %s", oP.uniqueID);
        lcdStrAt(5, 4, ioBfr);
        sprintf(ioBfr, "Sys Stat: %04X", oP.sysStat);
        lcdStrAt(4, 4, ioBfr);
        sprintf(ioBfr, "Sys Fault: %04X", sysFault);
        lcdStrAt(3, 4, ioBfr);
    }
    else if (field == 1)
    {
        sprintf(ioBfr, "T cal factor: %5.04f", oP.temperCalFactor);
        lcdStrAt(6, 4, ioBfr);
        sprintf(ioBfr, "H cal factor: %5.04f", oP.rhumidCalFactor);
        lcdStrAt(5, 4, ioBfr);
    }
    else if (field == 2)
    {
        adcCurrents(ADC_SILENT);
        sprintf(ioBfr, "Ch1:%3.01f 2:%3.01f mA", iSen[0], iSen[1]);
        lcdStrAt(6, 4, ioBfr);
        sprintf(ioBfr, "Ch3:%3.01f 4:%3.01f mA", iSen[2], iSen[3]);
        lcdStrAt(5, 4, ioBfr);
        sprintf(ioBfr, "Ch5:%3.01f 6:%3.01f mA", iSen[4], iSen[5]);
        lcdStrAt(4, 4, ioBfr);
        sprintf(ioBfr, "Ch7:%3.01f 8:%3.01f mA", iSen[6], iSen[7]);
        lcdStrAt(3, 4, ioBfr);
    }

    if (keyIn & KEY_A) { field = 0; lcdScreen(mainScreen); }
    else if (keyIn & KEY_B) { field = 1; lcdScreen(mainScreen); }
    else if (keyIn & KEY_C) { field = 2; lcdScreen(mainScreen); }
    else if (keyIn & KEY_D) { field = 0; windowState = WIN_SETUP2; }
}

    // ---------------
 void windowDefaults(char keyIn)
 {
    lcdCenter(7, "Restore Defaults");
    lcdUpDnEnEs();
    strcpy(ioBfr, "Factory?");
    if (field == 0) strcat(ioBfr, " <");
    else strcat(ioBfr, "    ");
    lcdStrAt(4, 4, ioBfr);

    strcpy(ioBfr, "Last save?");
    if (field == 1) strcat(ioBfr, " <");
    else strcat(ioBfr, "    ");
    lcdStrAt(3, 4, ioBfr);

    if (keyIn & (KEY_A | KEY_B))
    {
        if (field == 0) field = 1; else field = 0;
    }

    else if (keyIn & KEY_C)
    {
        windowState = WIN_EXECUTE_DEFAULTS;     // Keep field as a reference
    }

    else if (keyIn & KEY_D)
    {
        field = 0;
        windowState = WIN_SETUP3;
    }
}


    // ------------------
    // This is an experiment in reverse fielding
 void windowSetWiFi(char keyIn)
{
    static char keyInOld = 0xFF;

    //windowTimeout = TIMEOUT_T;    // DEB
    if (keyIn == keyInOld) return;
    keyInOld = keyIn;
    lcdCenter(7, "Setup WiFi");
    lcdUpDnEnEs();
    sprintf(ioBfr, "IP:   %02X.%02X.%02X.%02X", wifiIP[3], wifiIP[2], wifiIP[1], wifiIP[0]);
    lcdStrAt(6, 4, ioBfr);
    sprintf(ioBfr, "Mask: %02X.%02X.%02X.%02X", wifiMask[3], wifiMask[2], wifiMask[1], wifiMask[0]);
    lcdStrAt(5, 4, ioBfr);
    sprintf(ioBfr, "DHCP: %s", wifiDHPC ? "Yes" : "No ");
    lcdStrAt(4, 4, ioBfr);

    if (keyIn & KEY_D)
    {
        windowState = WIN_SETUP2;
        field = 0;
        return;
    }
    else if (keyIn & KEY_C)
    {
        if (field < 8) field++;  else field = 0;
    }

    switch(field)
    {
        case 0:
            if (keyIn == KEY_A) wifiIP[3]++;
            else if (keyIn == KEY_B) wifiIP[3]--;                
            sprintf(ioBfr, "%02X", wifiIP[3]);
            lcdReverseStrAt(6, 40, ioBfr);
            break;

        case 1:
            if (keyIn == KEY_A) wifiIP[2]++;
            else if (keyIn == KEY_B) wifiIP[2]--;
            sprintf(ioBfr, "%02X", wifiIP[2]);
            lcdReverseStrAt(6, 58, ioBfr);
            break;

        case 2:
           if (keyIn == KEY_A) wifiIP[1]++;
            else if (keyIn == KEY_B) wifiIP[1]--;
            sprintf(ioBfr, "%02X", wifiIP[1]);
            lcdReverseStrAt(6, 76, ioBfr);
            break;

        case 3:
           if (keyIn == KEY_A) wifiIP[0]++;
            else if (keyIn == KEY_B) wifiIP[0]--;
            sprintf(ioBfr, "%02X", wifiIP[0]);
            lcdReverseStrAt(6, 94, ioBfr);
            break;

        case 4:
            if (keyIn == KEY_A) wifiMask[3]++;
            else if (keyIn == KEY_B) wifiMask[3]--;
            sprintf(ioBfr, "%02X", wifiMask[3]);
            lcdReverseStrAt(5, 40, ioBfr);
            break;

        case 5:
            if (keyIn == KEY_A) wifiMask[2]++;
            else if (keyIn == KEY_B) wifiMask[2]--;
            sprintf(ioBfr, "%02X", wifiMask[2]);
            lcdReverseStrAt(5, 58, ioBfr);
            break;

        case 6:
            if (keyIn == KEY_A) wifiMask[1]++;
            else if (keyIn == KEY_B) wifiMask[1]--;
            sprintf(ioBfr, "%02X", wifiMask[1]);
            lcdReverseStrAt(5, 76, ioBfr);
            break;

        case 7:
            if (keyIn == KEY_A) wifiMask[0]++;
            else if (keyIn == KEY_B) wifiMask[0]--;
            sprintf(ioBfr, "%02X", wifiMask[0]);
            lcdReverseStrAt(5, 94, ioBfr);
            break;

        case 8:
            if (keyIn == KEY_A) wifiDHPC ^= true;
            else if (keyIn == KEY_B) wifiDHPC ^= true;
            sprintf(ioBfr, "%s", wifiDHPC ? "Yes" : "No ");
            lcdReverseStrAt(4, 40, ioBfr);
            break;
    }  
}

void windowCalibrate(char keyIn)
{
//    extern double temperCalFactor;   // For Fahrenheit
//    extern double rhumidCalFactor;

    lcdCenter(7, "Calibra. Constants");
    lcdUpDnEnEs();
    strcpy(ioBfr, "Temperature: ");
    sprintf(bfr2, "%3.02f", oP.temperCalFactor);
    strcat(ioBfr, bfr2);
    if (field == 0) strcat(ioBfr, " <");
    else strcat(ioBfr, "    ");
    lcdStrAt(5, 4, ioBfr);

    strcpy(ioBfr, "Humidity: ");
    sprintf(bfr2, "%3.02f", oP.rhumidCalFactor);
    strcat(ioBfr, bfr2);
    if (field == 1) strcat(ioBfr, " <");
    else strcat(ioBfr, "    ");
    lcdStrAt(4, 4, ioBfr);

    if (keyIn & KEY_A)
    {
        if (field == 0)
        {
            if (oP.temperCalFactor < CAL_FACTOR_MAX) oP.temperCalFactor += 0.01;
            else oP.temperCalFactor = CAL_FACTOR_MIN;
        }
        else
        {
            if (oP.rhumidCalFactor < CAL_FACTOR_MAX) oP.rhumidCalFactor += 0.01;
            else oP.rhumidCalFactor = CAL_FACTOR_MIN;
        }
    }
    else if (keyIn & KEY_B)
    {
        if (field == 0)
        {
            if (oP.temperCalFactor > CAL_FACTOR_MIN) oP.temperCalFactor -= 0.01;
            else oP.temperCalFactor = CAL_FACTOR_MAX;
        }
        else
        {
            if (oP.rhumidCalFactor > CAL_FACTOR_MAX) oP.rhumidCalFactor -= 0.01;
            else oP.rhumidCalFactor = CAL_FACTOR_MAX;
        }
    }
    else if (keyIn & KEY_C)
    {
        if (field < 1) field++; 
        else
        {
            sysFault &= ~FLT_SENSORSNOTCALIB;
            if (smemWriteParms() <= 0) sysFault |= FLT_SMEM;
            field = 0;
        }

    }
    else if (keyIn & KEY_D)
    {
        field = 0;
        windowState = WIN_SETUP3;
    }
}