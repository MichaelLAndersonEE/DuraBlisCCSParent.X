/* File:   smem.c  SEEPROM SPI2-based functions, incl datalog
 * Author: Michael L Anderson
 * Contact: MichaelLAndersonEE@gmail.com
 * Platform: PIC32MX350F256H on DuraBlis-CCS-Main_v4 board.
 * SEEPROM: 25AA128, 16 Kbyte, 256 64-byte pages
 * Created: 02 Oct 14
 */

#include <xc.h>
#include <string.h>
#include "DuraBlisCCSParent.h"
#include "smem.h"
#include "serial.h"
#include "time.h"
#include "keypad.h"
#include "resources.h"

    // SMEM semantics
#define SMEM_DUMMY  0x00
#define SMEM_READ   0x03
#define SMEM_WRITE  0x02
#define SMEM_WRDI   0x04
#define SMEM_WREN   0x06
#define SMEM_RDSR   0x05
#define SMEM_WRSR   0x01

#define SMEM_NUM_PAGES      256
//#define SMEM_PAGE_SIZE       64
#define SMEM_ARRAY_SIZE      64     // Max bytes in buffer for any one rd/wr block
#define SMEM_ADDR_TIME        0     // Page 0 for time save.
#define SMEM_ADDR_PARMS      64     // Page 1 for parms (cal consts, etc)
#define SMEM_ADDR_UID       128     // Page 2 for UID string
#define SMEM_ADDR_ISEN_CAL  192     // Page 3 for iSen cal factors
#define SMEM_ADDR_RESMTX    256     // Page 4 for resourceMatrix
#define SMEM_ADDR_DATALOG   320     // Pages 5..205 for DL

#define DL_MAX_RECORDS     1600     // 8 doubles per page x 200 pgs
#define DL_RECORD_SIZE        8     // Bytes, 2 doubles now
#define DL_RECORDS_PER_PAGE   8     // 64 bytes per pg / (4 bytes per float * 2 doubles per record)
#define DL_PAGES            200

static int smem_ReadArray(unsigned addr, byte *arrayPtr, unsigned arraySize);
static int smem_WriteArray(unsigned addr, byte *arrayPtr, unsigned arraySize);
static bool smem_Busy(void);
static byte spi2_WRBuffer(byte datum);

extern struct t_struct time;                    // Page 0
extern struct operatingParms_struct oP;         // Page 1
extern double iSenCalFactor [NUM_CHILDREN];     // Page 2
extern struct res_struct resourceMatrix;        // Page 3.  Datalog uses Pages 4..204

    // Volatile
extern float temperNowF, rhumidNow;
static unsigned dlPage;
static byte dlPageIdx;      // Bytes on a page
static byte smemBfr[SMEM_ARRAY_SIZE];   // All smem traffic here.  Use ioBfr for auxilliary.
static union dl_union
    {
        byte bubble[4];
        double dubble;          // XC32 double is 4 byte
        unsigned long unslong;  // Ditto uns long
        unsigned unsshort;
    } dlU;
//static union oP_union
//{
//    struct operatingParms_struct *oPptr;
//
//} oPU;

    // Destructive erasure of entire SEEPROM.
void smemEraseAll(void)
{
    unsigned page, d;

    for (d = 0; d < SMEM_ARRAY_SIZE; d++) smemBfr[d] = 0xFF;

    putStr("\tsmem destructive erase all...\r\n");
    for (page = 0; page < SMEM_NUM_PAGES; page++)
    {
         if (smem_WriteArray(page * SMEM_ARRAY_SIZE, smemBfr, SMEM_ARRAY_SIZE) != SMEM_ARRAY_SIZE)
         {
             putStr("\tsmemEraseAll failed.\r\n");
             return;
         }        
         petTheDog();
    }

    sprintf(ioBfr, "\tErased %d pages of smem.\r\n", SMEM_NUM_PAGES);
    putStr(ioBfr);
}

        // Destructive write to entire SEEPROM.  TODO Test cross-page writes.
void smemWriteTest(void)
{
    unsigned page, d;
    char testStr[SMEM_ARRAY_SIZE + 1];

    // "Page 000 : 012345678901234567890123456789012345678901234567890123456789

    for (d = 0; d < 40; d++) testStr[d] = '0' + (d % 10);
    testStr[d] = 0;

    putStr("\tsmem destructive write test...\r\n");
    for (page = 0; page < SMEM_NUM_PAGES; page++)
    {
         sprintf(smemBfr, "Page %03d : ", page);
         strcat(smemBfr, testStr);
         if (smem_WriteArray(page * SMEM_ARRAY_SIZE, smemBfr, SMEM_ARRAY_SIZE) != SMEM_ARRAY_SIZE)
         {
             putStr("\tsmemWriteTest failed.\r\n");
             return;
         }
         else
         {
             putStr(smemBfr);
             putStr("\r\n");
         }
         petTheDog();
    }
   
    sprintf(ioBfr, "\tWrote %d pages to smem.", SMEM_NUM_PAGES);
    putStr(ioBfr);    
}

void smemReadTest(void)
{
    unsigned page;
    for (page = 0; page < SMEM_NUM_PAGES; page++)
    {
         if (smem_ReadArray(page * SMEM_ARRAY_SIZE, smemBfr, SMEM_ARRAY_SIZE) != SMEM_ARRAY_SIZE)
         {
             putStr("\tsmemReadTest failed.\r\n");
             return;
         }
         else
         {
             putStr(smemBfr);
             putStr("\r\n");
         }
         petTheDog();
    }
}

    // Called nominally every 5 mins to keep a rough nonvol clock
int smemWriteTime(void)
{
    smemBfr[0] = time.year;
    smemBfr[1] = time.month;
    smemBfr[2] = time.dayMonth;
    smemBfr[3] = time.hour;
    smemBfr[4] = time.minute;

    return (smem_WriteArray(SMEM_ADDR_TIME, smemBfr, 5));
}

    // Called at reset.  Has non-recursive retry.
int smemReadTime(void)
{
    extern unsigned sysFault;
    bool success = true;
    
    if (smem_ReadArray(SMEM_ADDR_TIME, smemBfr, 5) < 5) success = false;

    if (smemBfr[0] > 0 && smemBfr[0] < 100) time.year = smemBfr[0];   // Years from (20)14 - (20)99
    else success = false;
    if (smemBfr[1] > 0 && smemBfr[1] < 13) time.month = smemBfr[1];
    else success = false;
    if (smemBfr[2] > 0 && smemBfr[2] < 32) time.dayMonth = smemBfr[2];
    else success = false;
    if (smemBfr[3] < 60) time.hour = smemBfr[3];
    else success = false;
    if (smemBfr[4] < 60) time.minute = smemBfr[4];
    else success = false;

    if (success == false)
    {
        if (smem_ReadArray(SMEM_ADDR_TIME, smemBfr, 5) == 5) return(-1);

        if (smemBfr[0] > 0 && smemBfr[0] < 100) time.year = smemBfr[0];
        else return(-2);
        if (smemBfr[1] > 0 && smemBfr[1] < 13) time.month = smemBfr[1];
        else return(-3);
        if (smemBfr[2] > 0 && smemBfr[2] < 32) time.dayMonth = smemBfr[2];
        else return(-4);
        if (smemBfr[3] < 60) time.hour = smemBfr[3];
        else return(-5);
        if (smemBfr[4] < 60) time.minute = smemBfr[4];
        else return(-6);
    }

    sysFault &= ~FLT_CLOCKNOTSET;       // Assume that we have an approx clock now
    return (5);
}

    // TODO regenerate actual times
int smemDatalogReport(void)
{   
    unsigned r;
    double T, RH, *dPtr;
    unsigned address = SMEM_ADDR_DATALOG;

    if (oP.dlRecordsSaved == 0)
    {
        putStr("\tNo datalog records saved.\n\r");
        return(0);
    }                      

        // Start at present location, then work down.
    //address = SMEM_ADDR_DATALOG + dlPage * DL_RECORDS_PER_PAGE + dlPageIdx;

    sprintf(ioBfr, "\n\r// #,\toF,\t%%RH\t[%d records]\n\r", oP.dlRecordsSaved);
    putStr(ioBfr);

    for (r = 0; r < oP.dlRecordsSaved; r++)
    {
        smem_ReadArray(address, smemBfr, DL_RECORD_SIZE);
        dlU.bubble[3]  = smemBfr[0];
        dlU.bubble[2]  = smemBfr[1];
        dlU.bubble[1]  = smemBfr[2];
        dlU.bubble[0]  = smemBfr[3];
        T = dlU.dubble;
        dlU.bubble[3]  = smemBfr[4];
        dlU.bubble[2]  = smemBfr[5];
        dlU.bubble[1]  = smemBfr[6];
        dlU.bubble[0]  = smemBfr[7];
        RH = dlU.dubble;

//        dPtr = (double *) (&smemBfr[0]);
//        T = *dPtr;
//        dPtr = (double *) (&smemBfr[4]);
//        RH = *dPtr;
        sprintf(ioBfr, "%3d, \t%2.1f, \t%2.1f,\n\r", r + 1, T, RH);
        putStr(ioBfr);

//        if (address > SMEM_ADDR_DATALOG + DL_RECORD_SIZE) address -= DL_RECORD_SIZE;
//        else address = SMEM_ADDR_DATALOG + DL_MAX_RECORDS - DL_RECORD_SIZE;
        address += DL_RECORD_SIZE;      // TODO wraparound
        petTheDog();
    }
    return(r);        
}

    // Called every time t (nom 5 min).  Smem writes latest T & RH as doubles.
int smemDatalog(void)
{
    static byte dlBfr[SMEM_ARRAY_SIZE];
 
    dlU.dubble = temperNowF;
    dlBfr[dlPageIdx] = dlU.bubble[3];       // Little-endian. The first shall be last.
    dlBfr[dlPageIdx + 1] = dlU.bubble[2];
    dlBfr[dlPageIdx + 2] = dlU.bubble[1];
    dlBfr[dlPageIdx + 3] = dlU.bubble[0];
    dlU.dubble = rhumidNow;
    dlBfr[dlPageIdx + 4] = dlU.bubble[3];
    dlBfr[dlPageIdx + 5] = dlU.bubble[2];
    dlBfr[dlPageIdx + 6] = dlU.bubble[1];
    dlBfr[dlPageIdx + 7] = dlU.bubble[0];

    if (smem_WriteArray(SMEM_ADDR_DATALOG + (dlPage * SMEM_ARRAY_SIZE), dlBfr, SMEM_ARRAY_SIZE) < SMEM_ARRAY_SIZE) return(-1);
    dlPageIdx += DL_RECORD_SIZE;
    if (dlPageIdx >= SMEM_ARRAY_SIZE)
    {
        dlPageIdx = 0;
        if (dlPage++ > DL_PAGES) dlPage = 0;    // Wrap around
    }
    oP.dlRecordsSaved++;
    if (smemWriteParms() < 0) return(-2);       // To record dlRecordsSaved
    return(SMEM_ARRAY_SIZE);
}

    // Called on startup reset and as factory setting restore of operating parms
    // TODO One non-recursive retry.  TODO non-self-referential checksum.
    // Returns num bytes read on success or neg failure code.
int smemReadParms(byte mode)
{
    struct operatingParms_struct oPBfr;
   // int success = 1;
    byte d, *dPtr;
    byte ch;

    if (mode == SMEM_LOQUACIOUS) putStr("\tsRP Test...\r\n");
    if (smem_ReadArray(SMEM_ADDR_PARMS, smemBfr, SMEM_ARRAY_SIZE) < SMEM_ARRAY_SIZE)
    {
        if (mode == SMEM_LOQUACIOUS) putStr("\tsRA read 1 fail.\r\n");
        return(-1);
    }

    dPtr = (byte *) &oPBfr;     // TODO use union?
    for (d = 0; d < SMEM_ARRAY_SIZE; d++)
        *(dPtr + d) = smemBfr[d];

    if (oPBfr.sysStat & ST_ALWAYS_TRUE) 
    {
        oP.sysStat = oPBfr.sysStat;
        if (mode == SMEM_LOQUACIOUS)
        {
            sprintf(ioBfr, "\tsysStat: %04X\r\n", oP.sysStat);
            putStr(ioBfr);
        }
    }
    else
    {
        if (mode == SMEM_LOQUACIOUS) putStr("\tsySt fail.\r\n");
        return(-2);
    }

    if (oPBfr.dlRecordsSaved < DL_MAX_RECORDS) 
    {
        oP.dlRecordsSaved = oPBfr.dlRecordsSaved;
        if (mode == SMEM_LOQUACIOUS)
        {
            sprintf(ioBfr, "\tdlRS: %d\r\n", oP.dlRecordsSaved);
            putStr(ioBfr);
        }
    }
    else
    {
        if (mode == SMEM_LOQUACIOUS) putStr("\tdlRS fail.\r\n");
        return(-3);
    }

    if (oPBfr.setPointTempF > SET_TEMP_MIN && oPBfr.setPointTempF <  SET_TEMP_MAX) 
    {
        oP.setPointTempF = oPBfr.setPointTempF;
        if (mode == SMEM_LOQUACIOUS)
        {
            sprintf(ioBfr, "\tsPTF: %3.02f\r\n", oP.setPointTempF);
            putStr(ioBfr);
        }
    }
    else
    {
        if (mode == SMEM_LOQUACIOUS) putStr("\tsPTF fail.\r\n");
        return(-4);
    }

    if (oPBfr.setPointRelHum > SET_RH_MIN && oPBfr.setPointRelHum <  SET_RH_MAX)
    {
        oP.setPointRelHum = oPBfr.setPointRelHum;
        if (mode == SMEM_LOQUACIOUS)
        {
            sprintf(ioBfr, "\tsPRH: %3.02f\r\n", oP.setPointRelHum);
            putStr(ioBfr);
        }
    }
    else
    {
        if (mode == SMEM_LOQUACIOUS) putStr("\tsPRH fail.\r\n");
        return(-5);
    }

    if (oPBfr.temperCalFactor > CAL_FACTOR_MIN && oPBfr.temperCalFactor < CAL_FACTOR_MAX)
    {
        oP.temperCalFactor = oPBfr.temperCalFactor;
        if (mode == SMEM_LOQUACIOUS)
        {
            sprintf(ioBfr, "\ttCalF: %3.02f\r\n", oP.temperCalFactor);
            putStr(ioBfr);
        }
    }
    else
    {
        if (mode == SMEM_LOQUACIOUS) putStr("\ttCalF fail.\r\n");
        return(-6);
    }
  

    if (oPBfr.rhumidCalFactor > CAL_FACTOR_MIN && oPBfr.rhumidCalFactor < CAL_FACTOR_MAX)
    {
        oP.rhumidCalFactor = oPBfr.rhumidCalFactor;
        if (mode == SMEM_LOQUACIOUS)
        {
            sprintf(ioBfr, "\trhCalF: %3.02f\r\n", oP.rhumidCalFactor);
            putStr(ioBfr);
        }
    }
    else
    {
        if (mode == SMEM_LOQUACIOUS) putStr("\trhCalF fail.\r\n");
        return(-7);
    }

    if (oPBfr.kpadSensit[0] > KEYPAD_SENSIT_MIN && oPBfr.kpadSensit[0] < KEYPAD_SENSIT_MAX)
    {
        oP.kpadSensit[0] = oPBfr.kpadSensit[0];
        if (mode == SMEM_LOQUACIOUS)
        {
            sprintf(ioBfr, "\tkS0: %4.03f\r\n", oP.kpadSensit[0]);
            putStr(ioBfr);
        }
    }
    else
    {
        if (mode == SMEM_LOQUACIOUS) putStr("\tkS0 fail.\r\n");
        return(-8);
    }

    if (oPBfr.kpadSensit[1] > KEYPAD_SENSIT_MIN && oPBfr.kpadSensit[1] < KEYPAD_SENSIT_MAX)
    {
        oP.kpadSensit[1] = oPBfr.kpadSensit[1];
        if (mode == SMEM_LOQUACIOUS)
        {
            sprintf(ioBfr, "\tkS1: %4.03f\r\n", oP.kpadSensit[1]);
            putStr(ioBfr);
        }
    }
    else
    {
        if (mode == SMEM_LOQUACIOUS) putStr("\tkS1 fail.\r\n");
        return(-9);
    }

    if (oPBfr.kpadSensit[2] > KEYPAD_SENSIT_MIN && oPBfr.kpadSensit[2] < KEYPAD_SENSIT_MAX)
    {
        oP.kpadSensit[2] = oPBfr.kpadSensit[2];
        if (mode == SMEM_LOQUACIOUS)
        {
            sprintf(ioBfr, "\tkS2: %4.03f\r\n", oP.kpadSensit[2]);
            putStr(ioBfr);
        }
    }
    else
    {
        if (mode == SMEM_LOQUACIOUS) putStr("\tkS2 fail.\r\n");
        return(-10);
    }
   
    if (oPBfr.kpadSensit[3] > KEYPAD_SENSIT_MIN && oPBfr.kpadSensit[3] < KEYPAD_SENSIT_MAX)
    {
        oP.kpadSensit[3] = oPBfr.kpadSensit[3];
        if (mode == SMEM_LOQUACIOUS)
        {
            sprintf(ioBfr, "\tkS3: %4.03f\r\n", oP.kpadSensit[3]);
            putStr(ioBfr);
        }
    }
    else
    {
        if (mode == SMEM_LOQUACIOUS) putStr("\tkS3 fail.\r\n");
        return(-11);
    }

    if (smem_ReadArray(SMEM_ADDR_UID, smemBfr, UID_SIZE) < UID_SIZE)
    {
        if (mode == SMEM_LOQUACIOUS) putStr("\tsRA read 2 fail.\r\n");
        return(-12);
    }
    smemBfr[UID_SIZE] = 0;
    strcpy(oP.uniqueID, smemBfr);
    if (mode == SMEM_LOQUACIOUS) { sprintf(ioBfr, "\tuID: %s\r\n", oP.uniqueID); putStr(ioBfr); }

//    oPBfr.uniqueID[UID_SIZE - 1] = 0;   // It can be shorter than, but not longer than.
//    for (d = 0; d < UID_SIZE; d++)
//    {
//        ch = oPBfr.uniqueID[d];        // Limit to ASCII-Z and printables
//        if ((ch == 0) || ((ch >= 32) && (ch <= 127)))
//            oP.uniqueID[d] = ch;
//    }
//    oP.uniqueID[UID_SIZE - 1] = 0;
//    if (mode == SMEM_LOQUACIOUS)
//    {
//        sprintf(ioBfr, "\tuID: %s\r\n", oP.uniqueID);
//        putStr(ioBfr);
//    }

    petTheDog();

    if (smem_ReadArray(SMEM_ADDR_RESMTX, smemBfr, SMEM_ARRAY_SIZE) < SMEM_ARRAY_SIZE) return(-20);

        // Obviously, this all must match what is written in sWP
    dlU.bubble[3] = smemBfr[0]; dlU.bubble[2] = smemBfr[1]; dlU.bubble[1] = smemBfr[2]; dlU.bubble[0] = smemBfr[3];
    resourceMatrix.airConditioner = dlU.unslong;
    if (mode == SMEM_LOQUACIOUS) { sprintf(ioBfr, "\trM.AC: %08lX\r\n", resourceMatrix.airConditioner); putStr(ioBfr); }

    dlU.bubble[3] = smemBfr[4]; dlU.bubble[2] = smemBfr[5]; dlU.bubble[1] = smemBfr[6]; dlU.bubble[0] = smemBfr[7];
    resourceMatrix.airExchanger = dlU.unslong;
    if (mode == SMEM_LOQUACIOUS) { sprintf(ioBfr, "\trM.AX: %08lX\r\n", resourceMatrix.airExchanger); putStr(ioBfr); }

    dlU.bubble[3] = smemBfr[8]; dlU.bubble[2] = smemBfr[9]; dlU.bubble[1] = smemBfr[10]; dlU.bubble[0] = smemBfr[11];
    resourceMatrix.dehumidifier = dlU.unslong;
     if (mode == SMEM_LOQUACIOUS) { sprintf(ioBfr, "\trM.DH: %08lX\r\n", resourceMatrix.dehumidifier); putStr(ioBfr); }

    dlU.bubble[3] = smemBfr[12]; dlU.bubble[2] = smemBfr[13]; dlU.bubble[1] = smemBfr[14]; dlU.bubble[0] = smemBfr[15];
    resourceMatrix.heater = dlU.unslong;
    if (mode == SMEM_LOQUACIOUS) { sprintf(ioBfr, "\trM.HE: %08lX\r\n", resourceMatrix.heater); putStr(ioBfr); }

    dlU.bubble[3] = smemBfr[16]; dlU.bubble[2] = smemBfr[17]; dlU.bubble[1] = smemBfr[18]; dlU.bubble[0] = smemBfr[19];
    resourceMatrix.humidifier = dlU.unslong;
    if (mode == SMEM_LOQUACIOUS) { sprintf(ioBfr, "\trM.HU: %08lX\r\n", resourceMatrix.humidifier); putStr(ioBfr); }

    dlU.bubble[3] = smemBfr[20]; dlU.bubble[2] = smemBfr[21]; dlU.bubble[1] = smemBfr[22]; dlU.bubble[0] = smemBfr[23];
    resourceMatrix.intFanTH = dlU.unslong;
    if (mode == SMEM_LOQUACIOUS) { sprintf(ioBfr, "\trM.IF: %08lX\r\n", resourceMatrix.intFanTH); putStr(ioBfr); }

    dlU.bubble[1] = smemBfr[24]; dlU.bubble[0] = smemBfr[25];
    resourceMatrix.floodSensor = dlU.unsshort;
    if (mode == SMEM_LOQUACIOUS) { sprintf(ioBfr, "\trM.FS: %04X\r\n", resourceMatrix.floodSensor); putStr(ioBfr); }

    resourceMatrix.outsideTH = smemBfr[26];
    if (mode == SMEM_LOQUACIOUS) { sprintf(ioBfr, "\trM.XS: %04X\r\n", resourceMatrix.outsideTH); putStr(ioBfr); }
    
    return(2 * SMEM_ARRAY_SIZE);
}

    // Called periodically as operating parm backup
    // Returns num bytes written on success or neg failure code.
int smemWriteParms(void)
{
    byte d, *dPtr;
    dPtr = (byte *)&oP;     // TODO Use union?
    for (d = 0; d < SMEM_ARRAY_SIZE; d++)
        smemBfr[d] = (byte) *(dPtr + d);

    if (smem_WriteArray(SMEM_ADDR_PARMS, smemBfr, SMEM_ARRAY_SIZE) < SMEM_ARRAY_SIZE)
        return(-1);

    for (d = 0; d < UID_SIZE; d++)
        smemBfr[d] = oP.uniqueID[d];
    smemBfr[d] = 0;
    if (smem_WriteArray(SMEM_ADDR_UID, smemBfr, UID_SIZE + 1) < UID_SIZE + 1)
        return(-2);

       // TODO this is trashing the vals
    dlU.unslong = resourceMatrix.airConditioner;
    smemBfr[0] = dlU.bubble[3]; smemBfr[1] = dlU.bubble[2]; smemBfr[2] = dlU.bubble[1]; smemBfr[3] = dlU.bubble[0];
   
    dlU.unslong = resourceMatrix.airExchanger;
    smemBfr[4] = dlU.bubble[3]; smemBfr[5] = dlU.bubble[2]; smemBfr[6] = dlU.bubble[1]; smemBfr[7] = dlU.bubble[0];
    dlU.unslong = resourceMatrix.dehumidifier;
    smemBfr[8] = dlU.bubble[3]; smemBfr[9] = dlU.bubble[2]; smemBfr[10] = dlU.bubble[1]; smemBfr[11] = dlU.bubble[0];
    dlU.unslong = resourceMatrix.heater;
    smemBfr[12] = dlU.bubble[3]; smemBfr[13] = dlU.bubble[2]; smemBfr[14] = dlU.bubble[1]; smemBfr[15] = dlU.bubble[0];
    dlU.unslong = resourceMatrix.humidifier;
    smemBfr[16] = dlU.bubble[3]; smemBfr[17] = dlU.bubble[2]; smemBfr[18] = dlU.bubble[1]; smemBfr[19] = dlU.bubble[0];
    dlU.unslong = resourceMatrix.intFanTH;
    smemBfr[20] = dlU.bubble[3]; smemBfr[21] = dlU.bubble[2]; smemBfr[22] = dlU.bubble[1]; smemBfr[23] = dlU.bubble[0];
    dlU.unsshort = resourceMatrix.floodSensor;
    smemBfr[24] = dlU.bubble[1]; smemBfr[25] = dlU.bubble[0];
    smemBfr[26] = resourceMatrix.outsideTH;

    if (smem_WriteArray(SMEM_ADDR_RESMTX, smemBfr, SMEM_ARRAY_SIZE) < SMEM_ARRAY_SIZE)
        return(-3);
    
    return(2 * SMEM_ARRAY_SIZE);      // 2 pages written
}

int smem_ReadArray(unsigned addr, byte *arrayPtr, unsigned arraySize)
{
    unsigned by;

    if (smem_Busy()) return(0);        // Pause till free
    SMEM_CS_n = 0;
    spi2_WRBuffer(SMEM_READ);
    spi2_WRBuffer(addr >> 8);
    spi2_WRBuffer(addr);

    for (by = 0; by < arraySize; by++)
    {
        arrayPtr[by] = spi2_WRBuffer(SMEM_DUMMY);
    }
    SMEM_CS_n = 1;
    return(by);
}

int smem_WriteArray(unsigned addr, byte *arrayPtr, unsigned arraySize)
{
    unsigned by;
   
    if (smem_Busy()) return(0);        // Pause till free
    SMEM_CS_n = 0;
    spi2_WRBuffer(SMEM_WREN);    //
    SMEM_CS_n = 1;
    delay_us(1);
    SMEM_CS_n = 0;
    spi2_WRBuffer(SMEM_WRITE);
    spi2_WRBuffer(addr >> 8);
    spi2_WRBuffer(addr);

    for (by = 0; by < arraySize; by++)
    {
//        if ((addr + by) % 64 == 0 && by != 0)  // Hit 64 byte page boundary
//        {
//            SMEM_CS_n = 1;
//            if (smem_Busy()) return(0);        // Pause till free
//            SMEM_CS_n = 0;
//            spi2_WRBuffer(SMEM_WREN);
//            SMEM_CS_n = 1;
//            delay_us(1);
//            SMEM_CS_n = 0;
//            spi2_WRBuffer(SMEM_WRITE);
//            spi2_WRBuffer((addr + by) >> 8);
//            spi2_WRBuffer(addr + by);
//        }   
        spi2_WRBuffer(arrayPtr[by]);

    }
    SMEM_CS_n = 1;
    return(arraySize);
}

    // Returns true if times out busy, which is a fault.
bool smem_Busy(void)
{
    byte status = 0;
    unsigned timeOut = 0;

    do
    {
        SMEM_CS_n = 0;
        spi2_WRBuffer(SMEM_RDSR);    // Read status reg
        status = spi2_WRBuffer(0);  // Test datum
        SMEM_CS_n = 1;
        if (timeOut++ == 0xFFFF) return(true); 
    } while (status & 0x01);

    return(false);
}

 byte spi2_WRBuffer(byte datum)
 {
     SPI2BUF = datum;
     while (!SPI2STATbits.SPIRBF) ;
     return (SPI2BUF);
 }

