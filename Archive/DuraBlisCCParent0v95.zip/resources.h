/* File:   resources.h
 * Manages the matrix of needed control resoources versus parent / child owners
 * Author: Michael L Anderson
 * Contact: MichaelLAndersonEE@gmail.com
 * Platform: PIC32MX350F256H on DuraBlis-CCS-Main_v4 board.
 * LCD:  NHD NHD-C12864WC-FSW-FBW-3V3, 128 x 64 pixels
 * Created: 18 Sep14
 */

#ifndef RESOURCES_H
#define	RESOURCES_H

#ifdef	__cplusplus
extern "C" {
#endif

//#define IDX_PARENT  0       // Used in resource mgmt

    // Resource bit field.  Any given resource, such as .heater, may have these set
#define RES_Ch1A    0x00001
#define RES_Ch1B    0x00002
#define RES_Ch2A    0x00004
#define RES_Ch2B    0x00008
#define RES_Ch3A    0x00010
#define RES_Ch3B    0x00020
#define RES_Ch4A    0x00040
#define RES_Ch4B    0x00080
#define RES_Ch5A    0x00100
#define RES_Ch5B    0x00200
#define RES_Ch6A    0x00400
#define RES_Ch6B    0x00800
#define RES_Ch7A    0x01000
#define RES_Ch7B    0x02000
#define RES_Ch8A    0x04000
#define RES_Ch8B    0x08000
#define RES_ParA    0x10000
#define RES_ParB    0x20000

#define RES_CYCLE_UP    0x01
#define RES_CYCLE_DOWN  0x02

   // This maps needed resources to child node numbers or local control.
    // We will incorporate the info from childen EQQs.  Children are 1-indexed.
    // xx, <1> parent K1, <1> parent K2, <4> child K1, <4> child K2, <4> child input
    // The order here shall be the priority order. Eg, if local K1 bit is set for heater and for airCon,
    // we will treat only heater case.  This is a logical inconsistency that should be caught by RealityCheck().
    // A resource may easily be null, in which case we lack a control vector. An implicit assumption is that a
    // given resource has at most two children associated with it. This seems reasonable.
struct res_struct
{
    unsigned long airConditioner;   // uns longs are bitfields RES_
    unsigned long heater;           // Parent low-current thermostat K1 & K2 only for first two resources
    unsigned long dehumidifier;
    unsigned long airExchanger;
    unsigned long humidifier;
    unsigned long intFanTH;
    byte outsideTH;                 // = child number with, 0 if none
    unsigned floodSensor;           // Bitfield, 1-based
} resourceMatrix;

// void resourceQuery(unsigned *resource, byte owner);
void resourceQuery(byte owner, char rlyAB, char *dest);
//bool resourceChange(unsigned *resource, byte owner, byte relay, bool enabled);
void resourceInitialize(void);

#ifdef	__cplusplus
}
#endif

#endif	/* RESOURCES_H */